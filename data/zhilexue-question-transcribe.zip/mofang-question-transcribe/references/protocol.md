# 导入包协议（mofang-question-pack v1）

本文件是交付格式的完整规范。字段名与语义已冻结，产物由「魔方助教」按本协议校验；结构与 `question-pack.schema.json` 一致，冲突时以随包 Schema 为准。

## 一、交付形态

- **纯文字**：单个 UTF-8 JSON 文件（文件名任意），`assets` 为空数组、所有 `sources` 不带 `path`。
- **含图**：一个普通 ZIP：

```text
录题结果.zip
  questions.json     固定名，ZIP 根内
  assets/            必要的实际配图（PNG/JPEG/WebP 位图）
  sources/           可选：原截图、原资料或复核片段
```

ZIP 内路径一律 POSIX 相对路径，可含中文和空格；不允许绝对路径、盘符、反斜杠、空段、`.`/`..`、控制字符、Windows 非法字符/设备名、末尾点空格。只装 `questions.json` 里声明过的 assets/sources 文件；禁止打包 `.env`、凭据、密钥、数据库文件或整个工作目录。

## 二、包根结构

```json
{
  "format": "mofang-question-pack",
  "schemaVersion": 1,
  "packageId": "…一次交付的标识",
  "datasetId": "…稳定来源命名空间",
  "title": "可选，包标题",
  "sources": [ …至少 1 项… ],
  "assets":  [ …可为空… ],
  "questions": [ …至少 1 项… ]
}
```

- `schemaVersion` 只支持整数 `1`；其他版本会被整包拒绝，不要猜测兼容写法。
- 所有对象默认**禁止额外键**；来源材料里的原始扩展字段只放进 `metadata.extra`。
- 可省略字段直接不写；**必填可空的字段要显式传 `null`**，不要用空字符串或空数组冒充「无」。

### 标识（1～160 字符非空字符串）

| 字段 | 稳定性 | 规则 |
|---|---|---|
| `packageId` | 一次交付一份 | 对同一交付批次的续跑/修订保持不变 |
| `datasetId` | 长期稳定 | 来源命名空间。复用已有来源 ID；首次遇到新来源时按原件稳定身份确定一次并保存，后续修订复用 |
| `recordKey` | 包内唯一且跨修订稳定 | 使用原始题号或稳定源记录 ID；内容改动、重试和工作目录变化不应改变它 |

允许中文、`/`、`#`、`:`；它们不是文件路径。不要用临时目录名、文件名、生成时间、每次编辑后变化的内容哈希或本地随机 UUID 冒充稳定来源身份。新材料即使同名，只要来源不同就需要不同 `datasetId`。无题号材料可在已确定的来源 ID 下使用稳定顺序定位。

## 三、逐题结构

```json
{
  "recordKey": "…",
  "source":   { "sourceId": "…", "provider?": "…", "url?": "…", "sourceRecordId?": "…", "locators?": [...] },
  "metadata": { "subject?": {...}, "stage?": {...}, "questionType?": {...},
                "difficulty?": { "raw": "…", "provider?": "…", "scale?": "…" },
                "knowledgePoints?": ["…"], "knowledgePaths?": ["…"], "suggestedTags?": ["…"],
                "extra?": { …原始扩展字段… } },
  "content": {
    "format": "mofang-md-v1",
    "stem": "…题干，trim 后不得为空…",
    "options":  [ { "label": "A", "text": "…" } ],
    "answer":   "字符串或 null",
    "analysis": [ { "label": "解答", "text": "…" } ] 或 null,
    "figures":  [ { "ref": 1, "assetId": "…", "role": "figure" } ]
  },
  "issues": [ { "code": "…", "level": "…", "field": "…", "message": "…" } ]
}
```

### source（来源）

- `sourceId` 必须能在包根 `sources` 清单里找到；`sources` 每项形如 `{ "id", "name", "kind", "path?", "sha256?", "excerpt?" }`，`kind ∈ image | text | document`。`name` 必填——哪怕只是「用户粘贴文字」。
- `path` 是素材在 ZIP 内（或 `--root` 素材目录下）的实际相对路径；**不附原件是合法的**，只写清单信息即可，不阻塞正常题。
- `sha256` 若写必须是小写 64 位 hex；工具会对实际文件重算核实，**不要凭记忆或模型生成填写**——拿不准就省略，交由打包工具回填实际值。
- `url` 只作为来源文本记录（http/https），导入器不会访问它。
- `locators`（可选溯源定位，行/页/表格行从 1 起）：
  - `{"kind":"lines","start":n,"end":n}`（start ≤ end）
  - `{"kind":"page","page":n,"rect?":[x1,y1,x2,y2]}`（rect 为原图左上原点 0~1 归一坐标，x1<x2、y1<y2）
  - `{"kind":"sheet","sheet":"表名","row":n}`
  - `{"kind":"text","label":"材料中的位置说明"}`
- `excerpt`（sources 上）最多 20000 字符。

### metadata（分类）

- 未给分类就整段省略，不要求你推断学科学段；材料原文里有的分类（如标签行、章节名）按原文保留。
- `subject/stage/questionType` 形如 `{"label":"物理","code?":"物理代称","basis":"source|inferred|user-default"}`：`basis` 区分「材料原文（source）」与「你推断的（inferred）」；`code` 只是字典建议，**不是**本地关联 ID。
- `difficulty` 保留原文 `{raw, provider?, scale?}`；尺度不明不要自己换算成数字。
- 知识点/标签不确定就不写；写了就准备对用户负责。

### content（正文）

- `options`：无选项用 `[]`；有选项时不强制四项，`label` 唯一非空（≤16 字符），`text` 不得空白（可以是图位，见下）。
- `answer`：材料没给答案就是 `null`；不给答案的题可以正常入库，**不要因此丢题，更不要自己解题补上**。
- `analysis`：材料没给解析就是 `null`；给了就按原文栏目保序逐段写（如「分析」「解答」「点评」各一段），`label`/`text` 非空，不把点评混进题干。
- `figures`：图位清单；`ref` 为正整数且同题唯一（正文可多次引用同一 ref），`role ∈ figure | formula-image | answer-image | analysis-image`。

## 四、mofang-md-v1 正文语法

只承诺以下能力，其余按字面文本保存（不执行、不静默剥除）：

| 写法 | 含义 |
|---|---|
| 空行/换行 | 段落与换行 |
| `$…$` | 行内公式（LaTeX） |
| `$$…$$`（独立成段） | 公式块 |
| `[图N]` | 图位，对应 `figures` 里 `ref: N` 的资产 |
| `\|` 管道表格 | 规则表格（见下） |
| `\$` / `\|` | 字面美元符号 / 表格单元格内的字面竖线；公式内的 `\|` 不分格 |

- 源材料里的 `\(...\)`、`\[...\]` 公式定界**由你改写**成 `$...$`、`$$...$$`；不要指望导入器猜。
- 普通 HTML、标题、列表、强调标记按字面文本保存；排版要求超出本子集时给该题留 review 问题。
- **表格**：必须表头、分隔行、各行列数一致，空单元格显式保留；多/少列或无法表达的合并格 → 该题 blocking 问题，不要补格或截断。分隔行缺失但疑似表格时保留原文字并留 review；普通竖线不要误判成表格。
- 数字、选项顺序、原文措辞一律不改；只把 CRLF 规范成 LF。

## 五、图片资产

- `assets` 每项：`{ "id", "path", "mime", "sha256?", "width?", "height?" }`，`mime ∈ image/png | image/jpeg | image/webp`；`path` 相对包根（ZIP 内）或 `--root` 目录。
- **必须是真实位图**：取原图或忠实裁剪，不许让生成模型重画；SVG/GIF 等来源先转成 PNG/JPEG/WebP 位图（保留来源信息在 metadata.extra 或 sources），只改扩展名不算转换。
- `[图N]` 写在独立一行成块级图位；选项或表格单元格内引用写成行内 `[图N]`（保留原位置，不要把紧邻文字拆失）。
- 单图 ≤ 8MiB；单 JSON ≤ 16MiB；源附件 ≤ 20MiB/个；ZIP 压缩体 ≤ 50MiB；展开合计 ≤ 200MiB；≤5000 题、≤20000 文件；单字段正文 ≤ 100000 字符。超限是硬拒绝，**不要以超限为由静默截断材料**——分批交付并在说明里写清。
- 整张页面截图只能放 `sources/` 作溯源，**不能当作已完成文字转写**冒充题干。

## 六、问题自报（issues）

每题可自带 `issues`，格式 `{ "code", "level", "field", "message" }`，`level ∈ blocking | review | info`：

- 看不清的数字/符号、题界不明、配图未取到 → 如实登记（例如 `level:"blocking"`、`field:"content.stem"`）。
- 导入侧会**独立重验**你登记的问题；自报不能洗白结构错误，也不必虚报无关问题。
- 材料缺失答案只产生 info，不算缺陷。
- blocking 的题会被标记「待处理」，原记录保留、不影响其他正常题导入；不要为了让题「看起来正常」而隐瞒问题。

## 七、随包校验/打包工具

```bash
node scripts/question-import-tool.cjs validate --input FILE.json|FILE.zip [--root DIR]
node scripts/question-import-tool.cjs pack --input FILE.json --root DIR --output FILE.zip [--allow-partial]
```

- 需要 Node 20 或更高版本（`node --version` 确认；工具运行不依赖安装目录之外的任何库）。
- `validate`：校验纯文字 JSON，或 `--root` 指素材目录校验「JSON+素材」，或直接校验 ZIP。输出 JSON 报告。
- `pack`：把通过校验的 JSON 与素材打成 ZIP；对实际附带的文件**重算并回填 SHA-256**，只读声明的路径，不联网、不改输入文件。已存在的输出默认拒绝覆盖。
- 退出码：`0` 无 blocking；`1` 存在逐题 blocking（正常题保留在报告里）；`2` 包级故障/参数/IO 错误。`review`/`info` 始终输出，不隐藏。
- 官方 CLI 默认「有 blocking 不写输出」；确需带问题交付时加 `--allow-partial` 生成明确 partial 包，导入侧仍会重验。

`mofang.cjs pack` 是随包辅助入口，另有安全写入步骤：先调用官方 CLI 校验包结构和路径，再暂存缺少的素材，候选 ZIP 写入临时目录并复验。校验或最终写入失败时保留旧输出；`--force` 也不会预先删除它。部分包可在没有旧输出时按显式 `--allow-partial` 交付，但不会用未通过完整复验的候选包替换已有文件。

交付前至少跑一次 `validate`（含图先 `pack` 再 `validate` 打出的 ZIP）；按报告修正你这边能修正的问题后再交付。完整示例见 `assets/examples/`。
