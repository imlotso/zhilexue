# extract-material — 素材预处理入口

上级：[SKILL.md](../SKILL.md)。

当输入属于下方支持范围且抽取结果完整时，可用一条命令生成 blocks、媒体与来源映射。先核对支持范围和实际告警；本脚本不负责 PDF、PPTX、XLSX 或扫描件 OCR。

## 用法

```bash
node scripts/extract-material.cjs --input <素材> [--out DIR] [选项]
```

| 选项 | 说明 |
|---|---|
| `--input FILE` | 素材路径（docx / docm / 图片 / md / txt） |
| `--out DIR` | 输出目录，默认 `./_work` |
| `--raster-scale N` | 矢量图栅格化倍率，默认 `2` |
| `--sheet-max-height N` | 单张公式对照表最大高度（像素），默认 `1200`；显式值仍可自定义短页高度 |
| `--no-math-absorb` | 不把紧邻斜体的数字/运算符并入公式 |
| `--no-italic-math` | 不把斜体 run 视作数学变量（全部按纯文本） |
| `--no-copy-source` | 不把原件复制到 `_work/sources/`（大批量时省一次全量拷贝） |
| `--full` | `manifest.json` 输出完整 `media[]`（含 `sha256`/`from`/尺寸；默认精简） |
| `--json` | 只输出机器可读的 JSON 摘要 |

退出码：`0` 成功；`1` 部分失败（已降级，看 warnings）；`2` 参数 / IO / 致命错误。

## 产物

```text
_work/
  blocks.txt            ★**行式视图**：每行一段（`段号 / 图片 / 原文`）。默认读这一份
  blocks.json           同样的内容，结构化版（段落/表格/图片按文档顺序）。需要表格结构时才读
  text.md               纯文本版（人读用；默认不必给模型读）
  manifest.json         段落↔媒体映射、角色判定、告警、next 提示（默认精简）
  media/
    F001.png …          公式（矢量已栅格化、已裁白边）
    FIG01.png …         插图
  formula-sheet-*.png   双列短页公式对照表；超宽图有重叠分段标签
  sources/              原始素材副本（`--no-copy-source` 时跳过）
```

> **按用途选产物**：需要表格单元格结构时读 `blocks.json`；只需连续段落文本时读 `blocks.txt`。文件预览和截断限制取决于当前宿主工具，不作固定大小承诺。历史 WorkBuddy 会话曾在约 50 KB JSON 上只显示短预览；换用前先检查当前工具实际返回的内容，不能假设 JSON 必被截断或 TXT 一定完整显示。

### blocks.txt

```text
00001	FIG01	{{FIG01}}山东省2022年普通高中学业水平等级考试
00002		物理
00003		注意事项：
00008	F001	1. 碘125衰变时产生{{F001}}射线，…
-- 表格 #1 role=options rows=2 --
00002	(表1)	A．
00003	(表2)	电流通过导体的热功率…
-- 表格 #1 结束 --
```

### blocks.json

```json
{ "blockCount": 103,
  "blocks": [
    { "paraIndex": 1, "text": "1．（6分）（2015•浙江）下列说法正确的是（　　）" },
    { "type": "tbl", "tableId": 1, "role": "options",
      "rows": [ [ [ {"paraIndex":2,"text":"A．"} ], [ {"paraIndex":3,"text":"电流通过导体的热功率…"} ] ] ] },
    { "paraIndex": 9, "inTable": true, "text": "考点：", "images": [] },
    { "paraIndex": 25, "text": "{{F001}}", "images": ["F001"] }
  ] }
```

- `type` 缺省即普通段落；`inTable: true` 标记它原本在表格里。
- `role` 是**启发式提示**（`options` / `analysis` / `other`），只帮你分类，不替你下结论。
- 空字段（`images: []` / `inTable: false`）会被省略以压体积。

### manifest.json 关键字段

| 字段 | 说明 |
|---|---|
| `stats` | 段落 / **表格内段落** / **表格·行·单元格** / 公式 / 插图 / OMML / 栅格化 / 去重 / 清理尾随字节 |
| `capabilities.rasterBackend` | **探测到的**栅格化后端（`null` 表示本机确实没有）；`rasterizedWith` 才是本次实际使用的 |
| `media[]` | 每项含 `id` / `role` / `path` / `paragraphs`（异常时另有 `note`）；`--full` 时附 `from` / `mime` / `width` / `height` / `sha256` / `rasterized` |
| `formulaSheets[]` | 对照表文件、所含编号、覆盖段落范围 `paragraphRange`，以及每个视图的原图 `segments[]`（分段序号、起止像素与重叠宽度） |
| `warnings[]` | 读取、转换、后端、表格或字形相关告警；若影响当前材料，要回看对应原件并定位未读取部分 |
| `suspectedMissingGlyph[]` | 疑似渲染成方框的缺字（保守启发式），需结合上下文与配图判读 |
| `suspectedMangledGlyph[]`（v1.2.2） | **疑似字形回退**：WMF/EMF 公式按字符绘制，本机缺字体时渲染器会回退成别的形状（实测 `≤` → **两个并排的小逗点**）。这是按形态筛出的核对提示，不代表所有公式图都必须逐张看。 |
| `glyphChecks`（v1.2.3） | **自报检测覆盖范围**：`covered[]` / `notCovered[]` / `backend`。两个名单都为空时看这里，别把「未命中」读成「公式全对」 |
| `media[].from`（v1.2.3） | 图位编号 ↔ 源文件（精简版也保留），供 `vector-text.cjs` 等外部工具对齐 |
| `next[]` | 建议的下一步 |

> **公式图片的定向核对**：先按 `formulaSheets[].paragraphRange` 查看当前题目相关的编号；短页默认双列且长边不超过 1200 像素。超宽公式会以重叠的原图横向范围生成局部视图，标签形如 `F094-01/06`，`formulaSheets[].segments[]` 记录稳定公式 ID、序号、总段数、原图起止像素及与前段重叠宽度；原始完整单图仍保存在 `_work/media/Fxxx.png`。遇到模糊、告警或与上下文不符时，直接打开原始单图。`node scripts/mofang.cjs inspect --work _work --formula F112 --no-write` 会给出单图完整路径、对应原文段落附近块和包含它的对照表。`suspectedMangledGlyph` 仅是本机形态提示，不证明未命中的图无误；确认后按原文转写并在相应题目记录依据。换机器或字体后应重新判断，不沿用旧结论。

> `stats.tables > 0` 但 `stats.paragraphsInTables == 0` → 直接进 `warnings`：这是"表格内容整块丢失"的硬信号（v1.1 曾静默发生）。先处理它，再往下走。

## 支持的素材

| 类型 | 支持情况 |
|---|---|
| `.docx` / `.docm` | ✅ 解包 + 解析段落/OMML/**表格单元格**/图片 + 公式插图自动分类 |
| 位图 `png/jpg/jpeg/webp/gif/bmp/tif` | ✅ 直接作为素材（多页文档请先导出） |
| 矢量 `wmf/emf/svg` | ✅ 自动栅格化为 PNG |
| `md` / `txt` | ✅ 纯文本路径 |
| `.doc` 老二进制 | ❌ 可尝试 `node scripts/convert-doc.cjs --input a.doc`；转换能力取决于本机可用程序 |
| `pdf` / `pptx` / `xlsx` | ❌ 请转成上述格式或导出位图 |

## 矢量栅格化后端

按优先级探测，探测不到就**如实降级**并写进 warnings，绝不伪造：

1. Windows GDI+（`System.Drawing`，经 PowerShell 批量调用，每批 150 张）
2. `magick` / `mogrify`（ImageMagick，整批一次进程）

> **中文路径陷阱**：PowerShell 5.1 按 ANSI 读取 `.ps1`，脚本里出现中文路径会被静默乱码（脚本还打印成功）。本工具一律把脚本、入参、输入输出都放在 **ASCII 临时目录**，路径通过 **UTF-8 JSON 任务文件**传递，不经命令行。

## 输出文本的约定

- 斜体 run（`S`/`H`/`g`/`R`/`p₁` …）→ `$...$`；正常体（如 `60°`）保留纯文本。
- 紧邻斜体、且只含数字/运算符/希腊字母的片段并入同一公式（`2R` → `$2R$`，`π∙2R` → `$\pi\cdot2R$`）。
- 图片占位符按**阅读顺序**编号并对**内容相同**的图去重：同一张公式图在多处出现时，占位符相同。
- 中文统一按字符转义：公式内含中文时输出 `\text{...}`。

## 常见情况处理

- **`rasterBackend: null`**：本机确实无栅格化后端。矢量公式图无法转写，如实告诉用户并登记 `issues`；或在有 GDI+/ImageMagick 的环境重跑。
- **`suspectedMissingGlyph` 非空**：该公式含字形缺失（渲染成**空心方框**）。结合上下文与配图判读。
  v1.2.3 起相关题目会**自动带上** `Q_GLYPH_SUSPECT`(info)，不必手工登记；拿不准那个方框是什么字符时，用
  若当前包内 helper 支持该原件格式，可运行 `node scripts/vector-text.cjs --input <素材> --work _work` 对照矢量源中的字符码；输出可能不完整，仍需和原图及同源材料核对。
- **两个检测器的标定与边界（v1.2.3）**：方框检测按**边长比例**内缩（固定像素内缩会漏报粗笔画方框）、
  先降采样再扫；成对逗点检测带**纵向位置闸**（真例残片在数学轴，上标双撇号在上标区，否则 `y₁″` 这类会被误报）。
  在山东 277 张 + 河北 269 张上标定为零误报零漏报。
- **`suspectedMangledGlyph` 非空**：见上文「怎么用」。这类图渲染结果**看起来是正常公式**，最容易静默错转。
- **告警里出现"图片无法解码"**：该图不能用作 assets；保留原件、登记 `issues`。
- **纯文字素材**：`media/` 为空、无对照表；直接按 `blocks.txt` / `blocks.json` 组包，交付单个 JSON。
