"use strict";
/**
 * vector-text — 从**矢量源**里回读公式用到的原始字符（WMF / EMF）。
 *
 * v1.2.3 新增。为什么需要它：
 *   公式在 Office 文档里常是矢量图（WMF/EMF）。本机缺字体时，渲染器会做字体回退，
 *   把某个字符画成**方框**或**别的形状**——图看着正常，靠肉眼和像素启发式只能「猜」。
 *   而矢量文件里通常保留着 `ExtTextOut` 文本记录，**原始字符就在里面**，可以直接读。
 *
 * 用途（两件，都是通用能力，与具体试卷版式无关）：
 *   1) **裁决字形丢失**：`0 □ L/v₀` 里那个方框到底是什么字符 —— 读清单，不用猜。
 *   2) **交叉校验转写**：清单里出现的字符集，可以拿来核对你写的 LaTeX 是否靠谱
 *      （例：清单里有 `D`/`F` 而无 `Δ`/`Φ`，那是 Symbol 字体的位序，不是错字）。
 *
 * ⚠️ 清单**可能不完整**：部分字形是被画成轮廓（多边形）而不是文本记录的。
 *    因此「清单里没有某字符」不能直接判定原文没有；反之「清单里有的字符」是硬证据。
 *
 * 用法：
 *   node scripts/vector-text.cjs --input <素材.docx|素材.pptx|单个.wmf|.emf> [--work _work] [--json]
 *   · 传 OOXML（docx/pptx/xlsx）时用 --work 指到预处理目录，借 manifest 的 media[].from
 *     把 F/FIG 编号对齐到源文件；没有 manifest 时按「同扩展名、内容去重后的出现顺序」兜底。
 */
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { ZipReader } = require("./lib/zip.cjs");

const TOOL = "mofang-import";
const VERSION = "1.2.3";

/* ------------------------------------------------------------------ */
/* WMF                                                                 */
/* ------------------------------------------------------------------ */
const GLYPH_DOWNSCALE = 0; // 占位：本文件不做像素处理

/**
 * 找出 WMF 记录链的起始偏移。
 * 标准 22 字节 placeable 头之后本应是 META_HEADER（size=18 字），但实测有写在
 * `fn` 在前、`size` 为 16 位变体的文件，直接读会算错。这里用「能不能干净地走到文件尾」
 * 反解出起点，对写坏的文件更稳。
 */
function findRecordStart(buf) {
  for (let start = 22; start <= 48; start += 1) {
    let off = start;
    let n = 0;
    let ok = true;
    while (off + 6 <= buf.length) {
      const size = buf.readUInt32LE(off);
      if (size < 3 || size > 200000 || off + size * 2 > buf.length + 2) { ok = false; break; }
      off += size * 2;
      n += 1;
      if (off === buf.length) break;
    }
    if (ok && off === buf.length && n >= 3) return start;
  }
  return null;
}

function decodeAnsi(raw) {
  // WMF 文本记录是 8 位代码页；中文文档多为 GBK（Node 官方构建带完整 ICU）
  try { return new TextDecoder("gbk").decode(raw); } catch (e) { return raw.toString("latin1"); }
}

/** 读 WMF 的文本记录，返回 [{fn, chars}]（按记录顺序，同字体分组） */
function readWmfText(buf) {
  const start = findRecordStart(buf);
  if (start === null) return { start: null, groups: [] };
  const groups = [];
  let off = start;
  while (off + 6 <= buf.length) {
    const size = buf.readUInt32LE(off);
    const fn = buf.readUInt16LE(off + 4);
    if (size < 3 || off + size * 2 > buf.length) break;
    if (fn === 0x0a32 || fn === 0x0521) {
      const p = off + 6;
      let count;
      let opt = 0;
      let sp;
      if (fn === 0x0a32) {                    // META_EXTTEXTOUT: y, x, count, options, [rect], string
        count = buf.readUInt16LE(p + 4);
        opt = buf.readUInt16LE(p + 6);
        sp = p + 8;
      } else {                                 // META_TEXTOUT: count, string
        count = buf.readUInt16LE(p);
        sp = p + 2;
      }
      if (opt & 0x0006) sp += 8;               // ETO_CLIPPED / ETO_OPAQUE → 先有一个矩形
      const raw = buf.slice(sp, sp + count);
      groups.push({ fn: fn === 0x0a32 ? "EXTTEXTOUT" : "TEXTOUT", chars: decodeAnsi(raw), hex: raw.toString("hex") });
    }
    off += size * 2;
  }
  return { start, groups };
}

/* ------------------------------------------------------------------ */
/* EMF                                                                 */
/* ------------------------------------------------------------------ */
const EMR_EXTTEXTOUTA = 83;
const EMR_EXTTEXTOUTW = 84;

/** 读 EMF 的文本记录（EMR_EXTTEXTOUTA/W） */
function readEmfText(buf) {
  const groups = [];
  let off = 0;
  while (off + 8 <= buf.length) {
    const type = buf.readUInt32LE(off);
    const size = buf.readUInt32LE(off + 4);
    if (size < 8 || off + size > buf.length) break;
    if (type === EMR_EXTTEXTOUTA || type === EMR_EXTTEXTOUTW) {
      // EMRTEXT 起始于记录内偏移 36
      const p = off + 36;
      if (p + 16 <= buf.length) {
        const nChars = buf.readUInt32LE(p + 8);
        const offString = buf.readUInt32LE(p + 12);
        const opt = buf.readUInt32LE(p + 20);
        const sp = off + offString;
        if (offString > 0 && sp + (type === EMR_EXTTEXTOUTW ? nChars * 2 : nChars) <= buf.length) {
          const raw = buf.slice(sp, sp + (type === EMR_EXTTEXTOUTW ? nChars * 2 : nChars));
          const chars = type === EMR_EXTTEXTOUTW ? raw.toString("utf16le") : decodeAnsi(raw);
          groups.push({ fn: type === EMR_EXTTEXTOUTW ? "EXTTEXTOUTW" : "EXTTEXTOUTA", chars, opt });
        }
      }
    }
    off += size;
  }
  return { start: 0, groups };
}

function readVector(file) {
  const buf = fs.readFileSync(file);
  const ext = path.extname(file).toLowerCase();
  let r;
  if (ext === ".emf") r = readEmfText(buf);
  else if (ext === ".wmf") r = readWmfText(buf);
  else r = { start: null, groups: [], unsupported: true };
  const flat = r.groups.map((g) => g.chars).join("");
  return { source: path.basename(file), start: r.start, groups: r.groups, chars: [...new Set([...flat])] };
}

/* ------------------------------------------------------------------ */
/* OOXML：把图位编号对齐到源矢量文件                                    */
/* ------------------------------------------------------------------ */
const VECTOR_RE = /\.(wmf|emf)$/i;
const IMAGE_RE = /\.(png|jpe?g|webp|gif|bmp|tiff?|wmf|emf)$/i;

function ooxmlMainPart(zip) {
  const names = zip.list();
  return names.find((n) => n === "word/document.xml")
    || names.find((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n))
    || names.find((n) => /^xl\/worksheets\/sheet\d+\.xml$/.test(n))
    || names.find((n) => n === "word/header1.xml")
    || null;
}

function relPathOf(mainPart) {
  return `${path.posix.dirname(mainPart)}/_rels/${path.posix.basename(mainPart)}.rels`;
}

/** 按引用顺序取出图片文件名（含重复），用于去重后的编号对齐 */
function orderedMedia(zip, mainPart) {
  const rels = zip.readOptional(relPathOf(mainPart));
  const map = new Map();
  if (rels) {
    for (const m of rels.toString("utf8").matchAll(/Id="([^"]+)"[^>]*?Target="([^"]+)"/g)) map.set(m[1], m[2]);
  }
  const xml = zip.read(mainPart).toString("utf8");
  const out = [];
  for (const m of xml.matchAll(/r:(?:embed|id|link)="([^"]+)"/g)) {
    const t = map.get(m[1]);
    if (!t) continue;
    const base = t.split("/").pop();
    if (IMAGE_RE.test(base)) out.push(base);
  }
  return out;
}

/** manifest 里的 media[].from → 图位编号（权威）；没有 manifest 就按去重顺序兜底 */
function idMapFromManifest(workDir) {
  if (!workDir) return null;
  const mf = path.join(workDir, "manifest.json");
  if (!fs.existsSync(mf)) return null;
  try {
    const man = JSON.parse(fs.readFileSync(mf, "utf8"));
    const media = man.media || [];
    if (!media.some((m) => m.from)) return null;   // 精简版可能没有 from
    const out = new Map();
    for (const m of media) if (m.from) out.set(String(m.from).split("/").pop(), m.id);
    return out;
  } catch (e) { return null; }
}

/** 兜底：同扩展名、内容去重后按出现顺序编号（与 extract-material 的 F/FIG 编号同口径） */
function idMapByOrder(zip, order) {
  const seen = new Set();
  const uniq = [];
  for (const name of order) {
    if (seen.has(name)) continue;
    seen.add(name);
    uniq.push(name);
  }
  const map = new Map();
  for (const ext of ["wmf", "emf"]) {
    let i = 0;
    for (const name of uniq) {
      if (!new RegExp(`\\.${ext}$`, "i").test(name)) continue;
      i += 1;
      map.set(name, `F${String(i).padStart(3, "0")}`);
    }
  }
  let j = 0;
  for (const name of uniq) {
    if (VECTOR_RE.test(name)) continue;
    j += 1;
    map.set(name, `FIG${String(j).padStart(2, "0")}`);
  }
  return map;
}

/* ------------------------------------------------------------------ */
function main(argv) {
  const o = { work: null, json: false, out: null };
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    const next = () => argv[i + 1];
    if (a === "--input" || a === "-i") o.input = next();
    else if (a === "--work" || a === "-w") o.work = next();
    else if (a === "--out" || a === "-o") o.out = next();
    else if (a === "--json") o.json = true;
    else if (/^(--help|-h)$/.test(a)) { process.stdout.write(HELP); return 0; }
  }
  if (!o.input) { process.stdout.write(HELP); return 2; }

  const entries = [];
  const ext = path.extname(o.input).toLowerCase();
  const zipLike = /\.(docx|docm|pptx|xlsx|dotx|xlsm)$/i.test(ext);

  if (!zipLike) {
    const r = readVector(o.input);
    entries.push({ id: path.basename(o.input, ext), ...r });
  } else {
    const zip = ZipReader.fromFile(o.input);
    const main = ooxmlMainPart(zip);
    if (!main) throw new Error("没找到主文档部件（word/document.xml 等）：不是可识别的 OOXML 文件");
    const order = orderedMedia(zip, main);
    const byManifest = idMapFromManifest(o.work);
    const byOrder = idMapByOrder(zip, order);
    const idOf = (name) => (byManifest && byManifest.get(name)) || byOrder.get(name) || name;
    const done = new Set();
    for (const name of order) {
      if (done.has(name)) continue;
      done.add(name);
      if (!VECTOR_RE.test(name)) continue;
      const part = `word/media/${name}`;
      const alt = zip.list("word/media/").includes(part) ? part : zip.list().find((n) => n.endsWith(`/media/${name}`));
      if (!alt) continue;
      const buf = zip.read(alt);
      const r = readVectorBuffer(buf, name);
      entries.push({ id: idOf(name), ...r });
    }
    entries.sort((a, b) => String(a.id).localeCompare(String(b.id), "zh"));
  }

  const withText = entries.filter((e) => e.groups.length);
  const result = {
    tool: TOOL, mode: "vector-text", version: VERSION,
    input: o.input,
    vectorFiles: entries.length,
    withTextRecords: withText.length,
    note: "清单来自矢量文件里的 ExtTextOut 文本记录，是**硬证据**；但可能不完整——" +
      "部分字形是被画成轮廓（多边形）而非文本记录的，所以「清单里没有」不能反推原文没有。",
    entries,
  };
  if (o.out) fs.writeFileSync(o.out, JSON.stringify(result, null, 2), "utf8");
  if (o.json || !o.out) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  } else {
    process.stdout.write(`矢量文件 ${entries.length} 个，其中 ${withText.length} 个含文本记录 → ${o.out}\n`);
  }
  return 0;
}

function readVectorBuffer(buf, name) {
  const ext = path.extname(name).toLowerCase();
  const r = ext === ".emf" ? readEmfText(buf) : readWmfText(buf);
  const flat = r.groups.map((g) => g.chars).join("");
  return { source: name, start: r.start, groups: r.groups, chars: [...new Set([...flat])] };
}

const HELP = `vector-text — 从矢量源（WMF/EMF）回读公式用到的原始字符

用法：
  node scripts/vector-text.cjs --input <素材.docx|.pptx|.xlsx|单个.wmf|.emf> [--work _work] [--out vector-text.json]

  --work _work   有 manifest 时用它把 F/FIG 编号对齐到源矢量文件（推荐）
  --out FILE     写出 JSON（不给则打印到 stdout）
  --json         强制打印 JSON

为什么需要它：公式在 Office 里常是矢量图，本机缺字体时渲染器会做字体回退，
把字符画成方框或别的形状——图看着正常，只能"猜"。而矢量文件里通常留着
ExtTextOut 文本记录，原始字符直接可读。用途：① 裁决字形丢失到底是什么字符；
② 交叉校验你写的 LaTeX（如清单里是 D/F 而非 Δ/Φ，那是 Symbol 字体位序，不是错字）。

⚠️ 清单可能不完整：部分字形是轮廓（多边形），没有文本记录。
   「清单里有的字符」是硬证据；「清单里没有」不能反推原文没有。
`;

module.exports = { readWmfText, readEmfText, readVectorBuffer, idMapByOrder };

if (require.main === module) {
  try {
    process.exitCode = main(process.argv.slice(2));
  } catch (e) {
    process.stderr.write(`错误：${e.message}\n`);
    process.exitCode = 1;
  }
}
