#!/usr/bin/env node
"use strict";
/**
 * convert-doc.cjs — 老二进制 Office（.doc/.wps 等）→ .docx（skill v1.2）
 *
 * 为什么需要它：SKILL.md 只说「.doc 走编辑器通道打开后另存」，但在 WorkBuddy 上这条路
 * 要经 office-routing → local-office-edit → 逐个 schema 探测，成本高、且预览会丢公式。
 * 本脚本把转换内置，按优先级自动探测，前两档都是「一条命令」。
 *
 * 后端优先级（探测 → 增强，绝不硬依赖）：
 *   1) soffice（LibreOffice）—— 跨平台、最快最稳，headless 批量转换
 *   2) Word COM（Windows 有 Word 时）—— 经 PowerShell 调用，转换质量最好
 *   3) 都不可用 → 明确报错并提示改走编辑器通道（如实降级，不伪造）
 *
 * ⚠️ 中文路径陷阱：PowerShell 5.1 按 ANSI 读取 .ps1，脚本里出现中文路径会**静默乱码**
 *    （脚本仍打印成功）。因此本模块：脚本内容纯 ASCII、脚本与输入输出一律放 ASCII
 *    临时目录、路径经 UTF-8 JSON 任务文件传递。与 lib/raster.cjs 同一套做法。
 *
 * 用法：
 *   node scripts/convert-doc.cjs --input a.doc [--output a.docx] [--json]
 *
 * 退出码：0 成功；2 失败/不支持
 */
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { spawnSync } = require("node:child_process");

const TOOL = "mofang-convert-doc";
const VERSION = "1.2";

const HELP = `mofang-convert-doc ${VERSION} — 老二进制 Office → .docx

用法：
  node scripts/convert-doc.cjs --input a.doc [--output a.docx] [--json]

后端优先级：soffice（LibreOffice）→ Word COM（Windows）→ 报错并提示走编辑器通道
退出码：0 成功；2 失败
`;

const LEGACY_EXT = new Set(["doc", "dot", "wps", "wpt"]);

const _whichCache = new Map();
function which(cmd) {
  if (_whichCache.has(cmd)) return _whichCache.get(cmd);
  const r = spawnSync(process.platform === "win32" ? "where" : "which", [cmd], { encoding: "utf8" });
  const ok = r.status === 0 && (r.stdout || "").trim().length > 0;
  _whichCache.set(cmd, ok);
  return ok;
}

function probe() {
  if (which("soffice")) return { backend: "soffice", detail: "LibreOffice headless" };
  if (process.platform === "win32" && which("powershell")) return { backend: "word-com", detail: "Word COM (PowerShell)" };
  return { backend: null, detail: "未找到转换后端（需 LibreOffice `soffice`，或 Windows 上的 Word）" };
}

function withTempDir(fn) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "mqtx-convert-"));
  try {
    return fn(dir);
  } finally {
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* ignore */ }
  }
}

/* 纯 ASCII 的 PowerShell 脚本；路径全部经 UTF-8 JSON 传入，不走命令行 */
const PS_SCRIPT = [
  "param([string]$JobFile)",
  "$ErrorActionPreference = 'Stop'",
  "$raw = Get-Content -LiteralPath $JobFile -Raw -Encoding UTF8",
  "$job = $raw | ConvertFrom-Json",
  "$out = New-Object System.Text.UTF8Encoding($false)",
  "$word = $null",
  "try {",
  "  $word = New-Object -ComObject Word.Application",
  "  $word.Visible = $false",
  "  $word.DisplayAlerts = 0",
  "  $d = $word.Documents.Open($job.src, $false, $true)",
  "  $d.SaveAs2($job.dst, 16)",
  "  $d.Close(0)",
  "  [System.IO.File]::WriteAllText($job.outFile, '{\"ok\":true,\"error\":null}', $out)",
  "} catch {",
  "  $msg = $_.Exception.Message.Replace('\\', '/').Replace('\"', \"'\")",
  "  [System.IO.File]::WriteAllText($job.outFile, '{\"ok\":false,\"error\":\"' + $msg + '\"}', $out)",
  "} finally {",
  "  if ($word -ne $null) { $word.Quit() }",
  "}",
].join("\n");

function convertWithSoffice(src, dst, tmp) {
  const outDir = path.join(tmp, "out");
  fs.mkdirSync(outDir);
  const r = spawnSync("soffice", ["--headless", "--norestore", "--convert-to", "docx", "--outdir", outDir, src], {
    encoding: "utf8", timeout: 300000, maxBuffer: 16 * 1024 * 1024,
  });
  const produced = fs.existsSync(outDir) ? fs.readdirSync(outDir).filter((f) => f.toLowerCase().endsWith(".docx")) : [];
  if (!produced.length) {
    return { ok: false, error: `soffice 未产出 docx（exit=${r.status}；${(r.stderr || "").slice(0, 200) || "无 stderr"}）` };
  }
  fs.copyFileSync(path.join(outDir, produced[0]), dst);
  return { ok: true };
}

function convertWithWordCom(src, dst, tmp) {
  const scriptPath = path.join(tmp, "conv.ps1");
  const jobPath = path.join(tmp, "job.json");
  const resPath = path.join(tmp, "result.json");
  fs.writeFileSync(scriptPath, PS_SCRIPT, "utf8");
  fs.writeFileSync(jobPath, JSON.stringify({ src, dst, outFile: resPath }), "utf8");
  const r = spawnSync("powershell", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", scriptPath, "-JobFile", jobPath], {
    encoding: "utf8", timeout: 300000, maxBuffer: 16 * 1024 * 1024,
  });
  let rep = null;
  if (fs.existsSync(resPath)) {
    try { rep = JSON.parse(fs.readFileSync(resPath, "utf8").replace(/^\uFEFF/, "")); } catch { rep = null; }
  }
  if (!rep) {
    return { ok: false, error: `Word COM 未返回结果（exit=${r.status}；${(r.stderr || "").slice(0, 200) || "无 stderr"}）` };
  }
  if (!rep.ok) return { ok: false, error: `Word COM 报错：${rep.error}` };
  if (!fs.existsSync(dst)) return { ok: false, error: "Word COM 未产出目标文件" };
  return { ok: true };
}

function main(argv) {
  const o = { json: false };
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    const next = () => argv[++i];
    if (a === "--input") o.input = next();
    else if (a === "--output") o.output = next();
    else if (a === "--json") o.json = true;
    else if (a === "--help" || a === "-h") { o.help = true; }
    else {
      process.stderr.write(`未知参数：${a}\n\n${HELP}`);
      return 2;
    }
  }
  if (o.help || !o.input) {
    process.stdout.write(HELP);
    return o.help ? 0 : 2;
  }
  const input = path.resolve(o.input);
  if (!fs.existsSync(input)) {
    process.stderr.write(`输入不存在：${input}\n`);
    return 2;
  }
  const ext = (path.extname(input).slice(1) || "").toLowerCase();
  if (ext === "docx") {
    process.stdout.write(`已是 .docx，无需转换：${input}\n`);
    return 0;
  }
  if (!LEGACY_EXT.has(ext)) {
    process.stderr.write(`不支持的扩展名：.${ext}（本工具用于 .doc/.dot/.wps/.wpt → .docx）\n`);
    return 2;
  }

  const output = path.resolve(o.output || path.join(path.dirname(input), `${path.basename(input, path.extname(input))}.docx`));
  const p = probe();
  const report = { tool: TOOL, version: VERSION, input, output, backend: p.backend, detail: p.detail };

  if (!p.backend) {
    report.ok = false;
    report.error = `${p.detail}。可改走编辑器通道打开后另存为 .docx。`;
    process.stdout.write(o.json ? JSON.stringify(report, null, 2) + "\n" : `转换失败：${report.error}\n`);
    return 2;
  }

  const result = withTempDir((tmp) => {
    // 一律先拷进 ASCII 临时目录，规避 PS 5.1 中文路径乱码
    const srcCopy = path.join(tmp, `in.${ext}`);
    fs.copyFileSync(input, srcCopy);
    const dstCopy = path.join(tmp, "out.docx");
    const r = p.backend === "soffice"
      ? convertWithSoffice(srcCopy, dstCopy, tmp)
      : convertWithWordCom(srcCopy, dstCopy, tmp);
    if (!r.ok) return r;
    fs.mkdirSync(path.dirname(output), { recursive: true });
    fs.copyFileSync(dstCopy, output);
    return { ok: true, size: fs.statSync(output).size };
  });

  if (!result.ok) {
    report.ok = false;
    report.error = `${p.backend} 转换失败：${result.error}`;
    process.stdout.write(o.json ? JSON.stringify(report, null, 2) + "\n" : `转换失败：${report.error}\n`);
    return 2;
  }
  report.ok = true;
  report.size = result.size;
  report.note = "转换会改变公式形态：原 .doc 里的 WMF 公式图会被另存为 PNG，因此 extract-material 的 rasterBackend 缺失不影响本卷。";
  process.stdout.write(o.json
    ? JSON.stringify(report, null, 2) + "\n"
    : `转换成功（后端：${p.backend}，${result.size} 字节）\n  ${output}\n`);
  return 0;
}

if (require.main === module) {
  process.exit(main(process.argv.slice(2)));
}

module.exports = { probe };
