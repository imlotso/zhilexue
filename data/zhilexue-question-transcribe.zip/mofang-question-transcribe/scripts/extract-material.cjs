#!/usr/bin/env node
"use strict";
/**
 * extract-material — 素材预处理入口（skill v1.2.4）
 *
 * 一次调用把「任意格式素材」摊平成模型可直接消费的固定产物：
 *   _work/blocks.txt          ★行式视图：每行一段（段号 / 图片 / 原文）。**默认读这一份**
 *   _work/blocks.json         同样内容的结构化版（段落 / 表格 / 图片按文档顺序），要表格结构时才读
 *   _work/text.md             全文，公式/插图位置写作 {{F001}} / {{FIG01}} 占位符（人读用）
 *   _work/media/              全部位图（矢量已栅格化为 PNG、已裁白边、已去尾随字节）
 *   _work/formula-sheet-*.png 所有公式拼成的大图（带编号）—— 读一次即可逐个转 LaTeX
 *   _work/manifest.json       段落↔媒体映射、角色判定、告警、下一步提示（默认精简）
 *
 * 设计要点：
 *   - 零第三方依赖（Node 标准库）
 *   - Windows 栅格化走 GDI+，用 ASCII 临时目录 + UTF-8 JSON 传参，规避中文路径乱码
 *   - 后端缺失时降级并如实登记，绝不伪造
 *
 * 用法：
 *   node scripts/extract-material.cjs --input FILE [--out DIR] [选项]
 */
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const { ZipReader } = require("./lib/zip.cjs");
const png = require("./lib/png.cjs");
const raster = require("./lib/raster.cjs");
const { parseDocx } = require("./lib/docx.cjs");

const TOOL = "mofang-extract-material";
const VERSION = "1.2.4";

const HELP = `mofang-extract-material ${VERSION} — 录题素材预处理（解包 / 栅格化 / 定位 / 对照表）

用法：
  node scripts/extract-material.cjs --input FILE [--out DIR] [选项]

选项：
  --input FILE          素材路径（docx / 图片 / md / txt）
  --out DIR             输出目录，默认 ./_work
  --raster-scale N      矢量图栅格化倍率，默认 2
  --sheet-max-height N  单张公式对照表最大高度（像素），默认 1200（双列短页；显式值继续生效）
  --no-math-absorb      不把紧邻斜体的数字/运算符并入公式
  --no-italic-math      不把斜体 run 视作数学变量（全部按纯文本）
  --no-copy-source      不把原件复制到 _work/sources/（大批量时省一次全量拷贝）
  --full                manifest.json 输出完整 media[]（含 sha256/from/尺寸等，默认精简）
  --json                仅输出机器可读的 JSON 摘要

退出码：0 成功；1 部分失败（可降级）；2 参数/IO/致命错误
`;

function parseArgs(argv) {
  const o = {
    out: "_work", rasterScale: 2, sheetMaxHeight: 1200,
    mathAbsorb: true, italicMath: true, json: false, full: false, copySource: true,
  };
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    const next = () => argv[++i];
    if (a === "--input") o.input = next();
    else if (a === "--out") o.out = next();
    else if (a === "--raster-scale") o.rasterScale = Number(next());
    else if (a === "--sheet-max-height") o.sheetMaxHeight = Number(next());
    else if (a === "--no-math-absorb") o.mathAbsorb = false;
    else if (a === "--no-italic-math") o.italicMath = false;
    else if (a === "--no-copy-source") o.copySource = false;
    else if (a === "--full") o.full = true;
    else if (a === "--json") o.json = true;
    else if (a === "--help" || a === "-h") { o.help = true; }
    else throw new Error(`未知参数：${a}`);
  }
  return o;
}

function sha256(buf) {
  return crypto.createHash("sha256").update(buf).digest("hex");
}

const IMAGE_EXT = new Set(["png", "jpg", "jpeg", "webp", "gif", "bmp", "tif", "tiff", "svg", "wmf", "emf"]);
const TEXT_EXT = new Set(["md", "markdown", "txt"]);
const DOC_EXT = new Set(["docx", "docm"]);

function detectKind(file) {
  const ext = (path.extname(file) || "").slice(1).toLowerCase();
  if (DOC_EXT.has(ext)) return "docx";
  if (ext === "doc") return "doc-legacy";
  if (IMAGE_EXT.has(ext)) return "image";
  if (TEXT_EXT.has(ext)) return "text";
  return "unknown";
}

function ensureDir(d) {
  fs.mkdirSync(d, { recursive: true });
}

function writeJson(file, obj) {
  fs.writeFileSync(file, JSON.stringify(obj, null, 2), "utf8");
}

/** manifest.json 默认只保留模型要用的媒体字段（sha256/from/尺寸对模型是噪声，pack 会自行重算） */
function compactMedia(m) {
  const c = { id: m.id, role: m.role, path: m.path, paragraphs: m.paragraphs };
  if (m.from) c.from = m.from;
  if (m.note) c.note = m.note;
  if (m.reusedId) c.reusedId = true;
  if (m.suspectedMissingGlyph) c.suspectedMissingGlyph = true;
  if (m.rasterized) c.rasterized = true;
  return c;
}

/** 把原件留档到 <outDir>/sources/（copy=false 时只返回清单信息，不落盘） */
function stageSource(input, outDir, copy) {
  const baseName = path.basename(input);
  if (!copy) return { name: baseName };
  const srcDir = path.join(outDir, "sources");
  ensureDir(srcDir);
  const dst = path.join(srcDir, baseName);
  fs.copyFileSync(input, dst);
  return { name: baseName, path: `sources/${baseName}`, sha256: sha256(fs.readFileSync(dst)) };
}

/* ------------------------------------------------------------------ */
/* docx 处理                                                           */
/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/* 表格角色（启发式）与 blocks.json                                     */
/* ------------------------------------------------------------------ */

const OPT_LABEL = /^[A-Ha-h][．.、)）]$/;
const FIELD_LABEL = /^(考点|专题|分析|解答|点评|答案|解析|详解|思路|难度|命题|考查)\s*[：:]/;

/** 判定一张表的角色：选项表 / 解析表 / 其他（只做提示，不替模型下结论） */
function detectTableRole(block, paragraphs) {
  let hasOpt = false;
  let hasField = false;
  for (const row of block.rows) {
    for (const cell of row) {
      for (const pi of cell) {
        const t = (paragraphs[pi - 1]?.text || "").trim();
        if (OPT_LABEL.test(t)) hasOpt = true;
        if (FIELD_LABEL.test(t)) hasField = true;
      }
    }
  }
  if (hasOpt) return "options";
  if (hasField) return "analysis";
  return "other";
}

/** 把段落 + 表格摊成按文档顺序的结构化流，模型读这一份即可（省略空字段以压体积） */
function buildBlocksDoc(doc, mediaByTarget) {
  const idsOf = (p) => (p?.images || []).map((im) => (mediaByTarget.get(im.target) || {}).id).filter(Boolean);
  const blocks = [];
  for (const b of doc.blocks) {
    if (b.type === "p") {
      const p = doc.paragraphs[b.paraIndex - 1];
      if (!p) continue;
      const t = p.text.replace(/\s+$/g, "");
      if (!t && p.images.length === 0) continue;
      const node = { paraIndex: p.index, text: t };
      if (p.inTable) node.inTable = true;
      const ids = idsOf(p);
      if (ids.length) node.images = ids;
      blocks.push(node);
    } else {
      const rows = b.rows.map((row) => row.map((cell) => cell.map((pi) => {
        const p = doc.paragraphs[pi - 1];
        const ids = idsOf(p);
        return ids.length
          ? { paraIndex: pi, text: (p?.text || "").replace(/\s+$/g, ""), images: ids }
          : { paraIndex: pi, text: (p?.text || "").replace(/\s+$/g, "") };
      })));
      blocks.push({ type: "tbl", tableId: b.tableId, role: detectTableRole(b, doc.paragraphs), rows });
    }
  }
  return { tool: TOOL, version: VERSION, blockCount: blocks.length, blocks };
}

/**
 * blocks.json 的**行式**等价视图。
 * 存在的理由：blocks.json 稍大（> 50 KB）就会让阅读工具退化成"只剩 2 KB 预览"，
 * 模型被迫分片读取；而同样内容的行式文本可以一次整份读完。两份信息完全一致。
 */
function renderBlocksTxt(blocksDoc) {
  const lines = [
    "# blocks.txt — 行式视图（每行一段；制表符分隔：段落号 / 图片 / 原文）",
    `# 源：blocks.json（blockCount=${blocksDoc.blockCount != null ? blocksDoc.blockCount : (blocksDoc.blocks || []).length}）`,
    "",
  ];
  for (const b of blocksDoc.blocks || []) {
    if (b.type === "tbl") {
      lines.push(`-- 表格 #${b.tableId} role=${b.role || "other"} rows=${(b.rows || []).length} --`);
      let n = 0;
      for (const row of b.rows || []) {
        for (const cell of row) {
          for (const p of cell) {
            n += 1;
            lines.push(`${String(p.paraIndex).padStart(5, "0")}\t(表${n})\t${String(p.text || "").replace(/\t/g, " ")}`);
          }
        }
      }
      lines.push(`-- 表格 #${b.tableId} 结束 --`);
      continue;
    }
    lines.push(`${String(b.paraIndex).padStart(5, "0")}\t${(b.images || []).join(",")}\t${String(b.text || "").replace(/\t/g, " ")}`);
  }
  return lines.join("\n") + "\n";
}

/**
 * 非 docx 素材（单图 / 纯文本）也要产出 blocks.json + blocks.txt。
 * v1.2.1 及以前只写 text.md，于是纯文本素材跑 scaffold 会直接 ENOENT —— 与
 * "一条命令摊平素材、产物固定"的承诺不符。
 */
function writeSimpleBlocks(outDir, blocks) {
  const doc = { tool: TOOL, version: VERSION, blockCount: blocks.length, blocks };
  writeJson(path.join(outDir, "blocks.json"), doc);
  fs.writeFileSync(path.join(outDir, "blocks.txt"), renderBlocksTxt(doc), "utf8");
  return "blocks.json";
}

function processDocx(input, outDir, o) {
  const zip = ZipReader.fromFile(input);
  const stats = { rasterized: 0, deduped: 0, sanitized: 0, missingGlyphSuspects: [], mangledGlyphSuspects: [] };
  const warnings = new Set();

  // 1) 先算每个媒体文件的占位符（按阅读顺序 + 内容去重）
  const mediaByTarget = new Map(); // mediaPath -> record
  const orders = { formula: 0, figure: 0 };
  const hashToRec = new Map();
  const idToImage = new Map(); // id -> 已裁边的解码图像（供对照表复用，避免重复解码）
  const mediaDir = path.join(outDir, "media");
  ensureDir(mediaDir);

  const doc0 = parseDocx(zip, {});
  const orderedTargets = [];
  const refCount = new Map();
  for (const p of doc0.paragraphs) {
    for (const im of p.images) {
      refCount.set(im.target, (refCount.get(im.target) || 0) + 1);
      if (!orderedTargets.includes(im.target)) orderedTargets.push(im.target);
    }
  }
  // 同一媒体被多处引用 → 复用同一 ID（此处统计复用量）
  for (const n of refCount.values()) stats.deduped += Math.max(0, n - 1);

  // 2) 栅格化需要转换的矢量图（批量一次）
  const needRaster = [];
  for (const target of orderedTargets) {
    const ext = (target.split(".").pop() || "").toLowerCase();
    if (raster.VECTOR_EXT.has(ext)) needRaster.push(target);
  }
  let rasterOut = new Map();
  let rasterDiag = null;
  // v1.2：恒报「探测到的能力」，与实际是否用到栅格化无关。
  // v1.1 写成 rasterized ? probe().backend : null，导致"本机有 GDI+ 却报 后端：无"，自相矛盾且误导模型。
  let rasterBackend = raster.probe().backend;
  if (needRaster.length) {
    const items = needRaster.map((t) => ({ key: t, bytes: zip.read(t), ext: (t.split(".").pop() || "").toLowerCase() }));
    const r = raster.rasterizeBatch(items, { scale: o.rasterScale });
    rasterOut = r.out;
    rasterDiag = r.diag;
    rasterBackend = r.backend;
    if (!r.backend) warnings.add(`矢量图栅格化不可用：${r.detail}`);
    for (const e of r.errors.slice(0, 20)) warnings.add(`栅格化失败 ${path.basename(e.key)}：${e.error}`);
    if (r.errors.length) warnings.add(`共 ${r.errors.length} 个矢量图未能转换`);
  }

  // 3) 逐个媒体落盘（PNG 统一格式；去重；裁白边）
  const idFor = (role, n) => `${role === "formula" ? "F" : "FIG"}${String(n).padStart(role === "formula" ? 3 : 2, "0")}`;

  for (const target of orderedTargets) {
    const ext = (target.split(".").pop() || "").toLowerCase();
    // 角色：取该 target 首次出现时的判定
    let role = "figure";
    let roleReason = "";
    for (const p of doc0.paragraphs) {
      const hit = p.images.find((i) => i.target === target);
      if (hit) { role = hit.role; roleReason = hit.roleReason; break; }
    }

    let bytes = null;
    let rasterized = false;
    let note = null;

    if (raster.VECTOR_EXT.has(ext)) {
      const out = rasterOut.get(target);
      if (!out) continue; // 已登记 warning
      bytes = out;
      rasterized = true;
      stats.rasterized += 1;
      note = `栅格化自 ${ext.toUpperCase()}`;
    } else {
      const raw = zip.read(target);
      if (png.isPng(raw)) {
        const s = png.sanitizeImage(raw, ext);
        bytes = s.bytes;
        if (s.trimmedBytes > 0) { stats.sanitized += 1; note = s.note; }
      } else {
        // JPEG/WebP 等：原样保留（协议接受 PNG/JPEG/WebP）
        bytes = raw;
        note = ext === "jpeg" || ext === "jpg" ? "原样保留 JPEG" : `原样保留 ${ext.toUpperCase()}`;
      }
    }
    if (!bytes) continue;

    // 去重：内容一致的多处引用共用同一 ID
    const h = sha256(bytes);
    const existing = hashToRec.get(h);
    if (existing) {
      stats.deduped += 1;
      mediaByTarget.set(target, { ...existing, reusedId: true, paragraphs: [] });
      continue;
    }
    orders[role] += 1;
    const id = idFor(role, orders[role]);

    const fileName = `${id}.png`;
    const filePath = path.join(mediaDir, fileName);
    let width = null;
    let height = null;
    let glyphSuspect = false;
    let mangledSuspect = false;

    if (png.isPng(bytes)) {
      try {
        let im = png.decodePng(bytes);
        im = png.trimWhite(im);
        width = im.width;
        height = im.height;
        if (role === "formula" && png.detectBoxGlyph(im)) {
          glyphSuspect = true;
        }
        if (role === "formula" && png.detectFallbackGlyphPair(im)) mangledSuspect = true;
        idToImage.set(id, im);
        bytes = png.encodePng(im.width, im.height, im.data);
      } catch (e) {
        warnings.add(`图片无法解码 ${path.basename(target)}：${e.message}`);
      }
    } else if (rasterDiag && rasterDiag.dims && rasterDiag.dims.has(target)) {
      const d = rasterDiag.dims.get(target);
      width = d.width;
      height = d.height;
    }

    fs.writeFileSync(filePath, bytes);
    const rec = {
      id, role, roleReason, path: `media/${fileName}`,
      from: target, mime: "image/png", width, height, sha256: sha256(bytes),
      rasterized, note, suspectedMissingGlyph: glyphSuspect, suspectedMangledGlyph: mangledSuspect, paragraphs: [],
    };
    mediaByTarget.set(target, rec);
    hashToRec.set(h, rec);
    if (glyphSuspect) stats.missingGlyphSuspects.push(id);
    if (mangledSuspect) stats.mangledGlyphSuspects.push(id);
  }

  // 4) 用最终 ID 重跑解析，生成 text.md
  const doc = parseDocx(zip, {
    italicMath: o.italicMath,
    mathAbsorb: o.mathAbsorb,
    placeholderFor: (seg) => {
      const rec = mediaByTarget.get(seg.target);
      if (rec) return `{{${rec.id}}}`;
      return `{{${seg.role === "formula" ? "F?" : "FIG?"}}}`;
    },
  });

  // 记录每个媒体出现在哪些段落
  for (const p of doc.paragraphs) {
    for (const im of p.images) {
      const rec = mediaByTarget.get(im.target);
      if (rec && !rec.paragraphs.includes(p.index)) rec.paragraphs.push(p.index);
    }
  }

  const textLines = [];
  textLines.push(`# ${path.basename(input)} — 素材全文（自动抽取）`);
  textLines.push("");
  textLines.push(`> 公式位置写作 {{Fnnn}}，插图位置写作 {{FIGnn}}；对应文件在 \`media/\`。`);
  textLines.push(`> 公式默认排成双列短页对照表；超宽公式按重叠水平范围分段并用 ASCII 编号标注，分段索引与原图坐标见 manifest.json。原始单图始终保存在 \`media/Fnnn.png\`，模糊或疑似异常时可单独打开核对。`);
  textLines.push(`> 运行 \`node scripts/mofang.cjs inspect --work _work --formula F112 --no-write\` 可定位该编号的单图、正文段落邻近块和所属对照表。`);
  textLines.push("");
  for (const p of doc.paragraphs) {
    const t = p.text.replace(/\s+$/g, "");
    if (!t && p.images.length === 0) continue;
    const mark = p.inTable ? " (表格内)" : "";
    textLines.push(`[${String(p.index).padStart(4, "0")}]${mark} ${t}`);
  }
  fs.writeFileSync(path.join(outDir, "text.md"), textLines.join("\n"), "utf8");

  // 4b) blocks.json —— 结构化流（含表格内段落）。模型默认读这一份，text.md 降级为「人读用」
  const blocksDoc = buildBlocksDoc(doc, mediaByTarget);
  writeJson(path.join(outDir, "blocks.json"), blocksDoc);

  // 4b-2) blocks.txt —— blocks.json 的**行式**等价视图（见 renderBlocksTxt 注释）。
  fs.writeFileSync(path.join(outDir, "blocks.txt"), renderBlocksTxt(blocksDoc), "utf8");

  // 4c) 自检：有表格却零表格内段落 = 解析器没进到单元格，必须告警（v1.1 曾静默丢失）
  if (doc.stats.tables > 0 && doc.stats.paragraphsInTables === 0) {
    warnings.add(
      `检测到 ${doc.stats.tables} 张表格，但未解析出任何表格内段落：题干/选项/解析可能整块缺失，请核对 lib/docx.cjs 的 w:tr/w:tc 分支`,
    );
  }

  // 4d) v1.2.2：字形回退告警。WMF/EMF 公式是按字符绘制的，若本机缺少该字符所用字体，
  //     渲染器会做字体回退把字符画成别的形状（实测 ≤/≥ 会渲染成两个并排的小逗点）。
  //     这类图**看起来是正常的公式**，不主动比对很难发现，必须点名让模型人工核对。
  if (stats.mangledGlyphSuspects.length) {
    warnings.add(
      `疑似字形回退（成对小逗点，多半是 ≤/≥ 等关系符在本机字体下渲染异常）：${stats.mangledGlyphSuspects.join(", ")}。` +
      "请逐张看图并用同源材料/原卷文本交叉确认；确认后按协议忠实转写，并在该题 issues 登记说明。",
    );
  }

  // 5) 公式对照表（自动分表；记录每表覆盖的段落范围，便于按题按需读取）
  const formulaRecs = [...mediaByTarget.values()].filter((r) => r.role === "formula" && !r.reusedId);
  const sheetItems = [];
  for (const rec of formulaRecs) {
    const im = idToImage.get(rec.id);
    if (im) sheetItems.push({ label: rec.id, img: im });
  }
  const { sheets } = png.composeSheets(sheetItems, {
    maxW: 420,
    maxItemHeight: 170,
    sheetMaxHeight: o.sheetMaxHeight,
    sheetMaxWidth: 1180,
    labelW: 128,
    gapY: 12,
    gapX: 20,
    columns: 2,
    segmentAspect: 3.4,
    segmentOverlap: 0.32,
  });
  const sheetRecords = [];
  sheets.forEach((s, i) => {
    const name = `formula-sheet-${i + 1}.png`;
    fs.writeFileSync(path.join(outDir, name), s.png);
    const paras = [];
    for (const label of s.items) {
      const rec = formulaRecs.find((r) => r.id === label);
      if (rec) for (const p of rec.paragraphs) if (!paras.includes(p)) paras.push(p);
    }
    paras.sort((a, b) => a - b);
    sheetRecords.push({
      path: name,
      width: s.width,
      height: s.height,
      items: s.items,
      segments: s.segments,
      paragraphs: paras,
      paragraphRange: paras.length ? [paras[0], paras[paras.length - 1]] : null,
    });
  });

  // 6) 源文件留档（--no-copy-source 可跳过；不附原件是合法的）
  const sourceFile = stageSource(input, outDir, o.copySource);

  return {
    doc: { paragraphs: doc.paragraphs.length },
    docStats: doc.stats,
    warnings: [...new Set([...doc.warnings, ...warnings])],
    stats,
    media: [...mediaByTarget.values()],
    sheets: sheetRecords,
    sourceFile,
    rasterBackend,
    textPath: "text.md",
    blocksPath: "blocks.json",
    blockCount: blocksDoc.blockCount,
  };
}

/* ------------------------------------------------------------------ */
/* 图片 / 文本 处理                                                     */
/* ------------------------------------------------------------------ */

function processImage(input, outDir, o) {
  const mediaDir = path.join(outDir, "media");
  ensureDir(mediaDir);
  const raw = fs.readFileSync(input);
  const ext = (path.extname(input) || "").slice(1).toLowerCase();
  const warnings = [];
  let bytes = raw;
  let rasterized = false;
  let note = null;

  if (raster.VECTOR_EXT.has(ext)) {
    const r = raster.rasterizeBatch([{ key: "img", bytes: raw, ext }], { scale: 3 });
    if (!r.backend || !r.out.get("img")) {
      warnings.push(`矢量图栅格化失败：${r.detail || (r.errors[0] && r.errors[0].error)}`);
      return { fatal: "无法栅格化矢量素材（缺后端）", warnings };
    }
    bytes = r.out.get("img");
    rasterized = true;
    note = `栅格化自 ${ext.toUpperCase()}`;
  } else if (png.isPng(raw)) {
    const s = png.sanitizeImage(raw, ext);
    bytes = s.bytes;
    note = s.note;
  }

  let width = null;
  let height = null;
  if (png.isPng(bytes)) {
    const im = png.decodePng(bytes);
    width = im.width;
    height = im.height;
  }
  const outPath = path.join(mediaDir, "FIG01.png");
  fs.writeFileSync(outPath, bytes);

  const text = [
    `# ${path.basename(input)} — 素材说明`,
    "",
    `> 输入为**单张图片**，无文本层。请直接读取 \`media/FIG01.png\`（整图包含题目内容）。`,
    `> 整图属于"页面级"素材：如作为题干配图需按题目实际边界裁剪，并登记为 sources 或 figure。`,
    "",
    `[0001] {{FIG01}}`,
    "",
  ].join("\n");
  fs.writeFileSync(path.join(outDir, "text.md"), text, "utf8");
  const blocksPath = writeSimpleBlocks(outDir, [{ paraIndex: 1, text: "{{FIG01}}", images: ["FIG01"] }]);

  return {
    doc: { paragraphs: 1 },
    docStats: { paragraphs: 1, omml: 0, images: 1 },
    warnings,
    stats: { rasterized: rasterized ? 1 : 0, deduped: 0, sanitized: note ? 1 : 0, missingGlyphSuspects: [], mangledGlyphSuspects: [] },
    media: [{
      id: "FIG01", role: "figure", roleReason: "单图输入", path: "media/FIG01.png",
      from: path.basename(input), mime: "image/png", width, height, sha256: sha256(bytes),
      rasterized, note, suspectedMissingGlyph: false, paragraphs: [1],
    }],
    sheets: [],
    sourceFile: stageSource(input, outDir, o.copySource),
    rasterBackend: raster.probe().backend,
    textPath: "text.md",
    blocksPath,
  };
}

function processText(input, outDir, o) {
  const raw = fs.readFileSync(input, "utf8").replace(/^\uFEFF/, "");
  fs.writeFileSync(path.join(outDir, "text.md"), raw, "utf8");
  // 逐行成段（空行跳过）；纯文本没有图片，blocks 只有 text 字段
  const lines = raw.split(/\r?\n/);
  const blocks = [];
  lines.forEach((t, i) => { if (t.trim()) blocks.push({ paraIndex: i + 1, text: t.replace(/\s+$/g, "") }); });
  const blocksPath = writeSimpleBlocks(outDir, blocks);
  return {
    doc: { paragraphs: lines.length },
    docStats: { paragraphs: lines.length, omml: 0, images: 0 },
    warnings: ["输入为纯文本，无图片素材；若原文含图片链接，请自行取回原图后再作为 assets 交付。"],
    stats: { rasterized: 0, deduped: 0, sanitized: 0, missingGlyphSuspects: [], mangledGlyphSuspects: [] },
    media: [],
    sheets: [],
    sourceFile: stageSource(input, outDir, o.copySource),
    rasterBackend: raster.probe().backend,
    textPath: "text.md",
    blocksPath,
  };
}

/* ------------------------------------------------------------------ */
/* main                                                               */
/* ------------------------------------------------------------------ */

function main(argv) {
  let o;
  try {
    o = parseArgs(argv);
  } catch (e) {
    process.stderr.write(`参数错误：${e.message}\n\n${HELP}`);
    return 2;
  }
  if (o.help || !o.input) {
    process.stdout.write(HELP);
    return o.help ? 0 : 2;
  }

  const input = path.resolve(o.input);
  if (!fs.existsSync(input)) {
    process.stderr.write(`输入不存在：${input}\n`);
    return 2;
  }
  const st = fs.statSync(input);
  if (st.isDirectory()) {
    const files = fs.readdirSync(input).filter((f) => detectKind(path.join(input, f)) !== "unknown");
    process.stderr.write(
      `输入是目录。v1.1 约定「一份材料一个产物」，请逐个文件调用。目录内可用素材：\n` +
      files.map((f) => `  - ${f}`).join("\n") + "\n",
    );
    return 2;
  }

  const kind = detectKind(input);
  if (kind === "doc-legacy") {
    process.stderr.write(
      "老式二进制 .doc 不受支持。请先用 Word/WPS 另存为 .docx，或改用编辑器通道打开后导出。\n",
    );
    return 2;
  }
  if (kind === "unknown") {
    process.stderr.write(
      `本工具的输入层不认识这种素材：${path.extname(input) || "(无扩展名)"}\n` +
      `内置解析只覆盖：docx/docm、常见位图（png/jpg/webp/gif/bmp/tif）、矢量图（wmf/emf/svg）、md/txt。\n` +
      "\n" +
      "**这不是死路**——按 SKILL.md §0.5 走通用兜底（格式无关，下游完全一样）：\n" +
      "  · PDF / PPTX / XLSX / HTML / 扫描件 / 网页 / 平台怪导出\n" +
      "  · 用多模态能力把页面直接读成段落，自己写出 _work/blocks.json，\n" +
      "    位图放进 _work/media/（图类 id 用 FIG 前缀），正文相应位置留 {{Fnnn}} / {{FIGnn}} 占位符；\n" +
      "  · 然后照常：mofang.cjs scaffold → 写公式 → fix → validate → pack。\n" +
      "  · 若手边有 Office 通道，.pptx / .xlsx 也可先让宿主导出成 docx/csv 再回来。\n",
    );
    return 2;
  }

  const outDir = path.resolve(o.out);
  ensureDir(outDir);

  // 旧产物同目录会互相污染：text.md 覆盖是预期行为，但 media/ 需清理避免残留
  const mediaDir = path.join(outDir, "media");
  if (fs.existsSync(mediaDir)) {
    for (const f of fs.readdirSync(mediaDir)) fs.rmSync(path.join(mediaDir, f), { force: true });
  }
  for (const f of fs.readdirSync(outDir)) {
    if (/^formula-sheet-\d+\.png$/.test(f)) fs.rmSync(path.join(outDir, f), { force: true });
  }

  let res;
  try {
    if (kind === "docx") res = processDocx(input, outDir, o);
    else if (kind === "image") res = processImage(input, outDir, o);
    else res = processText(input, outDir, o);
  } catch (e) {
    process.stderr.write(`处理失败：${e.message}\n${e.stack || ""}\n`);
    return 2;
  }
  if (res.fatal) {
    process.stderr.write(`${res.fatal}\n`);
    return 2;
  }

  const byRole = { formula: 0, figure: 0 };
  for (const m of res.media) byRole[m.role] = (byRole[m.role] || 0) + 1;

  const manifest = {
    tool: TOOL,
    version: VERSION,
    input: { path: input, name: path.basename(input), kind },
    outDir: outDir,
    capabilities: {
      rasterBackend: res.rasterBackend,
      rasterDetail: raster.probe().detail,
      rasterizedWith: res.stats.rasterized ? res.rasterBackend : null,
      imageOps: "built-in (零依赖 PNG 编解码/裁白边/拼接)",
    },
    stats: {
      paragraphs: res.docStats.paragraphs,
      paragraphsInTables: res.docStats.paragraphsInTables || 0,
      tables: res.docStats.tables || 0,
      tableRows: res.docStats.tableRows || 0,
      tableCells: res.docStats.tableCells || 0,
      formulas: byRole.formula || 0,
      figures: byRole.figure || 0,
      omml: res.docStats.omml || 0,
      rasterized: res.stats.rasterized,
      deduped: res.stats.deduped,
      sanitized: res.stats.sanitized,
    },
    artifacts: {
      blocks: res.blocksPath || "blocks.json",
      blocksTxt: "blocks.txt",
      text: res.textPath,
      media: "media/",
      formulaSheets: res.sheets.length ? "formula-sheet-*.png" : null,
    },
    text: { path: res.textPath, paragraphs: res.doc.paragraphs },
    source: res.sourceFile,
    media: o.full ? res.media : res.media.map(compactMedia),
    formulaSheets: res.sheets,
    warnings: res.warnings,
    suspectedMissingGlyph: res.stats.missingGlyphSuspects,
    suspectedMangledGlyph: res.stats.mangledGlyphSuspects || [],
    // v1.2.3：**自报检测覆盖范围**。两个列表都为空 ≠ 公式没问题——
    // 「本机字体导致字形异常」有多种形态，检测器只覆盖下面声明的那几种。
    // 换一台机器（字体不同）结果会变，不要沿用上一次的判断。
    glyphChecks: {
      covered: [
        "空心方框（缺失字形的 tofu，任意字号/笔画粗细）",
        "成对小逗点（≤ / ≥ 等关系符被字体回退画成「,,」）",
      ],
      notCovered: [
        "单个字形被画成别的符号（非方框、非成对逗点）",
        "字形本身正确但与原文语义不符",
        "正文（非图片）里的字符编码问题",
      ],
      note: "列表为空只表示「未命中已覆盖的两种形态」；仍建议抽查若干张公式图。",
      backend: res.rasterBackend || null,
    },
    next: [
      "读 blocks.txt（**行式**：段号 / 图片 / 原文，整份可一次读完，不会像 blocks.json 那样被大文件预览截断）；需要表格结构时再读 blocks.json",
      res.sheets.length
        ? `按题目所在段落范围查看 formula-sheet-*.png（共 ${res.sheets.length} 张）；遇到模糊或疑似异常的 {{Fnnn}}，用 node scripts/mofang.cjs inspect --work _work --formula F112 --no-write 定位单图与原文上下文`
        : "本素材无公式图片",
      "按 blocks.txt / blocks.json 切题后生成骨架：node scripts/mofang.cjs scaffold --input _work/blocks.json --manifest _work/manifest.json --out questions.json",
      "先核对逐题摘要：node scripts/mofang.cjs report --input questions.json --md；需要全文时加 --full（完整题干、选项、答案、解析、图位和 issues）",
      "组装/填充完成后：node scripts/mofang.cjs fix --input questions.json --in-place（机械修正，会回吐改了哪几处）",
      "交付前：node scripts/mofang.cjs pack --input questions.json --root <素材目录> --output 录题结果.zip --verify（一条命令完成校验→打包→复验）",
    ],
  };
  writeJson(path.join(outDir, "manifest.json"), manifest);

  if (o.json) {
    process.stdout.write(JSON.stringify({ ok: true, ...manifest }, null, 2) + "\n");
  } else {
    const L = [];
    L.push(`素材类型：${kind}`);
    L.push(`段落：${manifest.stats.paragraphs}（其中表格内 ${manifest.stats.paragraphsInTables}）`);
    L.push(`表格：${manifest.stats.tables} 张 / ${manifest.stats.tableRows} 行 / ${manifest.stats.tableCells} 单元格`);
    L.push(`公式：${manifest.stats.formulas}（含 OMML 直转 ${manifest.stats.omml}）`);
    L.push(`插图：${manifest.stats.figures}`);
    L.push(`矢量栅格化：${manifest.stats.rasterized} 张（后端：${res.rasterBackend || "无"}）`);
    L.push(`去重合并：${manifest.stats.deduped} 处；清理尾随字节：${manifest.stats.sanitized} 个`);
    L.push(`公式对照表：${res.sheets.length} 张`);
    L.push(`输出目录：${outDir}`);
    L.push(`  blocks.txt / blocks.json / text.md / manifest.json / media/ / ${res.sheets.length ? "formula-sheet-*.png / " : ""}${o.copySource ? "sources/" : ""}`);
    if (manifest.warnings.length) {
      L.push(`告警 ${manifest.warnings.length} 条：`);
      for (const w of manifest.warnings.slice(0, 10)) L.push(`  - ${w}`);
    }
    if (res.stats.missingGlyphSuspects.length) {
      L.push(`疑似缺字（渲染成方框）：${res.stats.missingGlyphSuspects.join(", ")}`);
    }
    if ((res.stats.mangledGlyphSuspects || []).length) {
      L.push(`疑似字形回退（成对小逗点，需人工看图核对）：${res.stats.mangledGlyphSuspects.join(", ")}`);
    }
    process.stdout.write(L.join("\n") + "\n");
  }

  const failed = manifest.warnings.some((w) => /栅格化失败|未能转换|不可用/.test(w));
  return failed ? 1 : 0;
}

if (require.main === module) {
  process.exitCode = main(process.argv.slice(2));
}

module.exports = { main };
