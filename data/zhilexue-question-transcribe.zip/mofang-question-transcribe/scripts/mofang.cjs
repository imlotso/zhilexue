#!/usr/bin/env node
"use strict";
/**
 * mofang.cjs — 录题工具薄壳（skill v1.2.9）
 *
 * 为什么需要它：`question-import-tool.cjs` 是上游 build 产物（skill 内无源码、无法修改），
 * 而它的默认 stdout 会逐题回吐 `raw` 与 `typedQuestion` 并用 2 空格缩进 —— 实测一次
 * validate 输出 123,916 B，而唯一有效信息 findings 仅 1,025 B（信噪比 1:121）。
 *
 * 本壳在不改动 bundle 一个字节的前提下：
 *   1. 默认只回吐「摘要视图」：计数 + findings + 有问题的文件 + 每题内容计数
 *   2. `--full` 时原样透传 bundle 的 stdout
 *   3. 补「文档写了但引擎没查」的规则；v1.2.2 起补齐**内容空洞硬闸**——
 *      「切题切错 / 选项丢失」这类"协议合法但内容废掉"的记录，过去一律判 ready，
 *      现在会被判 blocking，避免交出一份看起来成功的错误报告。
 *   4. `pack` 先官方预检、再暂存、打临时 ZIP 并复验；成功后才替换最终文件。
 *   5. `fix` 只改授权内容字段；歧义表达保留并写完整审计侧车。
 *   6. `scaffold` 从 blocks 生成候选 questions.json，并逐块保留来源审计侧车。
 *   7. `report` / `inspect` / `doctor`：逐题核对表 / 素材一条命令总览 / 环境自检
 *
 * 退出码与 bundle 一致：0 无 blocking；1 有逐题 blocking；2 包级/参数/IO 错误
 */
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const crypto = require("node:crypto");
const { spawnSync } = require("node:child_process");

const TOOL = "mofang-import";
const VERSION = "1.2.9";
const BUNDLE = path.join(__dirname, "question-import-tool.cjs");

const HELP = `mofang-import ${VERSION} — 录题工具薄壳（默认只回吐摘要）

用法：
  node scripts/mofang.cjs validate --input F.json [--root DIR] [--full] [--pretty]
  node scripts/mofang.cjs pack     --input F.json --root DIR --output F.zip
                                   [--verify] [--force] [--allow-partial] [--full] [--pretty]
                                   [--media-dir _work/media] [--source-dir DIR]
  node scripts/mofang.cjs fix      --input F.json [--output G.json | --in-place] [--audit-file FILE] [--confirm-generated-todos] [--todo-provenance FILE] [--pretty]
  node scripts/mofang.cjs scaffold --input _work/blocks.json [--manifest _work/manifest.json]
                                   --out questions.json --dataset-id ID [--block-audit FILE]
                                   [--question-regex RE] [--structure-regex RE] [--no-merge-repeat-numbers]
                                   [--title T] [--source-name N] [--pretty]
  node scripts/mofang.cjs report   --input questions.json [--full] [--md] [--max-stem N] [--pretty]
  node scripts/mofang.cjs inspect  --work _work [--formula F112] [--lines N] [--no-write] [--pretty]
  node scripts/mofang.cjs doctor

通用选项：
  --full     回吐底层完整报告（调试用；体积较大）
  --pretty   摘要视图缩进美化（默认单行紧凑 JSON）
  --help     显示本帮助

scaffold：
  从 blocks 生成候选 questions.json，并写出逐块保留原文的 .blocks-audit.json。
  题界、共享材料、卷首范围、重复题号、答案抽取与预填空还原都需对照原件确认；
  blockCoverage.complete 固定为 false，旁车状态不代表覆盖已确认。
  必须提供稳定来源身份：--dataset-id，或 manifest.datasetId / manifest.input.datasetId。

fix：
  只处理 questions[].content 的明确格式问题。身份、来源、分类与既有 issues 不改。
  模糊脚本、相邻公式和不确定命令保留原串；完整 changes/reviews 写到 .fix-audit.json。
  --confirm-generated-todos 仅在调用者已对照原件确认对应字段后，按 scaffold 旁车定向确认工具生成的 TODO。
  --todo-provenance FILE    指向原 scaffold 生成的旁车；默认查找 <输入文件>.todo-provenance.json。

report：
  默认输出摘要逐题表（题干前 N 字、答案前 40 字）；--full 输出完整题干、选项全文、答案、解析和图位/资产路径。
  --full --md 按题输出完整 Markdown 报告；摘要的 --md 仍输出原有 Markdown 表。

inspect：
  读 _work/manifest.json + _work/blocks.json，一条命令给出：素材统计、告警（含疑似缺字 / 字形回退）、
  公式对照表清单（含段落区间）、并写出 **行式** _work/blocks.txt（每行一段，整份可一次读完，
  不会像 50 KB+ 的 JSON 那样只剩 2 KB 预览）。--lines N 可同时回吐前 N 行（默认 0）。

doctor：
  环境自检（Node 版本、平台、矢量栅格化后端、bundle 是否可执行）。

pack：
  包结构/路径先经官方校验；素材暂存后打临时 ZIP 并复验。只有复验通过才替换最终文件。
  --force 不提前删除旧件；--allow-partial 不会用 blocking 候选替换现有交付件。

额外检查（薄壳补，底层引擎没查的）：
  占位符未替换 / 选择题缺选项 / 题干疑似卷首须知（以上 blocking）
  CRLF、\\( \\) 定界符残留、公式命令粘连（\\DeltaV）、选项标签不连续、题号不连续、
  题干重复、填空无答案、提到图但 figures 为空、题干过短（以上 review）
  recordKey 疑似含时间戳（info）
`;

/* ------------------------------------------------------------------ */
/* 参数                                                                */
/* ------------------------------------------------------------------ */

function parseArgs(argv) {
  const sub = argv[0];
  const o = {
    sub, full: false, pretty: false, verify: false, force: false, allowPartial: false,
    inPlace: false, md: false, write: true, maxStem: 60, lines: 0,
    confirmGeneratedTodos: false,
  };
  for (let i = 1; i < argv.length; i += 1) {
    const a = argv[i];
    const next = () => argv[++i];
    if (a === "--input") o.input = next();
    else if (a === "--output") o.output = next();
    else if (a === "--out") o.out = next();
    else if (a === "--root") o.root = next();
    else if (a === "--manifest") o.manifest = next();
    else if (a === "--work") o.work = next();
    else if (a === "--formula") o.formula = next();
    else if (a === "--question-regex") o.questionRegex = next();
    else if (a === "--structure-regex") o.structureRegex = next();
    else if (a === "--title") o.title = next();
    else if (a === "--datasetId") o.datasetId = next();
    else if (a === "--dataset-id") o.datasetId = next();
    else if (a === "--audit-file") o.auditFile = next();
    else if (a === "--todo-provenance") {
      o.todoProvenance = next();
      if (!o.todoProvenance) throw new Error("--todo-provenance 需要文件路径");
    }
    else if (a === "--block-audit") o.blockAudit = next();
    else if (a === "--source-name") o.sourceName = next();
    else if (a === "--media-dir") o.mediaDir = next();
    else if (a === "--source-dir") o.sourceDir = next();
    else if (a === "--max-stem") o.maxStem = Number(next());
    else if (a === "--lines") o.lines = Number(next());
    else if (a === "--full") o.full = true;
    else if (a === "--pretty") o.pretty = true;
    else if (a === "--verify") o.verify = true;
    else if (a === "--force") o.force = true;
    else if (a === "--allow-partial") o.allowPartial = true;
    else if (a === "--no-merge-repeat-numbers") o.noMergeRepeat = true;
    else if (a === "--in-place") o.inPlace = true;
    else if (a === "--confirm-generated-todos") o.confirmGeneratedTodos = true;
    else if (a === "--md") o.md = true;
    else if (a === "--no-write") o.write = false;
    else if (a === "--help" || a === "-h") { o.help = true; }
    else throw new Error(`未知参数：${a}`);
  }
  return o;
}

/* ------------------------------------------------------------------ */
/* 调用底层 bundle                                                     */
/* ------------------------------------------------------------------ */

function runBundle(args) {
  const r = spawnSync(process.execPath, [BUNDLE, ...args], {
    encoding: "utf8",
    maxBuffer: 256 * 1024 * 1024,
  });
  const status = r.error ? 2 : (r.status == null ? 2 : r.status);
  return { status, stdout: r.stdout || "", stderr: r.stderr || "", error: r.error };
}

function parseBundleJson(stdout) {
  const i = stdout.indexOf("{");
  if (i < 0) return null;
  try { return JSON.parse(stdout.slice(i)); } catch { return null; }
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8").replace(/^\uFEFF/, ""));
}

function sha256File(file) {
  return crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

/* ------------------------------------------------------------------ */
/* 额外检查（文档要求但底层未查）                                      */
/* ------------------------------------------------------------------ */

const RE_PLACEHOLDER = /\{\{(?:F\d{3,}|FIG\d{2,}|rId\d+)\}\}/g;
const RE_RECORDKEY_DATE = /(?:\b(?:19|20)\d{2}[-_/]?\d{2}[-_/]?\d{2}\b)|(?:\bT\d{2}:?\d{2}:?\d{2}\b)/;
/** 选择题括号（含全角空白）；用于判断"这题应该带选项" */
const RE_CHOICE_BLANK = /[（(][\s\u3000]*[）)]/;
/** 答案长得像选项字母 = 强证据表明这是选择题 */
const RE_ANSWER_LETTER = /^\s*[A-H](?:\s*(?:[、,，;；/＋+&和及与或])?\s*[A-H]){0,7}\s*$/i;
/** 卷首须知特征词（题干命中即说明切题切到了说明区） */
const RE_PREAMBLE_LIKE = /考生务必|答题卡|本试卷和答题卡|考试结束后，将本试卷|用铅笔把答题卡|写在本试卷上无效/;

/** 只接受由 A-H 组成的纯选项答案（可连续书写或用常见分隔符分开）。 */
function parseChoiceAnswer(answer) {
  const text = String(answer || "").trim();
  if (!RE_ANSWER_LETTER.test(text)) return null;
  const labels = (text.match(/[A-H]/gi) || []).map((label) => label.toUpperCase());
  if (new Set(labels).size !== labels.length) return null;
  return labels;
}

function hasExplicitChoiceAnswer(answer) {
  const labels = parseChoiceAnswer(answer);
  return !!labels && labels.length > 1;
}

/** 返回纯选项答案里没有对应实际选项的标签；不推断答案未提到的漏项。 */
function missingChoiceAnswerOptions(answer, options) {
  const answerLabels = parseChoiceAnswer(answer);
  if (!answerLabels) return [];
  const actualLabels = new Set((options || []).map((option) => String((option && option.label) || "").trim().toUpperCase())
    .filter((label) => /^[A-H]$/.test(label)));
  return answerLabels.filter((label) => !actualLabels.has(label));
}

function contentStrings(q) {
  const out = [];
  const c = (q && q.content) || {};
  if (typeof c.stem === "string") out.push(["content.stem", c.stem]);
  (c.options || []).forEach((o, i) => {
    if (o && typeof o.text === "string") out.push([`content.options[${i}].text`, o.text]);
  });
  if (typeof c.answer === "string") out.push(["content.answer", c.answer]);
  (c.analysis || []).forEach((a, i) => {
    if (a && typeof a.text === "string") out.push([`content.analysis[${i}].text`, a.text]);
  });
  return out;
}

/** 只统计 $...$ 之外的 `\(` `\)` `\[` `\]`（公式内可能是合法 LaTeX，如 \\[2mm]） */
function delimitersOutsideMath(s) {
  const hits = [];
  let i = 0;
  while (i < s.length) {
    const ch = s[i];
    if (ch === "\\") {
      const nx = s[i + 1];
      if (nx === undefined) break;
      if (nx === "$") { i += 2; continue; }                 // \$ 字面美元
      if ("()[]".includes(nx)) hits.push(ch + nx);
      i += 2;
      continue;
    }
    if (ch === "$") {
      const j = s.indexOf("$", i + 1);
      if (j < 0) break;                                     // 未闭合，交给底层报
      i = j + 1;                                            // 跳过整个 $...$
      continue;
    }
    i += 1;
  }
  return hits;
}

/** `\(`→`$` `\)`→`$` `\[`→`$$` `\]`→`$$`（仅限公式之外） */
function convertDelimiters(s, stats, ctx) {
  let out = "";
  let i = 0;
  let inMath = false;
  while (i < s.length) {
    const ch = s[i];
    if (ch === "\\") {
      const nx = s[i + 1];
      if (nx === undefined) { out += ch; i += 1; continue; }
      if (nx === "$") { out += "\\$"; i += 2; continue; }
      if (!inMath && "()[]".includes(nx)) {
        const replacement = (nx === "(" || nx === ")") ? "$" : "$$";
        out += replacement;
        note(ctx, "delimiter", ch + nx, replacement, { start: i, end: i + 2 });
        stats.delimiters += 1;
        i += 2;
        continue;
      }
      out += ch + nx;
      i += 2;
      continue;
    }
    if (ch === "$") { inMath = !inMath; out += ch; i += 1; continue; }
    out += ch;
    i += 1;
  }
  return out;
}

/* --------------------------- LaTeX 命令粘连预检 --------------------------- */
/* 素材里常见 `$\DeltaV$`（命令与后一个字母粘连）：KaTeX 会报 Undefined control sequence
 * \DeltaV 并判 blocking。判据取"高置信度"的一种：
 *   `\Name` 的某个**前缀**本身是已知命令，而 Name 不在已知命令里
 *     \DeltaV  → 前缀 \Delta 已知，\DeltaV 未知 → 粘连
 *     \sinx    → 前缀 \sin   已知，\sinx   未知 → 粘连
 *     \mathcal{F} / \text{气} / \frac{1}{2}   → 命令名后紧跟 { 或空白，正常
 * 该判据几乎不误报，因此只报 review，不阻塞交付。 */
const KATEX_COMMANDS = new Set(("alpha beta gamma delta epsilon varepsilon zeta eta theta vartheta iota kappa lambda mu nu xi omicron pi varpi rho varrho sigma varsigma tau upsilon phi varphi chi psi omega " +
  "Gamma Delta Theta Lambda Xi Pi Sigma Upsilon Phi Psi Omega " +
  "varGamma varDelta varTheta varLambda varXi varPi varSigma varUpsilon varPhi varPsi varOmega " +
  "frac dfrac tfrac cfrac binom dbinom tbinom genfrac atop above choose sqrt " +
  "overbrace underbrace overline underline overrightarrow overleftarrow widehat widetilde widecheck mathring " +
  "left right middle big Big bigg Bigg bigl bigr Bigl Bigr biggl biggr Biggl Biggr langle rangle lvert rvert Vert " +
  "sum prod coprod int iint iiint oint lim limsup liminf max min sup inf det gcd log ln lg exp " +
  "sin cos tan cot sec csc arcsin arccos arctan sinh cosh tanh coth sech csch " +
  "cdot cdots ldots dots vdots ddots " +
  "times div pm mp ast star circ bullet oplus ominus otimes oslash odot " +
  "leq geq leqslant geqslant neq approx sim simeq cong equiv propto ll gg " +
  "subset supset subseteq supseteq in notin ni forall exists nexists neg land lor " +
  "rightarrow leftarrow leftrightarrow Rightarrow Leftarrow Leftrightarrow Longrightarrow Longleftarrow Longleftrightarrow " +
  "uparrow downarrow updownarrow updownarrow mapsto to gets implies iff " +
  "infty partial nabla prime angle triangle square parallel perp mid nmid models top bot vdash dashv " +
  "text textbf textit textrm textsf texttt mathrm mathbf mathit mathsf mathtt mathbb mathcal mathfrak mathscr boldsymbol bm " +
  "vec hat bar dot ddot tilde acute grave check breve " +
  "begin end cases array matrix pmatrix bmatrix vmatrix Vmatrix aligned align gathered split " +
  "quad qquad enspace thinspace negthinspace hspace vspace phantom hphantom vphantom strut rule " +
  "color textcolor overset underset stackrel sub sup Stack " +
  "operatorname mathop mathbin mathrel mathord mathpunct mathopen mathclose mathinner " +
  "displaystyle textstyle scriptstyle scriptscriptstyle limits nolimits nonumber notag " +
  "cancel bcancel xcancel boxed " +
  "degree celsius percent " +
  "ell wp Re Im aleph hbar imath jmath " +
  "lVert rVert lceil rceil lfloor rfloor " +
  "therefore because ") .split(/\s+/).filter(Boolean));

const RE_LATEX_CMD = /\\([A-Za-z]{2,})/g;

/** 找出「LaTeX 命令与后续字母粘连」的写法（如 `\DeltaV`、`\sinx`）。只扫描 $...$ 内部。 */
function detectCommandGlue(text) {
  const hits = [];
  const s = String(text || "");
  const spans = [];
  const re = /\$([^$]*)\$/g;
  let m;
  while ((m = re.exec(s)) !== null) spans.push(m[1]);
  for (const span of spans) {
    RE_LATEX_CMD.lastIndex = 0;
    let c;
    while ((c = RE_LATEX_CMD.exec(span)) !== null) {
      const name = c[1];
      if (KATEX_COMMANDS.has(name)) continue;
      for (let k = name.length - 1; k >= 2; k -= 1) {
        if (KATEX_COMMANDS.has(name.slice(0, k))) { hits.push(`\\${name}`); break; }
      }
    }
  }
  return [...new Set(hits)];
}

/* ------------------------------ 逐题额外检查 ------------------------------ */

function extraFindingsFor(rec) {
  const out = [];
  const key = rec.recordKey || "";
  const q = rec.typedQuestion || rec.raw || {};
  const c = q.content || {};
  const stem = typeof c.stem === "string" ? c.stem : "";
  const options = Array.isArray(c.options) ? c.options : [];
  const hasAnswer = typeof c.answer === "string" && c.answer.trim() !== "";
  const analysisText = (c.analysis || []).map((a) => (a && a.text) || "").join("\n");
  const push = (code, level, field, message) => out.push({ code, level, field, message });

  if (RE_RECORDKEY_DATE.test(key)) {
    push("Q_RECORDKEY_MAYBE_TIMESTAMP", "info", "recordKey",
      `recordKey 疑似含日期/时间（${key}）。协议要求 recordKey 不得包含生成时间戳；若这是来源材料的原始编号可忽略。`);
  }

  for (const [field, text] of contentStrings(q)) {
    const ph = text.match(RE_PLACEHOLDER);
    if (ph) {
      push("Q_UNRESOLVED_PLACEHOLDER", "blocking", field,
        `正文仍有未替换的占位符 ${[...new Set(ph)].join(" ")}：须对照 formula-sheet-*.png 写成 LaTeX（$…$），或把配图挂进 figures。`);
    }
    if (/\r/.test(text)) {
      push("Q_CRLF", "review", field,
        "正文含 CR（CRLF 未归一化）。协议要求只把 CRLF 规范成 LF；可跑 mofang.cjs fix 自动修正。");
    }
    const delims = delimitersOutsideMath(text);
    if (delims.length) {
      push("Q_DELIM_LEFTOVER", "review", field,
        `正文残留 ${[...new Set(delims)].join(" ")} 定界符（在公式之外）：应改写为 $…$ / $$…$$；可跑 mofang.cjs fix 自动修正。`);
    }
    const glue = detectCommandGlue(text);
    if (glue.length) {
      push("Q_LATEX_CMD_GLUE", "review", field,
        `公式里 ${glue.join(" ")} 疑似「命令与后一个字母粘连」（如 \\DeltaV 应为 \\Delta V）。KaTeX 会报 Undefined control sequence 并判 blocking。`);
    }
  }

  /* ---- v1.2.2 内容空洞硬闸：切题切错 / 选项丢失的兜底 ---- */
  const isChoiceBlank = RE_CHOICE_BLANK.test(stem);
  const missingAnswerOptions = missingChoiceAnswerOptions(c.answer, options);
  if ((isChoiceBlank || hasExplicitChoiceAnswer(c.answer)) && options.length === 0) {
    if (missingAnswerOptions.length) {
      push("Q_OPTIONS_MISSING", "blocking", "content.options",
        `答案包含选项标签 ${missingAnswerOptions.join("")}，但 options 为空${isChoiceBlank ? "且题干含选择题括号" : ""}：请对照 _work/blocks.json 补回选项。`);
    } else {
      push("Q_OPTIONS_MAYBE_MISSING", "review", "content.options",
        "题干含括号但 options 为空：若这是选择题说明选项丢了；若括号只是填空占位可忽略。");
    }
  }
  if (options.length > 0) {
    const labels = options.map((o) => String((o && o.label) || "").trim().toUpperCase());
    const expected = labels.map((_, i) => String.fromCharCode(65 + i));
    if (labels.some((l, i) => l !== expected[i])) {
      push("Q_OPTIONS_LABELS_GAPPED", "review", "content.options",
        `选项标签不是从 A 起连续（实际 ${labels.join("")}）：中间可能丢了选项，或把题干里的 A、B 枚举误判成了选项。`);
    }
    if (options.some((o) => !o || typeof o.text !== "string" || !o.text.trim())) {
      push("Q_OPTION_EMPTY", "blocking", "content.options", "存在只有标号没有内容的选项，请补写。");
    }
    if (missingAnswerOptions.length) {
      push("Q_ANSWER_OPTION_MISMATCH", "blocking", "content.answer",
        `纯选项答案引用了实际选项中不存在的标签 ${missingAnswerOptions.join("")}（实际标签 ${labels.join("")}）。请对照原文核对答案与选项。`);
    }
  }
  if (RE_PREAMBLE_LIKE.test(stem) && stem.length < 120 && !isChoiceBlank) {
    push("Q_STEM_LOOKS_LIKE_PREAMBLE", "blocking", "content.stem",
      "题干命中卷首须知特征词（如「考生务必」「答题卡」）：极可能把卷首说明段落当成了题目。请核对切题结果。");
  }
  if (/_{3,}/.test(stem) && !hasAnswer) {
    push("Q_FILL_ANSWER_MISSING", "review", "content.answer",
      "题干含填空符 ____ 但 answer 为 null：请确认材料确实没给答案（没给就不用补）。");
  }
  if (!hasAnswer && /故选|故答案为|答[：:]/.test(analysisText)) {
    push("Q_ANSWER_MAYBE_MISSING", "review", "content.answer",
      "解析里出现「故选 / 故答案为 / 答：」的痕迹但 answer 为 null：答案句可能没被抽出来。");
  }
  if (stem.replace(/[\s\u3000]|\[图\d+\]|[（(]\s*[）)]/g, "").length < 6) {
    push("Q_STEM_TOO_SHORT", "review", "content.stem",
      "题干有效字符过少（< 6）：切题可能切到了标题或表头。");
  }
  if (/如图|图甲|图乙|图丙|下图|图\s*\d|见图/.test(stem) && (c.figures || []).length === 0) {
    push("Q_FIGURE_MAYBE_MISSING", "review", "content.figures",
      "题干提到图，但 figures 为空。按素材来源查：① 预处理路径——核对 manifest.media[] 的 paragraphs 是否覆盖本题段落；" +
      "② 自建 blocks 路径——确认该段块的 images[] 写对了（图类 id 用 FIG 前缀），且图文件在 media/ 下。" +
      "③ 若图是嵌在正文里的（非独立图位），请在正文相应位置写 {{FIGnn}} 占位符。");
  }
  return out;
}

/* --------------------------- 文档级额外检查 --------------------------- */

function docFindingsFor(records) {
  const out = [];
  const push = (code, level, field, message) => out.push({ recordKey: "(整卷)", level, code, field, message });
  const nums = [];
  let allNumeric = records.length > 0;
  for (const r of records) {
    const q = r.typedQuestion || r.raw || {};
    const n = (q.metadata && q.metadata.extra && q.metadata.extra.题号) || null;
    if (n == null || !/^\d+$/.test(String(n))) { allNumeric = false; break; }
    nums.push(Number(n));
  }
  if (allNumeric && nums.length) {
    const sorted = [...nums].sort((a, b) => a - b);
    if (sorted.some((v, i) => v !== i + 1) || sorted[0] !== 1) {
      push("Q_QUESTION_NUMBERS_GAPPED", "review", "metadata.extra.题号",
        `题号不是从 1 起的连续序列（实际 ${sorted.join(",")}）：可能有题目被并进了别的题，或切题起点不对。`);
    }
  }
  const seen = new Map();
  for (const r of records) {
    const q = r.typedQuestion || r.raw || {};
    const stem = ((q.content && q.content.stem) || "").replace(/[\s\u3000]/g, "");
    if (!stem) continue;
    if (seen.has(stem)) {
      push("Q_STEM_DUPLICATE", "review", "content.stem",
        `${r.recordKey} 与 ${seen.get(stem)} 的题干完全相同：可能把同一题切成了两题，或重复题号没归回同题。`);
    } else seen.set(stem, r.recordKey);
  }
  return out;
}

function countsFor(rec) {
  const q = (rec.typedQuestion || rec.raw) || {};
  const c = q.content || {};
  return {
    recordKey: rec.recordKey,
    status: rec.status,
    options: Array.isArray(c.options) ? c.options.length : 0,
    figures: Array.isArray(c.figures) ? c.figures.length : 0,
    hasAnswer: typeof c.answer === "string" && c.answer.trim() !== "",
    hasAnalysis: Array.isArray(c.analysis) && c.analysis.length > 0,
  };
}

/* ------------------------------------------------------------------ */
/* 摘要视图                                                            */
/* ------------------------------------------------------------------ */

function collectProblems(files) {
  const problems = [];
  let checked = 0;
  for (const [kind, list] of [["assets", files && files.assets], ["sources", files && files.sources]]) {
    for (const f of list || []) {
      checked += 1;
      const fs2 = f.findings || [];
      if (f.present === false || fs2.length) {
        problems.push({ kind, id: f.assetId || f.sourceId, present: f.present !== false, findings: fs2 });
      }
    }
  }
  return { checked, problems };
}

/**
 * 底层（KaTeX 等）告警摘要：按「符号」和「归一化消息」聚合计数。
 * 模型真正需要的信息只有"哪些字符没有字形、各出现几次"，此前必须跑 --full（100 KB+）再自己过滤。
 */
function stderrSample(stderr) {
  const lines = String(stderr || "").split("\n").map((s) => s.trim()).filter(Boolean);
  const bySymbol = new Map();
  const byMessage = new Map();
  const uniq = (map, key, make) => {
    if (!map.has(key)) map.set(key, make());
    return map.get(key);
  };
  for (const line of lines) {
    const mUni = line.match(/Unrecognized Unicode character\s*["“'](.+?)["”']\s*\((\d+)\)/);
    const mMet = line.match(/No character metrics for\s*["“'](.+?)["”']/);
    if (mUni || mMet) {
      const ch = String((mUni ? mUni[1] : mMet[1]) || "").trim();
      const cp = mUni ? Number(mUni[2]) : (ch.codePointAt(0) || 0);
      const hex = `U+${cp.toString(16).toUpperCase()}`;
      const rec = uniq(bySymbol, `${ch} ${hex}`, () => ({ symbol: ch, codepoint: hex, count: 0, kinds: {} }));
      rec.count += 1;
      const kind = mUni ? "unrecognized" : "noMetrics";
      rec.kinds[kind] = (rec.kinds[kind] || 0) + 1;
      continue;
    }
    const norm = line.replace(/'[^']*'/g, "'…'").replace(/\b\d{2,}\b/g, "#");
    uniq(byMessage, norm, () => ({ message: norm, count: 0 })).count += 1;
  }
  const out = { count: lines.length };
  if (bySymbol.size) {
    out.bySymbol = [...bySymbol.values()].sort((a, b) => b.count - a.count);
    out.hint = "bySymbol 所列字符在 KaTeX 无字形（如罗马数字 Ⅰ/Ⅱ = U+2160/U+2161）。处置二选一：改写公式（Ⅰ → \\mathrm{I}），或按素材忠实保留并登记 issue 披露。";
  }
  if (byMessage.size) out.byMessage = [...byMessage.values()].sort((a, b) => b.count - a.count).slice(0, 10);
  out.sample = [...new Set(lines)].slice(0, 3);
  return out;
}

function buildSummary(mode, o, rep, status, bundleStderr) {
  const findings = [];
  const counts = [];
  const records = (rep && rep.records) || [];
  const statusCounts = rep ? {
    ready: Number(rep.readyCount) || 0,
    review: Number(rep.reviewCount) || 0,
    blocked: Number(rep.blockedCount) || 0,
  } : null;
  const normalizedStatus = (value) => {
    if (value === "ready") return "ready";
    if (value === "review" || value === "needs-review" || value === "needsReview") return "review";
    if (value === "blocked" || value === "blocking") return "blocked";
    return null;
  };
  for (const r of records) {
    const recordCounts = countsFor(r);
    for (const f of r.findings || []) {
      findings.push({ recordKey: r.recordKey, level: f.level, code: f.code, field: f.field, message: f.message });
    }
    const extraFindings = extraFindingsFor(r);
    for (const f of extraFindings) {
      findings.push({ recordKey: r.recordKey, level: f.level, code: f.code, field: f.field, message: f.message });
    }
    const oldStatus = normalizedStatus(recordCounts.status);
    const nextStatus = extraFindings.some((finding) => finding.level === "blocking")
      ? "blocked"
      : extraFindings.some((finding) => finding.level === "review") && oldStatus === "ready"
        ? "review"
        : oldStatus;
    if (statusCounts && oldStatus && nextStatus && oldStatus !== nextStatus) {
      statusCounts[oldStatus] = Math.max(0, statusCounts[oldStatus] - 1);
      statusCounts[nextStatus] += 1;
    }
    counts.push({ ...recordCounts, status: nextStatus || recordCounts.status });
  }
  for (const f of docFindingsFor(records)) findings.push(f);
  const order = { blocking: 0, review: 1, info: 2 };
  const rank = (l) => (l in order ? order[l] : 3);
  findings.sort((a, b) => rank(a.level) - rank(b.level) || String(a.recordKey).localeCompare(String(b.recordKey)));
  const blockCounts = { blocking: 0, review: 0, info: 0 };
  for (const f of findings) blockCounts[f.level] = (blockCounts[f.level] || 0) + 1;

  const { checked, problems } = collectProblems(rep && rep.files);
  const summary = {
    tool: TOOL,
    mode,
    input: o.input,
    exitCode: status,
  };
  if (o.root) summary.root = o.root;
  if (o.output) summary.output = o.output;
  if (rep && rep.written !== undefined) summary.written = rep.written;
  if (rep && rep.partial !== undefined) summary.partial = rep.partial;
  if (rep && rep.shaBackfilled !== undefined) summary.shaBackfilled = rep.shaBackfilled;
  summary.counts = {
    ready: statusCounts ? statusCounts.ready : null,
    review: statusCounts ? statusCounts.review : null,
    blocked: statusCounts ? statusCounts.blocked : null,
  };
  if (rep && rep.packErrors && rep.packErrors.length) summary.packErrors = rep.packErrors;
  if (rep && rep.error) summary.bundleError = rep.error;
  summary.findingCounts = blockCounts;
  if (findings.length) summary.findings = findings;
  if (counts.length) summary.records = counts;
  summary.files = { checked, problems };
  const warn = stderrSample(bundleStderr);
  if (warn.count) summary.bundleWarnings = warn;
  return summary;
}

function emit(obj, o) {
  process.stdout.write(JSON.stringify(obj, null, o.pretty ? 2 : 0) + "\n");
}

/* ------------------------------------------------------------------ */
/* validate / pack                                                     */
/* ------------------------------------------------------------------ */

function cmdValidate(o) {
  if (!o.input) throw new Error("validate 需要 --input");
  const args = ["validate", "--input", o.input];
  if (o.root) args.push("--root", o.root);
  const r = runBundle(args);
  if (o.full) {
    process.stdout.write(r.stdout);
    if (r.stderr) process.stderr.write(r.stderr);
    return r.status;
  }
  const rep = parseBundleJson(r.stdout);
  if (!rep) {
    process.stdout.write(r.stdout);
    if (r.stderr) process.stderr.write(r.stderr);
    return r.status;
  }
  const summary = buildSummary("validate", o, rep, r.status, r.stderr);
  // blocking 计数以「合并后的 findings」为准（含薄壳补的规则）
  if (summary.findingCounts.blocking > 0 && summary.exitCode === 0) summary.exitCode = 1;
  emit(summary, o);
  return summary.exitCode;
}

/** 取一个（JSON 或 ZIP 的）validate 摘要，用于 pack 前的硬闸 */
function validateSummary(input, root) {
  const args = ["validate", "--input", input];
  if (root) args.push("--root", root);
  const r = runBundle(args);
  const rep = parseBundleJson(r.stdout);
  if (!rep) return null;
  return buildSummary("validate", { input, root }, rep, r.status, r.stderr);
}

function lstatIfExists(target) {
  try { return fs.lstatSync(target); }
  catch (e) { if (e && e.code === "ENOENT") return null; throw e; }
}

/** 校验 root 的现有路径组件，并拒绝 assets/sources 链接或普通文件。 */
function inspectPackRoot(rootValue) {
  const root = path.resolve(rootValue);
  const volumeRoot = path.parse(root).root;
  let current = volumeRoot;
  let missing = false;
  for (const part of root.slice(volumeRoot.length).split(path.sep).filter(Boolean)) {
    current = path.join(current, part);
    if (missing) continue;
    const stat = lstatIfExists(current);
    if (!stat) { missing = true; continue; }
    if (stat.isSymbolicLink()) throw new Error(`拒绝经链接目录使用 pack root：${current}`);
    if (!stat.isDirectory()) throw new Error(`pack root 路径组件不是目录：${current}`);
  }
  const exists = !missing;
  if (exists) {
    for (const name of ["assets", "sources"]) {
      const child = path.join(root, name);
      const stat = lstatIfExists(child);
      if (!stat) continue;
      if (stat.isSymbolicLink()) throw new Error(`pack root 的 ${name} 不能是链接目录：${child}`);
      if (!stat.isDirectory()) throw new Error(`pack root 的 ${name} 必须是目录：${child}`);
    }
  }
  return { root, exists };
}

function ensurePackRootDirectories(root) {
  const inspected = inspectPackRoot(root);
  fs.mkdirSync(inspected.root, { recursive: true });
  for (const name of ["assets", "sources"]) {
    const child = path.join(inspected.root, name);
    if (!lstatIfExists(child)) fs.mkdirSync(child);
  }
  inspectPackRoot(inspected.root);
}

/* ------------------------------------------------------------------ */
/* 资产/原件落地（v1.2.4）                                              */
/*                                                                    */
/* 协议把资产固定在包根 `assets/` 下，而素材实际躺在 `_work/media/`。   */
/* 这一"搬运"以前全靠模型在补丁脚本里手写 copyFileSync —— 文档没写、工具  */
/* 也不管，忘一次就是 Q_ASSET_MISSING(blocking)。任意格式场景下更容易漏。 */
/* 现在 pack 可以自己搬：--media-dir 指素材位图目录，--source-dir 指原件。*/
/* 纪律：只补**缺失**的，绝不覆盖已存在的（不悄悄替换用户已核对的资产）；  */
/*       扩展名对不上时不硬凑（宁可让 Q_ASSET_MISSING 响亮地报出来），     */
/*       而是把"按 id 找到了别的扩展名"如实列出来让人决定。               */
/* ------------------------------------------------------------------ */
function stageMissing(o) {
  const staged = [];
  const mismatches = [];
  const sourceNoPath = [];
  let doc;
  try { doc = readJson(o.input); } catch { return { staged, mismatches, sourceNoPath }; }
  const root = path.resolve(o.root);
  const rootReal = fs.realpathSync(root);

  const imgDirs = [o.mediaDir && path.resolve(o.mediaDir), path.join(root, "media")].filter(Boolean);
  const srcDirs = [o.sourceDir && path.resolve(o.sourceDir), path.join(root, "sources")].filter(Boolean);
  const IMG_EXT = [".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"];

  // 这是写入边界守卫，不替代官方包校验：官方 CLI 在 stage 前判包结构，
  // 此处只防止路径穿越或已存在的目录链接把复制目标带出 root。
  const safeDestination = (rel) => {
    if (typeof rel !== "string" || !rel.trim() || path.posix.isAbsolute(rel) || path.win32.isAbsolute(rel)) {
      throw new Error(`拒绝向包根外写入：非法相对路径 ${String(rel)}`);
    }
    const parts = rel.split(/[\\/]+/);
    if (parts.some((part) => part === ".." || part === "." || !part)) {
      throw new Error(`拒绝向包根外写入：路径含越界/空组件 ${rel}`);
    }
    const dest = path.resolve(rootReal, ...parts);
    const relFromRoot = path.relative(rootReal, dest);
    if (!relFromRoot || relFromRoot === ".." || relFromRoot.startsWith(`..${path.sep}`) || path.isAbsolute(relFromRoot)) {
      throw new Error(`拒绝向包根外写入：${rel}`);
    }
    let current = rootReal;
    for (const part of parts) {
      current = path.join(current, part);
      if (!fs.existsSync(current)) continue;
      const actual = fs.realpathSync(current);
      const actualRel = path.relative(rootReal, actual);
      if (actualRel === ".." || actualRel.startsWith(`..${path.sep}`) || path.isAbsolute(actualRel)) {
        throw new Error(`拒绝经符号链接向包根外写入：${rel}`);
      }
    }
    return dest;
  };

  const copyIfMissing = (rel, dirs, exts) => {
    const dest = safeDestination(rel);
    if (fs.existsSync(dest)) return { status: "exists" };
    const base = path.basename(rel);
    for (const d of dirs) {
      if (!fs.existsSync(d)) continue;
      const exact = path.join(d, base);
      if (fs.existsSync(exact) && fs.statSync(exact).isFile()) {
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        // mkdir 可能穿过并发出现的链接；写入前再检查一次真实目标。
        safeDestination(rel);
        fs.copyFileSync(exact, dest);
        return { status: "staged", from: exact };
      }
    }
    // 按主干名找（扩展名不一致时只报告，不硬凑）
    const stem = base.replace(/\.[^.]+$/, "");
    for (const d of dirs) {
      if (!fs.existsSync(d)) continue;
      for (const e of exts) {
        const alt = path.join(d, stem + e);
        if (fs.existsSync(alt) && fs.statSync(alt).isFile()) return { status: "extMismatch", found: alt };
      }
    }
    return { status: "notFound" };
  };

  for (const a of doc.assets || []) {
    if (!a || typeof a.path !== "string") continue;
    const r = copyIfMissing(a.path, imgDirs, IMG_EXT);
    if (r.status === "staged") staged.push({ kind: "asset", id: a.id, declared: a.path, from: r.from });
    else if (r.status === "extMismatch" || r.status === "notFound") {
      mismatches.push({ kind: "asset", id: a.id, declared: a.path, detail: r.status === "extMismatch" ? `找到了 ${r.found}` : "未在候选目录找到" });
    }
  }
  for (const s of doc.sources || []) {
    if (!s || typeof s.path !== "string") {
      if (s && s.id) sourceNoPath.push(s.id);
      continue;
    }
    const r = copyIfMissing(s.path, srcDirs, [""]);
    if (r.status === "staged") staged.push({ kind: "source", id: s.id, declared: s.path, from: r.from });
    else if (r.status === "notFound") mismatches.push({ kind: "source", id: s.id, declared: s.path, detail: "未在候选目录找到" });
  }
  return { staged, mismatches, sourceNoPath };
}

function cmdPack(o) {
  if (!o.input) throw new Error("pack 需要 --input");
  if (!o.root) throw new Error("pack 需要 --root");
  if (!o.output) throw new Error("pack 需要 --output");
  const rejectPreflight = (preflight, reason) => {
    emit({
      tool: TOOL, mode: "pack", input: o.input, output: o.output, written: false, exitCode: 2,
      reason,
      preflight: preflight || { error: "官方校验输出无法解析" },
    }, o);
  };
  // 附件输入必须在 root 语境中预检；无 root 的官方 validate 会把正常的声明附件判为包级错误。
  // 下方先检查 root 路径，再用隔离 root（新 root）或真实 root（已有 root）执行官方预检。
  if (lstatIfExists(o.output) && !o.force) {
    emit({ tool: TOOL, mode: "pack", input: o.input, output: o.output, written: false, exitCode: 2,
      reason: "输出已存在；如确认替换请加 --force" }, o);
    return 2;
  }

  let rootInfo;
  try { rootInfo = inspectPackRoot(o.root); }
  catch (e) {
    rejectPreflight(null, e.message);
    return 2;
  }

  // 新 root 先用隔离目录复跑官方路径检查；真实 root 的现有链接/文件检查已在上方完成，
  // 后续还会对真实 root 再跑官方校验，临时目录不会替代目标目录的检查。
  let preflight;
  let preflightRoot = rootInfo.root;
  let temporaryRoot = null;
  try {
    if (!rootInfo.exists) {
      temporaryRoot = fs.mkdtempSync(path.join(os.tmpdir(), "mofang-pack-preflight-"));
      fs.mkdirSync(path.join(temporaryRoot, "assets"));
      fs.mkdirSync(path.join(temporaryRoot, "sources"));
      preflightRoot = temporaryRoot;
    }
    preflight = validateSummary(o.input, preflightRoot);
  } finally {
    if (temporaryRoot) fs.rmSync(temporaryRoot, { recursive: true, force: true });
  }
  if (!preflight || preflight.exitCode >= 2 || (preflight.packErrors && preflight.packErrors.length)) {
    rejectPreflight(preflight, "打包前的官方包结构/路径校验失败；未创建目标 root、暂存素材或更改旧交付件");
    return 2;
  }
  try { ensurePackRootDirectories(rootInfo.root); }
  catch (e) {
    rejectPreflight(preflight, e.message);
    return 2;
  }
  preflight = validateSummary(o.input, rootInfo.root);
  if (!preflight || preflight.exitCode >= 2 || (preflight.packErrors && preflight.packErrors.length)) {
    rejectPreflight(preflight, "目标 root 的官方包结构/路径校验失败；未暂存素材或更改旧交付件");
    return 2;
  }

  // 缺素材造成的逐题 exit 1 可以继续暂存；包结构 exit 2 已在上方挡住。
  let stage;
  try {
    stage = stageMissing(o);
  } catch (e) {
    emit({ tool: TOOL, mode: "pack", input: o.input, output: o.output, written: false, exitCode: 2,
      reason: e.message, staged: [] }, o);
    return 2;
  }
  const pre = validateSummary(o.input, o.root);
  // v1.2.2：打包含图前先过「内容空洞」硬闸，否则会把切错的题静默打进包里。
  if (!pre || pre.exitCode >= 2 || (pre.packErrors && pre.packErrors.length)) {
    emit({ tool: TOOL, mode: "pack", input: o.input, output: o.output, written: false, exitCode: 2,
      reason: "素材暂存后的官方包结构/路径校验失败；旧交付件未更改", staged: stage.staged,
      preflight: pre || { error: "官方校验输出无法解析" } }, o);
    return 2;
  }
  if (pre.findingCounts.blocking > 0 && !o.allowPartial) {
    emit({
      tool: TOOL, mode: "pack", input: o.input, output: o.output, written: false, exitCode: 1,
      reason: "打包前校验存在 blocking，已拒绝写输出；修完再打，或加 --allow-partial 生成明确 partial 的包",
      staged: stage.staged.length ? stage.staged : undefined,
      assetMismatches: stage.mismatches.length ? stage.mismatches : undefined,
      counts: pre.counts, findingCounts: pre.findingCounts, findings: pre.findings,
    }, o);
    return 1;
  }
  const output = path.resolve(o.output);
  const outputDir = path.dirname(output);
  fs.mkdirSync(outputDir, { recursive: true });
  const tempDir = fs.mkdtempSync(path.join(outputDir, ".mofang-pack-"));
  const candidate = path.join(tempDir, path.basename(output));
  const args = ["pack", "--input", o.input, "--root", o.root, "--output", candidate];
  if (o.allowPartial) args.push("--allow-partial");
  const r = runBundle(args);
  const rep = parseBundleJson(r.stdout);
  const summary = rep ? buildSummary("pack", o, rep, r.status, r.stderr) : null;
  let status = r.status;
  const vsum = rep && rep.written ? validateSummary(candidate) : null;
  if (summary && rep.written) {
    summary.verify = vsum ? {
      exitCode: vsum.exitCode,
      counts: vsum.counts,
      findingCounts: vsum.findingCounts,
      findings: vsum.findings,
      files: vsum.files,
      bundleWarnings: vsum.bundleWarnings,
    } : { exitCode: 2, error: "ZIP 复验输出无法解析" };
  }
  const recheckOk = !!vsum && vsum.exitCode === 0 && !(vsum.packErrors && vsum.packErrors.length) &&
    vsum.findingCounts.blocking === 0;
  const intentionalPartial = !!vsum && o.allowPartial && !fs.existsSync(output) && !!rep && rep.partial === true &&
    vsum.exitCode === 1 && !(vsum.packErrors && vsum.packErrors.length);
  let promoted = false;
  try {
    if (rep && rep.written && r.status < 2 && (recheckOk || intentionalPartial)) {
      const hadPrevious = fs.existsSync(output);
      if (hadPrevious && !o.force) throw new Error("输出已存在；如确认替换请加 --force");
      // 同目录 rename 在 Windows 与 POSIX 上均直接替换现存文件；失败时旧文件仍在原位。
      fs.renameSync(candidate, output);
      promoted = true;
    } else {
      status = Math.max(status, vsum ? vsum.exitCode : 2);
    }
  } catch (e) {
    status = Math.max(status, 2);
    if (summary) summary.promoteError = e.message;
    else process.stderr.write(`${e.message}\n`);
  }
  if (summary) {
    summary.candidateWritten = !!(rep && rep.written);
    summary.written = promoted;
    summary.promoted = promoted;
  }
  if (summary && rep && rep.written && !promoted && status === 0) status = 2;
  if (summary) summary.exitCode = status;
  if (stage.staged.length && summary) summary.staged = stage.staged;
  if (stage.mismatches.length && summary) summary.assetMismatches = stage.mismatches;
  if (stage.sourceNoPath.length && summary) {
    summary.sourceHint = `sources 里的 ${stage.sourceNoPath.join("、")} 未声明 path，包里不会附原始素材。要附上就：` +
      "把原件放到 <root>/sources/ 下、在 questions.json 的 sources[].path 写 'sources/<文件名>'，" +
      "然后 pack 加 --source-dir <原件目录> 由工具自动搬运。纯文字交付属正常情况，可忽略本条。";
  }
  if (promoted && o.full && rep) {
    const escapedCandidate = JSON.stringify(candidate).slice(1, -1);
    const escapedOutput = JSON.stringify(output).slice(1, -1);
    process.stdout.write(r.stdout.split(escapedCandidate).join(escapedOutput));
    if (r.stderr) process.stderr.write(r.stderr);
    status = r.status;
  } else if (summary) {
    emit(summary, o);
  } else {
    process.stdout.write(r.stdout);
    if (r.stderr) process.stderr.write(r.stderr);
  }
  fs.rmSync(tempDir, { recursive: true, force: true });
  return status;
}

/* ------------------------------------------------------------------ */
/* fix：纯机械修正（v1.2.2 起回吐明细）                                 */
/* ------------------------------------------------------------------ */

const MATHSPAN = /\$([^$]*)\$/g;
const SAMPLE_LIMIT = 12;

function clip(s, n = 90) {
  const t = String(s).replace(/\n/g, "⏎");
  return t.length > n ? `${t.slice(0, n)}…` : t;
}

function note(ctx, kind, before, after, location) {
  if (!ctx || before === after) return;
  const change = { field: ctx.path, kind, before: String(before), after: String(after), ...(location || {}) };
  ctx.audit.push(change);
  if (ctx.samples.length < SAMPLE_LIMIT) {
    ctx.samples.push({ field: ctx.path, kind, before: clip(before), after: clip(after) });
  }
}

function fixInlineMath(body, stats, ctx) {
  let b = body;
  const cjk = /\\(?:text|mathrm|mathbf)\{[^}]*\}|[\u2E80-\u9FFF\uF900-\uFAFF\uFF01-\uFF5E]+/g;
  const beforeCjk = b;
  b = b.replace(cjk, (m) => (m.startsWith("\\") ? m : (stats.cjkWrapped += 1, `\\text{${m}}`)));
  if (b !== beforeCjk) note(ctx, "cjkWrapped", beforeCjk, b);
  const before = b;
  b = b.replace(/[\uFE63\uFF0D\u2212\u2013\u2014]/g, "-");
  if (b !== before) { stats.hyphenNormalized += 1; note(ctx, "hyphenNormalized", before, b); }
  return b;
}

/** 统计未转义的 $ 个数（奇数 = 定界不配平，此时绝不做公式内修正，免得把正文吞进"公式"） */
function countDollars(s) {
  let n = 0;
  for (let i = 0; i < s.length; i += 1) {
    if (s[i] === "\\") { i += 1; continue; }
    if (s[i] === "$") n += 1;
  }
  return n;
}

function ambiguousMath(s) {
  const candidate = convertDelimiters(String(s), { delimiters: 0 });
  const flags = [];
  let adjacentOccurrence = 0;
  for (const match of candidate.matchAll(/(?<=[^\s$])\$\$(?=[^\s$])/g)) {
    adjacentOccurrence += 1;
    const offset = match.index;
    flags.push({
      code: "Q_FIX_ADJACENT_FORMULA",
      token: "相邻美元定界符",
      occurrence: adjacentOccurrence,
      offset,
      offsetBasis: "公式定界候选归一后的字段，0-based UTF-16 code unit",
      context: candidate.slice(Math.max(0, offset - 32), Math.min(candidate.length, offset + match[0].length + 32)),
    });
  }
  for (const match of candidate.matchAll(MATHSPAN)) {
    if (/\^\{[^{}]*\}\^\{[^{}]*\}|_\{[^{}]*\}_\{[^{}]*\}/.test(match[1])) {
      flags.push({ code: "Q_FIX_AMBIGUOUS_SCRIPT", token: match[0] });
    }
  }
  for (const token of detectCommandGlue(candidate)) {
    flags.push({ code: "Q_FIX_AMBIGUOUS_COMMAND", token });
  }
  return flags;
}

function fixText(s, stats, ctx) {
  const raw = String(s);
  const ambiguous = ambiguousMath(raw);
  if (ambiguous.length) {
    ctx.reviews.push({ field: ctx.path, status: "needs-review", items: ambiguous });
    return raw;
  }
  let out = s;
  // 1) CRLF → LF
  const crlf = out.match(/\r/g);
  if (crlf) { stats.crlf += crlf.length; note(ctx, "crlf", s, out.replace(/\r\n?/g, "\n")); }
  out = out.replace(/\r\n?/g, "\n");

  // 2) 公式定界符改写（只动 $...$ 之外的 \( \) \[ \]）
  out = convertDelimiters(out, stats, ctx);

  // 2b) 定界符个数为奇数 → 配平已坏，后续 $...$ 匹配必然错位，故直接返回并登记，交给 validate 报
  if (countDollars(out) % 2 !== 0) {
    stats.dollarImbalance += 1;
    ctx.reviews.push({
      field: ctx.path, status: "needs-review",
      items: [{ code: "Q_FIX_UNBALANCED_DOLLAR", token: "美元定界符数量为奇数；原字段未修改" }],
    });
    return out;
  }

  // 3) $...$ 内部仅做明确格式归一；歧义项已原样保留并写入 review 侧车。
  out = out.replace(MATHSPAN, (m, body) => (body === "" ? m : `$${fixInlineMath(body, stats, ctx)}$`));
  return out;
}

const GENERATED_TODO_CODES = new Set(["Q_TODO_FORMULA", "Q_TODO_FIGURE"]);

function generatedTodoField(question, field) {
  if (!question || !question.content || typeof question.content !== "object") return null;
  if (field === "content.stem") return question.content.stem;
  if (field === "content.answer") return question.content.answer;
  let match = /^content\.options\[(\d+)\]\.text$/.exec(field);
  if (match) {
    const option = (question.content.options || [])[Number(match[1])];
    return option && option.text;
  }
  match = /^content\.analysis\[(\d+)\]\.text$/.exec(field);
  if (match) {
    const section = (question.content.analysis || [])[Number(match[1])];
    return section && section.text;
  }
  return null;
}

function exactIssue(actual, expected) {
  return !!actual && !!expected && actual.code === expected.code && actual.level === expected.level
    && actual.field === expected.field && actual.message === expected.message;
}

function todoProvenancePath(input, explicit) {
  return path.resolve(explicit || `${path.resolve(input)}.todo-provenance.json`);
}

function sameResolvedPath(left, right) {
  const a = path.resolve(left);
  const b = path.resolve(right);
  return process.platform === "win32" ? a.toLowerCase() === b.toLowerCase() : a === b;
}

function planGeneratedTodoConfirmations(doc, outDoc) {
  const provenanceFile = todoProvenancePath(doc.__inputPath, doc.__todoProvenance);
  if (!fs.existsSync(provenanceFile)) {
    throw new Error(`找不到 scaffold 生成旁车 ${provenanceFile}；旧版或来源不明的 TODO 不会自动确认`);
  }
  const provenance = readJson(provenanceFile);
  if (!provenance || provenance.format !== "mofang-question-generated-todo-provenance-v1" || provenance.scaffoldVersion !== VERSION) {
    throw new Error("TODO 来源旁车格式或生成版本不受支持；没有任何输出被写入");
  }
  if (!provenance.datasetId || provenance.datasetId !== doc.datasetId || !Array.isArray(provenance.entries)) {
    throw new Error("TODO 来源旁车与输入 datasetId 不匹配或条目无效；没有任何输出被写入");
  }
  const source = provenance.sourceBlocks;
  if (!source || typeof source.path !== "string" || !/^[a-f0-9]{64}$/.test(source.sha256 || "") || !fs.existsSync(source.path)) {
    throw new Error("TODO 来源旁车缺少可核实的原始 blocks 证据；没有任何输出被写入");
  }
  if (sha256File(source.path) !== source.sha256) {
    throw new Error("原始 blocks SHA-256 与 scaffold 旁车不一致；没有任何输出被写入");
  }
  if (!/^[a-f0-9]{64}$/.test(provenance.scaffoldOutputSha256 || "")) {
    throw new Error("TODO 来源旁车缺少 scaffold 输出 SHA-256；没有任何输出被写入");
  }

  const usedRecords = new Set();
  const plans = [];
  for (const entry of provenance.entries) {
    if (!entry || typeof entry.recordKey !== "string" || !entry.issue || !GENERATED_TODO_CODES.has(entry.issue.code)
      || !Array.isArray(entry.targets) || entry.targets.length === 0) {
      throw new Error("TODO 来源旁车含无效的生成条目；没有任何输出被写入");
    }
    if (usedRecords.has(entry.recordKey)) throw new Error(`TODO 来源旁车重复记录题目 ${entry.recordKey}；没有任何输出被写入`);
    usedRecords.add(entry.recordKey);
    const sourceQuestions = (doc.questions || []).filter((question) => question && question.recordKey === entry.recordKey);
    const targetQuestions = (outDoc.questions || []).filter((question) => question && question.recordKey === entry.recordKey);
    if (sourceQuestions.length !== 1 || targetQuestions.length !== 1) {
      throw new Error(`TODO 来源旁车中的题目 ${entry.recordKey} 不唯一或已缺失；没有任何输出被写入`);
    }
    const question = targetQuestions[0];
    const issueList = Array.isArray(question.issues) ? question.issues : [];
    const matchingIndexes = issueList.map((issue, index) => exactIssue(issue, entry.issue) ? index : -1).filter((index) => index >= 0);
    if (matchingIndexes.length !== 1) {
      throw new Error(`题目 ${entry.recordKey} 的生成 TODO 与来源旁车不再精确且唯一匹配；没有任何输出被写入`);
    }

    const seenFields = new Set();
    const targetEvidence = [];
    const generatedTokens = new Set();
    for (const target of entry.targets) {
      if (!target || typeof target.field !== "string" || !Array.isArray(target.tokens) || target.tokens.length === 0
        || seenFields.has(target.field)) {
        throw new Error(`题目 ${entry.recordKey} 的 TODO 目标字段无效或重复；没有任何输出被写入`);
      }
      seenFields.add(target.field);
      const tokens = [...new Set(target.tokens)];
      if (tokens.some((token) => typeof token !== "string" || !/^\{\{(?:F\d{3,}|FIG\d{2,}|rId\d+)\}\}$/.test(token))) {
        throw new Error(`题目 ${entry.recordKey} 的 TODO 目标占位符无效；没有任何输出被写入`);
      }
      for (const token of tokens) generatedTokens.add(token);
      const beforeText = generatedTodoField(sourceQuestions[0], target.field);
      const afterText = generatedTodoField(question, target.field);
      if (typeof beforeText !== "string" || typeof afterText !== "string") {
        throw new Error(`题目 ${entry.recordKey} 的目标字段 ${target.field} 缺失或不是文本；没有任何输出被写入`);
      }
      const remaining = tokens.filter((token) => afterText.includes(token));
      targetEvidence.push({
        field: target.field,
        tokens,
        beforeSha256: crypto.createHash("sha256").update(beforeText).digest("hex"),
        afterSha256: crypto.createHash("sha256").update(afterText).digest("hex"),
        remaining,
      });
    }
    const remainingGenerated = [];
    const untracked = [];
    for (const [field, text] of contentStrings(question)) {
      for (const match of String(text).matchAll(/\{\{(?:F\d{3,}|FIG\d{2,}|rId\d+)\}\}/g)) {
        const token = match[0];
        const occurrence = { field, token };
        if (generatedTokens.has(token)) remainingGenerated.push(occurrence);
        else untracked.push(occurrence);
      }
    }
    const confirmed = remainingGenerated.length === 0 && untracked.length === 0;
    plans.push({
      question,
      issueIndex: matchingIndexes[0],
      confirmed,
      audit: {
        recordKey: entry.recordKey,
        issue: entry.issue,
        status: confirmed ? "confirmed-and-removed" : "retained-unresolved",
        callerConfirmedAgainstOriginal: true,
        sourceBlocksSha256: source.sha256,
        scaffoldOutputSha256: provenance.scaffoldOutputSha256,
        targets: targetEvidence,
        remainingGenerated,
        untrackedPlaceholders: untracked,
      },
    });
  }
  return plans;
}

function cmdFix(o) {
  if (!o.input) throw new Error("fix 需要 --input");
  const doc = readJson(o.input);
  Object.defineProperty(doc, "__inputPath", { value: o.input, enumerable: false });
  if (o.todoProvenance) Object.defineProperty(doc, "__todoProvenance", { value: o.todoProvenance, enumerable: false });
  const stats = { crlf: 0, delimiters: 0, adjacentDollar: 0, mergedSupSub: 0, cjkWrapped: 0, hyphenNormalized: 0, commandGlueSpaced: 0, dollarImbalance: 0, staleIssueCleared: 0 };
  const ctx = { samples: [], audit: [], reviews: [], path: "" };
  const outDoc = JSON.parse(JSON.stringify(doc));
  const edit = (value, field) => {
    if (typeof value !== "string") return value;
    ctx.path = field;
    return fixText(value, stats, ctx);
  };
  for (let qi = 0; qi < ((outDoc && outDoc.questions) || []).length; qi += 1) {
    const q = outDoc.questions[qi];
    if (!q || !q.content || typeof q.content !== "object") continue;
    const prefix = `questions[${qi}].content`;
    q.content.stem = edit(q.content.stem, `${prefix}.stem`);
    if (Array.isArray(q.content.options)) {
      q.content.options.forEach((option, oi) => {
        if (option && typeof option === "object") option.text = edit(option.text, `${prefix}.options[${oi}].text`);
      });
    }
    q.content.answer = edit(q.content.answer, `${prefix}.answer`);
    if (Array.isArray(q.content.analysis)) {
      q.content.analysis.forEach((item, ai) => {
        if (item && typeof item === "object") item.text = edit(item.text, `${prefix}.analysis[${ai}].text`);
      });
    }
  }

  const generatedTodoPlans = o.confirmGeneratedTodos ? planGeneratedTodoConfirmations(doc, outDoc) : [];
  for (const plan of generatedTodoPlans) {
    if (!plan.confirmed) continue;
    plan.question.issues.splice(plan.issueIndex, 1);
    stats.staleIssueCleared += 1;
  }

  const target = o.inPlace ? o.input : o.output;
  if (!target) throw new Error("fix 需要 --output 或 --in-place");
  const auditFile = o.auditFile || `${target}.fix-audit.json`;
  if (o.confirmGeneratedTodos) {
    const provenanceFile = todoProvenancePath(o.input, o.todoProvenance);
    if (sameResolvedPath(target, provenanceFile) || sameResolvedPath(auditFile, provenanceFile)) {
      throw new Error("输出或 fix 审计路径不能覆盖 TODO 来源旁车；没有任何输出被写入");
    }
  }
  fs.mkdirSync(path.dirname(path.resolve(target)), { recursive: true });
  fs.writeFileSync(target, JSON.stringify(outDoc, null, 2), "utf8");
  fs.mkdirSync(path.dirname(path.resolve(auditFile)), { recursive: true });
  fs.writeFileSync(auditFile, JSON.stringify({
    format: "mofang-question-fix-audit-v1", input: o.input, output: target,
    changes: ctx.audit, reviews: ctx.reviews,
    generatedTodoConfirmations: o.confirmGeneratedTodos ? generatedTodoPlans.map((plan) => plan.audit) : undefined,
  }, null, 2), "utf8");
  const changed = ctx.audit.length;
  emit({
    tool: TOOL, mode: "fix", input: o.input, output: target, exitCode: 0,
    changes: stats,
    changeCount: changed,
    samples: ctx.samples,
    samplesTruncated: ctx.audit.length > ctx.samples.length,
    auditFile,
    reviewCount: ctx.reviews.length,
    reviewSamples: ctx.reviews.slice(0, SAMPLE_LIMIT),
    reviewSamplesTruncated: ctx.reviews.length > SAMPLE_LIMIT,
    generatedTodoConfirmations: o.confirmGeneratedTodos ? generatedTodoPlans.map((plan) => ({
      recordKey: plan.audit.recordKey, status: plan.audit.status,
    })) : undefined,
  }, o);
  return 0;
}

/* ------------------------------------------------------------------ */
/* scaffold：从 blocks.json 预填充一版接近成品的 questions.json          */
/*   v1.2.1 重写；v1.2.2 加固：                                         */
/*     · 跳过卷首「注意事项/考生须知」说明区（否则 1．/2．/3． 被当题号）  */
/*     · 选项归属兜底：裸标签 A{{F001}}、一段多行、允许标签跳号           */
/*     · 每题完整性自检（选择题缺选项、选项标签不连续）                  */
/*     · 正文里既有公式的「命令粘连」预检（\DeltaV）提前到这一步报出      */
/* ------------------------------------------------------------------ */

const DEFAULT_QRE = "^\\s*(\\d{1,3})\\s*[．.、]";
const RE_OPT_LABEL = /^(?:（\s*([A-Ha-h])\s*）|\s*([A-Ha-h])\s*[．.、)）])\s*/; // A． A、 A） （A）
/** 裸标签：`A{{F001}}` / `A[图1]` / `A$...$`（源文档把「．」丢了时会这样） */
const RE_OPT_LABEL_BARE = /^\s*([A-Ha-h])(?=\s*(?:\{\{|\[图|\$))/;
const OPT_LABEL_CELL = /^[A-Ha-h][．.、)）]$/;                                   // 表格单元格里的纯标签
const RE_FIELD = /^【\s*([^】]{1,8})\s*】\s*/;                                     // 【答案】【分析】【解答】【点评】…
const RE_SECTION_BREAK = /参考答案|试题解析|答案与解析|答案解析/;
const RE_QHEAD = /^\s*(\d{1,3})\s*[．.、]\s*(?:（\s*([^）]{1,12}?)\s*分）)?/;     // 题号 + 可选分值
const RE_SUBQUESTION_HEAD = /^[（(]\s*(\d{1,2})\s*[）)]/;
const RE_SUBQUESTION_CHOICE = /(?:单项选择|多项选择|选择题|填(?:写)?(?:正确)?答案标号|选择(?:正确)?答案(?:标号)?)/;
/* ------------------------------------------------------------------ */
/* v1.2.3：通用「结构段 / 栏目名」识别                                   */
/*                                                                    */
/* 设计原则：**不绑定任何一种试卷版式**。素材可能来自 Word 试卷、PDF、   */
/* 网页、扫描件、聊天粘贴、平台导出……版式和栏目写法都不一样。做法是：   */
/*   · 结构段（章节/小节/模块头）：编号家族规则表 + 显式 --structure-regex；*/
/*   · 栏目名：从**本批材料自身**学词表（成对括号是强信号），叠加内建种子；*/
/*     段首的内联图/公式占位符不阻断识别——素材常把「【」本身做成图片。   */
/* ------------------------------------------------------------------ */
/** 内建栏目名种子词表（不完整也没关系，真正起作用的是从材料里学到的） */
const FIELD_VOCAB_SEED = new Set([
  "答案", "参考答案", "答案与解析", "解析", "详解", "分析", "解答", "点评", "评析", "试题解析",
  "考点", "专题", "难度", "题型", "年份", "地区", "来源", "章节", "命题人", "命题意图",
  "思路", "思路分析", "解答", "解", "证", "证明", "误区", "拓展", "变式", "方法", "方法总结",
  "技巧", "说明", "注", "注意事项", "小结", "总结", "归纳", "审题", "关键",
]);
/** 结构段编号家族：一级（章节/大题） */
const STRUCT_L1 = /^(?:[一二三四五六七八九十]{1,3}\s*[、.．]|第\s*[一二三四五六七八九十\d]{1,3}\s*(?:部分|章|节|卷|编|篇)|(?:Chapter|Section|Part|Unit|Module|Lesson)\b)/i;
/** 结构段非编号家族：模块/选考/例题等（二级） */
const STRUCT_MODULE = /^(?:(?:选修|必修|模块|专题|实验)\s*[\d一二三四五六七八九十]{1,2}|[ⅠⅡⅢⅣⅤⅥⅦⅧ]\s*[、.．]?|第\s*\d{1,2}\s*[讲题]|例\s*\d{1,3}|【[^】]{1,16}】\s*(?:[（(]\s*\d+\s*分\s*[）)])?[。．.]?$)/;
const STRUCT_SENT_END = /[。！？；;]/;
/** 括号里的中文数字编号（章节/小节）：**中文数字 = 章节头，阿拉伯数字 = 小问**，这是中文排版惯例 */
const STRUCT_PAREN_CN = /^[（(]\s*([一二三四五六七八九十]{1,3})\s*[）)]([\s\S]*)$/;
const RE_CN_SECTION_PREFIX = /^[（(]\s*[一二三四五六七八九十]{1,3}\s*[）)]/;
const RE_SECTION_KIND = /^(?:选考题|选考|必做题|必做|非选择题|选择题|填空题|计算题|实验题|附加题|综合题|问答题|解答题)(?=\s|$|[：:，,、（(])/;
const RE_SECTION_TITLE_DELIMITER = /^(?:选考题|选考|必做题|必做|非选择题|选择题|填空题|计算题|实验题|附加题|综合题|问答题|解答题)(?:\s*(?:[：:，,、]|共\s*\d+\s*分|请|考生|任选|作答))/;
const RE_SECTION_SCOPE = /选考|选做|必做|非选择题|选择题|填空题|计算题|实验题|附加题|综合题|问答题|解答题/;
const RE_SECTION_INSTRUCTION = /考生|任选|每科|作答|共\s*\d+\s*分|计\s*\d+\s*分/;
const RE_LEAD_ARTIFACT = /^(?:\{\{F\d{3,}\}\}|\{\{FIG\d{2,}\}\})+/;                 // 段首内联图/公式
const RE_FIELD_LOOSE = /^\s*([^】〕〗\[\]（）()【〔〖：:，。、；;]{1,12})\s*(?:[】〕〗\]）)]|[：:])\s*/;
const RE_FIELD_STRONG = /^\s*[【〔〖\[]\s*([^】〕〗\]]{1,16})\s*[】〕〗\]]\s*/;

/** 从「成对括号」这种强形式里学栏目名词表——素材常只在一部分段落保留括号 */
function learnLabelVocab(units) {
  const vocab = new Set(FIELD_VOCAB_SEED);
  for (const u of units) {
    if (u.kind !== "p" || u.inTable) continue;
    let t = String(u.text || "").trim();
    const lead = t.match(RE_LEAD_ARTIFACT);
    if (lead) t = t.slice(lead[0].length);
    const m = t.match(RE_FIELD_STRONG);
    if (!m) continue;
    const close = t.match(/[】〕〗\]]/);
    const rest = close ? t.slice(t.indexOf(close[0]) + 1).trim() : "";
    const restIsJustScore = !rest || /^[（(]?\s*\d+\s*分\s*[）)]?[。．.]?$/.test(rest);
    // 「【选修3-3】（12分）」这种是结构段，别把它学成栏目名
    if (restIsJustScore && !FIELD_VOCAB_SEED.has(normFieldName(m[1]))) continue;
    // `[2]打F点时…` 里的 `[2]` 是填空编号，不是栏目名——词表只收中文词
    const k = normFieldName(m[1]);
    if (!/[\u2E80-\u9FFF]/.test(k) && !FIELD_VOCAB_SEED.has(k)) continue;
    vocab.add(k);
  }
  return vocab;
}

/**
 * 判定一个段落是不是「结构段（章节/小节/模块头）」。返回 {level, text} 或 null。
 * 判据全部是**版式无关的排版惯例**，不针对某一份试卷：
 *   · 一级：`一、` / `第X章` / `Part N` 这类章节编号；
 *   · 二级：`（一）` 中文数字编号（**阿拉伯数字的「（1）」是小问编号，不是章节头**）、
 *           模块/选考头（`选修3-3`、`【选修3-3】（12分）`、`Ⅰ`、`例1`、`第1讲`）。
 *   · 护栏：章节头必须**短**且**不带正文标点/填空/公式占位符**——
 *           「（1）求玻璃的折射率」这种小问不会被误判。
 *   · 括号段若括号后还有实质正文（或括号里就是「答案/解析」这类栏目名），判为**栏目**不是结构段。
 */
function classifyStructure(raw, labelVocab) {
  const rawText = String(raw || "").trim();
  const t = rawText.replace(/\s+/g, " ").trim();
  if (!t) return null;
  const sectionPrefix = t.match(RE_CN_SECTION_PREFIX);
  const sectionTitle = sectionPrefix ? t.slice(sectionPrefix[0].length).trimStart() : "";
  if (sectionPrefix && RE_SECTION_TITLE_DELIMITER.test(sectionTitle) && RE_SECTION_INSTRUCTION.test(sectionTitle)) {
    return { level: 2, text: rawText, boardScope: true };
  }
  if (t.length > 160) return null;
  const probe = t.replace(/[。．.]\s*$/, "");
  const inner = (t.match(/^[【〔〖\[]\s*([^】〕〗\]]{1,16})\s*[】〕〗\]]/) || [])[1];
  const close = t.match(/[】〕〗\]]/);
  const rest = close ? t.slice(t.indexOf(close[0]) + 1).trim() : "";
  if (inner) {
    // 括号后还有实质正文 → 是栏目（【答案】…【考点】…）；
    // 括号后为空、或只有「（12分）」这种分值 → 是结构段（前提：括号里不是栏目名）。
    const restIsJustScore = !rest || /^[（(]?\s*\d+\s*分\s*[）)]?[。．.]?$/.test(rest);
    if (!restIsJustScore) return null;
    if (FIELD_VOCAB_SEED.has(normFieldName(inner))) return null;
    return { level: 2, text: t };
  }
  if (STRUCT_L1.test(probe)) return { level: 1, text: t };
  if (STRUCT_MODULE.test(probe)) return { level: 2, text: t };
  const cn = probe.match(STRUCT_PAREN_CN);
  if (cn) {
    const title = cn[2].trim();
    const looksLikeHead = title.length <= 24 && !/[，,。；;、]/.test(title) && !/\{\{|_{2,}/.test(title);
    if (looksLikeHead) return { level: 2, text: t };
  }
  return null;
}

function isAmbiguousSectionNote(raw) {
  const text = String(raw || "").trim();
  const prefix = text.match(RE_CN_SECTION_PREFIX);
  const title = prefix ? text.slice(prefix[0].length).trimStart() : "";
  return !!prefix && RE_SECTION_SCOPE.test(title) && RE_SECTION_TITLE_DELIMITER.test(title) &&
    !(RE_SECTION_INSTRUCTION.test(title));
}

function isTopLevelNumberedSection(raw) {
  const text = String(raw || "").trim();
  const prefix = text.match(RE_CN_SECTION_PREFIX);
  return !!prefix && RE_SECTION_KIND.test(text.slice(prefix[0].length).trimStart());
}

function isSectionNoteAdjacent(units, index, questionRegex) {
  for (let nextIndex = index + 1; nextIndex < units.length && nextIndex <= index + 3; nextIndex += 1) {
    const next = units[nextIndex];
    if (next.kind !== "p") return false;
    const text = String(next.text || "").trim();
    if (!text) continue;
    questionRegex.lastIndex = 0;
    return questionRegex.test(text);
  }
  return false;
}

/** 像不像栏目名：中文词（或已学到的词）才是栏目名；`[2]`、`（1）`、`ii` 这类是**编号**，不是栏目 */
function isLabelToken(s, labelVocab) {
  const k = normFieldName(s);
  if (!k) return false;
  if (labelVocab && labelVocab.has(k)) return true;
  return /[\u2E80-\u9FFF]/.test(k);
}

/**
 * 栏目名识别（在段首内联占位符被剥离之后再判）。
 * 返回 {label, rest, droppedLead} 或 null。
 * · 括号族【】〔〕〖〗[] 里的**中文词** → 栏目名（`[2]` 是填空编号，不是栏目）；
 * · 只剩收尾括号（`详解】`，素材把「【」做成了图片）或「X：」→ 要求命中词表，
 *   这样「由题意可知：…」这类正文句不会被误判。
 */
function matchFieldLabel(text, labelVocab) {
  let t = String(text || "");
  const lead = t.match(RE_LEAD_ARTIFACT);
  const droppedLead = lead ? lead[0] : "";
  if (lead) t = t.slice(lead[0].length);
  let m = t.match(/^\s*[【〔〖\[]\s*([^】〕〗\]]{1,16})\s*[】〕〗\]]\s*/);
  if (m && isLabelToken(m[1], labelVocab)) return { label: normFieldName(m[1]), rest: t.slice(m[0].length), droppedLead };
  m = t.match(RE_FIELD_LOOSE);
  if (m && isLabelToken(m[1], labelVocab) && labelVocab.has(normFieldName(m[1]))) {
    return { label: normFieldName(m[1]), rest: t.slice(m[0].length), droppedLead };
  }
  return null;
}

const RE_ORIGIN = /（\s*(?:19|20)\d{2}\s*[•·][^）]{1,12}）/;                       // （2015•浙江）
/** 卷首说明区标题（「注意事项」等）：命中的段落起、到第一个板块标题止，一律不参与题号识别 */
const RE_PREAMBLE_HEAD = /^\s*(?:[一二三四五六七八九十]+\s*[、.．]\s*)?(?:注意事项|考生须知|考生注意|考试说明|答题须知|答题说明)\s*[:：]?\s*$/;
/** 判断题干里的「A、B两点…」式枚举，避免被当成选项 A */
const RE_STEM_ENUM = /^[A-Ha-h](\s*[、,，．.]?\s*[\u2E80-\u9FFF])/;
// （选择题括号 RE_CHOICE_BLANK 与答案字母 RE_ANSWER_LETTER 在上文已定义，此处复用）
// 填空不能靠一条正则：解析卷「上一处空档的收尾　」与「下一处空档的开头　」会自己配成一对，
// 把中间整段正文吞掉（v1.2.1 实测踩到）。改为对题干里的 全角空格 从左到右贪心配对。
const BLANK_CHAR = "\u3000";
// 答案句：`故选：B。` / `故答案为：…` / `答：…`。可能独占一段，也可能跟在解析正文同一段的末尾。
const ANSWER_MARK_RE = /(故选|故答案为|答)[：:]\s*([\s\S]*)$/;
const isAnswerSentence = (tail) => !!tail && !/[。．][\s\S]+/.test(tail); // 「。」后还有正文 → 不是答案句
const ANALYSIS_FIELD_NAMES = new Set(["分析", "解答", "解析", "详解", "点评"]);
const META_FIELD_NAMES = new Set(["考点", "专题", "难度", "题型", "年份", "地区", "来源", "章节"]);
const ANSWER_FIELD_NAME = "答案";

function normFieldName(s) {
  return String(s || "").replace(/\s+/g, "");
}

function mimeOf(p) {
  const e = String(p || "").toLowerCase();
  if (e.endsWith(".jpg") || e.endsWith(".jpeg")) return "image/jpeg";
  if (e.endsWith(".webp")) return "image/webp";
  return "image/png";
}

function stripExt(p) {
  return path.basename(String(p || "unknown-dataset")).replace(/\.[A-Za-z0-9]{1,5}$/, "");
}

/**
 * 段落是不是「选项段」。是则返回 [{label, text}]（text 为空串 = 标签独立成段，正文在后续段落）。
 * v1.2.2 放宽为：
 *   · 支持裸标签（`A{{F001}}`，源文档丢了「．」）
 *   · 支持一个段落里多行选项（按 \n 也切）
 *   · 标签要求**严格递增**、且首个不早于 expectLabel（中间丢选项交给完整性自检报出）
 * 仍保留「题干里的 A、B两点… 不算选项」的护栏。
 */
function parseOptionParagraph(text, expectLabel) {
  const pieces = String(text).split(/[\t\n]/).map((s) => s.trim()).filter(Boolean);
  if (!pieces.length) return null;
  const out = [];
  for (const piece of pieces) {
    let m = piece.match(RE_OPT_LABEL);
    if (!m) m = piece.match(RE_OPT_LABEL_BARE);
    if (!m) return null;
    const label = (m[1] || m[2]).toUpperCase();
    out.push({ label, text: piece.slice(m[0].length).trim() });
  }
  // 单段单条的额外护栏：`A、B两处弧长均为…` 是题干枚举，不是选项 A
  if (out.length === 1 && out[0].text && RE_STEM_ENUM.test(out[0].text)) return null;
  if (out[0].label < expectLabel) return null;
  for (let i = 1; i < out.length; i += 1) {
    if (out[i].label.charCodeAt(0) <= out[i - 1].label.charCodeAt(0)) return null;
  }
  return out;
}

/** 仅定位明确要求选项作答的小问；不满足边界证据时原位保留并提示复核。 */
function planSubquestionOptions(group, units, labelVocab) {
  const inlineIndices = new Set();
  const reviews = [];
  if (!group.segs.length) return { inlineIndices, reviews };

  let inAnswer = false;
  let answerText = "";
  for (const [start, end] of group.segs) {
    for (let i = start; i < end; i += 1) {
      const unit = units[i];
      if (unit.kind !== "p" || unit.inTable) continue;
      const text = String(unit.text || "").trim();
      const field = matchFieldLabel(text, labelVocab);
      if (field) {
        inAnswer = /^(?:参考)?答案$/.test(field.label);
        if (inAnswer && field.rest) answerText += ` ${field.rest}`;
      } else if (inAnswer) answerText += ` ${text}`;
    }
  }
  const answerNumbers = Array.from(answerText.matchAll(/[（(]\s*(\d{1,2})\s*[）)]/g), (match) => Number(match[1]));
  const compoundAnswer = answerNumbers.length >= 2 && answerNumbers.every((number, index) =>
    index === 0 || number > answerNumbers[index - 1]);

  const [stemStart, stemEnd] = group.segs[0];
  const heads = [];
  for (let i = stemStart + 1; i < stemEnd; i += 1) {
    const unit = units[i];
    if (unit.kind !== "p" || unit.inTable) continue;
    const text = String(unit.text || "").trim();
    if (matchFieldLabel(text, labelVocab)) break;
    const match = text.match(RE_SUBQUESTION_HEAD);
    if (match) heads.push({ index: i, number: Number(match[1]), text, paraIndex: unit.paraIndex, sourceIndex: unit.sourceIndex });
  }

  for (const head of heads) {
    if (!RE_SUBQUESTION_CHOICE.test(head.text)) continue;
    const nextHead = heads.find((candidate) => candidate.index > head.index && candidate.number === head.number + 1);
    const limit = nextHead ? nextHead.index : stemEnd;
    const candidateIndices = [];
    const labels = [];
    let expected = "A";
    let continuousToNextHead = !!nextHead;
    for (let i = head.index + 1; i < limit; i += 1) {
      const unit = units[i];
      if (unit.kind !== "p" || unit.inTable) { continuousToNextHead = false; break; }
      const text = String(unit.text || "").trim();
      if (!text) continue;
      if (matchFieldLabel(text, labelVocab)) { continuousToNextHead = false; break; }
      const pieces = parseOptionParagraph(text, expected);
      if (!pieces || pieces.some((piece) => !piece.text.trim())) { continuousToNextHead = false; break; }
      candidateIndices.push(i);
      for (const piece of pieces) {
        labels.push(piece.label);
        expected = String.fromCharCode(piece.label.charCodeAt(0) + 1);
      }
    }
    if (labels.length < 2) continue;

    const contiguous = labels.every((label, index) => label === String.fromCharCode(65 + index));
    const consecutiveHeads = heads.every((candidate, index) =>
      index === 0 || candidate.number === heads[index - 1].number + 1);
    const answerMatchesSubquestions = compoundAnswer && answerNumbers.length === heads.length &&
      consecutiveHeads && answerNumbers.every((number, index) => number === heads[index].number);
    const hasLaterSubquestion = continuousToNextHead && !!nextHead && nextHead.index > candidateIndices[candidateIndices.length - 1];
    if (answerMatchesSubquestions && hasLaterSubquestion && contiguous) {
      for (const index of candidateIndices) inlineIndices.add(index);
    } else {
      reviews.push({
        headingParaIndex: head.paraIndex,
        headingSourceIndex: head.sourceIndex,
        optionsParaIndex: units[candidateIndices[0]].paraIndex,
        optionsSourceIndex: units[candidateIndices[0]].sourceIndex,
        reason: !answerMatchesSubquestions ? "答案编号与题干小问未形成完整对应" : !hasLaterSubquestion ? "选项后未发现连续编号的下一小问边界" : "选项标签不连续",
      });
    }
  }
  return { inlineIndices, reviews };
}

/** 从解析正文里剔出答案句。只动答案句本身：独占一段的删整段，跟在段末的只切尾，
 *  绝不从该段起截断（题中间可能出现「故选：（D）。」）。`故答案为：`/`答：` 的续段一并收进答案。 */
function stripAnswerSentences(paras) {
  const kept = [];
  const picked = [];
  let tailMode = false;
  for (const raw of paras) {
    const t = String(raw).trim();
    if (!t) continue;
    if (tailMode) { picked.push(t); continue; }
    const m = t.match(ANSWER_MARK_RE);
    if (!m) { kept.push(t); continue; }
    const head = t.slice(0, m.index).trim();
    const val = m[2].trim().replace(/[。．]$/, "");
    if (!isAnswerSentence(m[2].trim())) { kept.push(t); continue; } // 判不准就别动
    if (head) kept.push(head);
    if (m[1] === "故选") { if (val) picked.push(val); }
    else { tailMode = true; if (val) picked.push(val); }
  }
  return { kept, picked };
}

/** 答案里是否提到这串选项字母（按非字母边界比，避免 CABDE 里误认 CD） */
function answerMentionsLetters(answer, letters) {
  const a = String(answer || "").replace(/[#＃]/g, " ");
  if (!a || !letters) return false;
  return new RegExp(`(?:^|[^A-Za-z])${letters}(?:$|[^A-Za-z])`).test(a);
}

/**
 * 剔除「与答案重复」的选项结论句（`故选D。`）。
 * 答案已经单独存在 content.answer 里，正文末尾再写一遍属冗余；
 * **只有结论文里的字母确实出现在答案里**才删——材料自相矛盾时原样保留，让人看得见。
 * 两种位置都处理：独占一段的整段删；跟在段末的只切掉该小句（保留句号）。
 */
function stripDuplicateChoiceConclusions(paras, answer) {
  const kept = [];
  const dropped = [];
  for (const p of paras) {
    const t = String(p);
    const m = t.match(/^\s*故选\s*[:：]?\s*([A-Ha-h]{1,8})\s*[。．.]?\s*$/);
    if (m && answerMentionsLetters(answer, m[1].toUpperCase())) { dropped.push(m[0].trim()); continue; }
    kept.push(t);
  }
  if (kept.length) {
    const i = kept.length - 1;
    const t = kept[i];
    const m = t.match(/[，,]\s*故选\s*[:：]?\s*([A-Ha-h]{1,8})\s*[。．.]\s*$/);
    if (m && answerMentionsLetters(answer, m[1].toUpperCase())) {
      kept[i] = `${t.slice(0, m.index)}。`;
      dropped.push(m[0].trim());
    }
  }
  return { kept, dropped };
}

/**
 * 解析卷题干填空处理（对"忠实转写"的唯一例外）。
 * 形态是「全角空格成对夹住内容」：夹实义内容 → 还原为 ____ 并把值抽出；
 * 只夹空白（空白卷形态）→ 归一化为 ____。选择题括号（　　）按缩进/括号上下文排除。
 * 实现要点：从左到右贪心配对，绝不用「任意两个 全角空格」当定界符（否则相邻两处空档互吞）。
 */
function restoreStemBlanks(src) {
  const s = String(src);
  const marks = [];
  for (let i = 0; i < s.length; i += 1) {
    if (s[i] !== BLANK_CHAR) continue;
    if (i === 0 || s[i - 1] === "\n") continue;      // 段首全角空格按缩进处理，不作填空定界
    marks.push(i);
  }
  if (marks.length < 2) return { text: s, values: [], normalized: 0 };
  const values = [];
  let normalized = 0;
  let out = "";
  let cursor = 0;
  for (let k = 0; k + 1 < marks.length; k += 2) {
    const a = marks[k];
    const b = marks[k + 1];
    const inner = s.slice(a + 1, b);
    const before = s[a - 1];
    const after = s[b + 1];
    const isChoiceParen = (before === "（" || before === "(") && (after === "）" || after === ")");
    if (isChoiceParen) continue;                      // 选择题括号：原样保留
    if (!inner.replace(/[\t \u3000]/g, "").length) normalized += 1;
    else values.push(inner.trim());
    out += s.slice(cursor, a) + "____";
    cursor = b + 1;
  }
  out += s.slice(cursor);
  return { text: out, values, normalized };
}

/**
 * 定位「卷首说明区」：从「注意事项/考生须知」一段起，到文档里第一个板块标题为止。
 * 该区间内的所有行都不参与题号识别 —— 否则卷首分条的「1．2．3．」会被当成第 1/2/3 题
 * （v1.2.1 实测：真实题干与选项整段丢失，且因"重复题号归回同题"而**不出任何告警**）。
 */
function findPreambleRange(units, isSectionHead) {
  let start = -1;
  const scanLimit = Math.min(units.length, 60);
  for (let i = 0; i < scanLimit; i += 1) {
    const u = units[i];
    if (u.kind !== "p" || u.inTable) continue;
    if (RE_PREAMBLE_HEAD.test((u.text || "").trim())) { start = i; break; }
  }
  if (start < 0) return null;
  for (let i = start + 1; i < units.length; i += 1) {
    const u = units[i];
    if (u.kind !== "p" || u.inTable) continue;
    if (isSectionHead((u.text || "").trim())) return { start, end: i, bounded: true };
  }
  // 找不到板块标题：保守取其后 15 个段落，并标记未定界（输出告警让模型复核）
  // 边界不明时只隔离标题本身。后续段落仍参与候选切题，并在 blocks-audit
  // 里逐块标记待核，不能用固定段数猜测并丢弃可能的真实题目。
  return { start, end: start + 1, bounded: false };
}

function scaffold(o) {
  if (!o.input) throw new Error("scaffold 需要 --input（blocks.json）");
  if (!o.out) throw new Error("scaffold 需要 --out");
  const blocksDoc = readJson(o.input);
  const qre = new RegExp(o.questionRegex || DEFAULT_QRE);

  // 媒体清单（可选）：拿 role / paragraphs 用来挂图
  let manifest = null;
  if (o.manifest && fs.existsSync(o.manifest)) manifest = readJson(o.manifest);
  const mediaById = new Map();
  for (const m of (manifest && manifest.media) || []) mediaById.set(m.id, m);

  // v1.2.4：**段块自带的 images[] 与 manifest 是一等来源**。
  // v1.2.3 只认 manifest.media[].paragraphs —— 于是文档 §0.5「自己产出 blocks」这条路
  // （PDF/截图/任意来源直读，常常没有 manifest）会**静默丢掉所有插图**：
  // 题干若没写「如图/图甲」这类字样，连 Q_FIGURE_MAYBE_MISSING 都不会响，
  // 结果是「丢图 + 全绿」——正是本 skill 最该避免的失败形态。
  //
  // 但**不能照单全收**：extract-material 写的 images[] 把公式图（Fxxx）也包进去了，
  // 全收会让每道含公式的题多挂一堆「插图」并污染 assets。所以只认**图类 id**：
  //   · manifest 里已有的 → 以 manifest 的 role 为准（role==="formula" 一律不收）；
  //   · manifest 里没有的（自建 blocks 场景）→ 只认 FIG 前缀，与文档 §0.5 的写法定死。
  let figuresFromBlocks = 0;
  for (const b of blocksDoc.blocks || []) {
    const blockParas = b.type === "tbl"
      ? (b.rows || []).flatMap((row) => row.flat())
      : [b];
    for (const para of blockParas) {
      for (const id of para.images || []) {
        if (!id) continue;
        const known = mediaById.get(id);
        if (known) {
          if (known.role && known.role !== "figure") continue;   // 公式/其它角色：不是插图
          const ps = known.paragraphs || [];
          if (!ps.includes(para.paraIndex)) known.paragraphs = [...ps, para.paraIndex];
          continue;
        }
        if (!/^FIG/i.test(id)) continue;                          // 未知 id 只认 FIG 前缀
        mediaById.set(id, {
          id, role: "figure",
          path: `media/${id}.png`,
          paragraphs: [para.paraIndex],
          fromBlocks: true,
        });
        figuresFromBlocks += 1;
      }
    }
  }

  // 1) 展平成「单元」序列。只有表格块写 type:"tbl"，段落块没有 type 字段。
  const units = [];
  for (const [sourceIndex, b] of (blocksDoc.blocks || []).entries()) {
    if (b.type === "tbl") units.push({ kind: "tbl", sourceIndex, raw: b, role: b.role, tableId: b.tableId, rows: b.rows || [] });
    else units.push({ kind: "p", sourceIndex, raw: b, paraIndex: b.paraIndex, text: b.text || "", images: b.images || [], inTable: !!b.inTable });
  }
  // 首段是否当"文档标题"跳过：**仅当它不像题号行时才跳过**。
  // 纯文本/粘贴素材的第一行常常就是第 1 题（v1.2.1 会把它当标题吞掉 → 第 1 题题干变空）。
  const firstText = ((units[0] || {}).text || "").trim();
  const docTitle = (firstText && firstText.length <= 100 && !qre.test(firstText)) ? firstText : "";
  // v1.2.3：栏目名词表从本批材料自身学（成对括号是强信号）+ 内建种子；
  //         外部可用 --structure-regex 指定自家版式的结构段形态。
  const labelVocab = learnLabelVocab(units);
  const userStructRe = o.structureRegex ? new RegExp(o.structureRegex) : null;
  const structOf = (t) => {
    const s = classifyStructure(t, labelVocab);
    if (s) return s;
    if (userStructRe && userStructRe.test(String(t || "").trim())) return { level: 1, text: String(t).trim() };
    return null;
  };
  const isSectionHead = (t) => !!t && !!structOf(t);

  const layoutWarnings = [];
  const unresolvedSectionNotes = [];

  // 结构栈：每个段落位置 → 当时生效的结构段列表（有序）。结构段归属其**后面**的题。
  const structAt = new Map();
  const boardAt = new Map();
  const structureUnitIndices = new Set();
  const structureByUnitIndex = new Map();
  {
    let stack = [];
    let boardText = null;
    let activeNumberedScope = false;
    let parentText = null;
    units.forEach((u, i) => {
      if (u.kind === "p" && !u.inTable) {
        const candidate = structOf(u.text);
        const adjacent = !candidate || !candidate.boardScope || isSectionNoteAdjacent(units, i, qre);
        const s = adjacent ? candidate : null;
        if (candidate && candidate.boardScope && !adjacent) {
          unresolvedSectionNotes.push({ paraIndex: u.paraIndex, text: String(u.text || "").trim() });
        }
        if (s) {
          structureUnitIndices.add(i);
          structureByUnitIndex.set(i, s);
          if (s.level === 1) {
            stack = [s.text];
            boardText = s.text;
            activeNumberedScope = false;
            parentText = s.text;
          } else if (s.boardScope) {
            stack = parentText ? [parentText, s.text] : [s.text];
            boardText = s.text;
            activeNumberedScope = true;
          } else if (activeNumberedScope && isTopLevelNumberedSection(s.text)) {
            stack = parentText ? [parentText, s.text] : [s.text];
            boardText = s.text;
          } else {
            stack = stack.length ? [parentText || stack[0], s.text] : [s.text];
            if (!boardText) boardText = stack[0];
          }
          structAt.set(i, [...stack]);
          boardAt.set(i, boardText);
          return;
        }
        if (isAmbiguousSectionNote(u.text)) {
          unresolvedSectionNotes.push({ paraIndex: u.paraIndex, text: String(u.text || "").trim() });
        }
      }
      structAt.set(i, [...stack]);
      boardAt.set(i, boardText);
    });
  }
  for (const note of unresolvedSectionNotes) {
    layoutWarnings.push(`疑似板块说明未能安全判定或未紧邻后续题目（段落 ${note.paraIndex}）：${note.text}。原文仍按普通内容保留，请对照 blocks.json 核对归属。`);
  }

  // 2) 卷首说明区
  const preamble = findPreambleRange(units, isSectionHead);
  if (preamble) {
    const from = (units[preamble.start] || {}).paraIndex;
    const to = (units[preamble.end] || {}).paraIndex;
    layoutWarnings.push(
      preamble.bounded
        ? `已隔离卷首候选说明区（段落 ${from}–${to}）：该范围内的编号不参与题号识别，需对照原文确认。`
        : `只隔离了卷首标题（段落 ${from}）；未找到明确边界，后续段落仍参与候选切题，需对照原文确认。`,
    );
  }
  const inPreamble = (idx) => !!preamble && idx >= preamble.start && idx < preamble.end;

  // 3) 找题界。第一遍题号开新题；此后同一题号再次出现 → 归回同一题的「答案解析段」。
  let secondPassAt = -1;
  units.forEach((u, idx) => {
    if (secondPassAt >= 0 || u.kind !== "p" || u.inTable) return;
    const t = (u.text || "").trim();
    if (t.length <= 40 && RE_SECTION_BREAK.test(t)) secondPassAt = idx;
  });

  const hits = [];
  const byNum = new Map();
  const skippedRepeats = [];
  const orderViolations = [];
  let lastNum = -1;
  units.forEach((u, idx) => {
    if (u.kind !== "p" || u.inTable) return;
    if (inPreamble(idx)) return;
    const m = qre.exec(u.text || "");
    if (!m) return;
    const n = Number(m[1]);
    if (!Number.isFinite(n)) return;
    if (n > lastNum && !byNum.has(n)) {
      lastNum = n;
      const g = { num: n, segs: [] };
      byNum.set(n, g);
      hits.push({ idx, num: n, group: g, repeat: false });
      return;
    }
    const g = byNum.get(n);
    if (!g) { orderViolations.push(n); return; }
    if (o.noMergeRepeat) { skippedRepeats.push(n); return; }
    hits.push({ idx, num: n, group: g, repeat: true });
  });
  if (!hits.length) {
    throw new Error(
      `未按 --question-regex 找到任何题号（当前：${o.questionRegex || DEFAULT_QRE}）。` +
      `若素材题号版式特殊（如「第1题」「1)」「例1」），请用 --question-regex 覆盖。`,
    );
  }
  const firstNums = hits.filter((h) => !h.repeat).map((h) => h.num);
  const mergedNums = [...new Set(hits.filter((h) => h.repeat).map((h) => h.num))];
  if (firstNums.length && firstNums[0] !== 1) {
    layoutWarnings.push(`首遍题号不是从 1 开始（首个 = ${firstNums[0]}）：可能卷首有多余的编号行，或素材从中间截取。请核对 records。`);
  }
  if (mergedNums.length && secondPassAt < 0) {
    layoutWarnings.push(
      `题号 ${mergedNums.join(",")} 出现重复，但全文没有「参考答案/试题解析」标题：` +
      "已按「重复题号归回同题」处理；若这些其实是各自独立的题目，请加 --no-merge-repeat-numbers 重跑。",
    );
  }
  if (orderViolations.length) {
    layoutWarnings.push(`题号 ${[...new Set(orderViolations)].join(",")} 出现回退且找不到对应的已开题目，已忽略这些行。`);
  }

  // 4) 切段：每个题界管到下一个题界；第一遍的末段在第一遍结束处截断，
  //    免得把「参考答案与试题解析」的标题区并进末题 stem。
  for (let i = 0; i < hits.length; i += 1) {
    const h = hits[i];
    let to = i + 1 < hits.length ? hits[i + 1].idx : units.length;
    if (secondPassAt >= 0 && h.idx < secondPassAt && to > secondPassAt) to = secondPassAt;
    h.group.segs.push([h.idx, to]);
  }
  for (const h of hits) {
    if (!h.repeat) continue;
    const g = h.group;
    const last = g.segs[g.segs.length - 1];
    if (last && last[1] === h.idx) last[1] = h.idx + 1;
    else g.segs.push([h.idx, h.idx + 1]);
  }

  const sectionOf = (from) => {
    const st = structAt.get(from);
    return st && st.length ? st[0] : null;
  };
  const structuresOf = (from) => structAt.get(from) || [];

  // v1.2.4：没有 manifest（自建 blocks 路径）时，**别把中间产物名当成素材名**。
  // 以前 srcName 会取成 "blocks.json"、title 取成 "blocks"，交付件里的 title/sources.name
  // 就变成了中间产物的名字而不是用户材料。这里退到父目录名（通常就是材料名）。
  const inputBase = path.basename(o.input);
  const baseIsIntermediate = /^\s*blocks\.(json|txt)$/i.test(inputBase);
  const fallbackName = baseIsIntermediate
    ? (path.basename(path.dirname(path.resolve(o.input))) || stripExt(inputBase))
    : inputBase;
  const srcName = (manifest && manifest.input && manifest.input.name) || o.sourceName || fallbackName;
  const kind = (manifest && manifest.input && manifest.input.kind) || "document";
  const manifestDatasetId = manifest && (manifest.datasetId || (manifest.input && manifest.input.datasetId));
  const hasManifestDatasetId = typeof manifestDatasetId === "string" && manifestDatasetId.trim().length > 0;
  const datasetId = o.datasetId || (hasManifestDatasetId ? manifestDatasetId : "");
  if (!String(datasetId).trim()) {
    throw new Error("scaffold 需要稳定来源身份：请传 --dataset-id <稳定ID>，或在 manifest.datasetId / manifest.input.datasetId 中提供；不会从临时目录、文件名或内容猜 ID。");
  }
  const title = o.title || stripExt(srcName);
  const structuralCandidates = units.flatMap((unit, index) => {
    if (unit.kind !== "p" || unit.inTable || !structureUnitIndices.has(index)) return [];
    const structure = structureByUnitIndex.get(index);
    if (!structure) return [];
    const nextQuestion = hits.find((hit) => !hit.repeat && hit.idx > index);
    return [{
      sourceIndex: unit.sourceIndex,
      paraIndex: unit.paraIndex,
      level: structure.level,
      text: String(unit.text || ""),
      appliesToRecordKey: nextQuestion ? `${datasetId}#${nextQuestion.num}` : null,
      status: "needs-review",
    }];
  });
  const structuralBySourceIndex = new Map(structuralCandidates.map((candidate) => [candidate.sourceIndex, candidate]));

  const questions = [];
  const assetsById = new Map();
  const pending = [];
  const generatedTodoEntries = [];
  const latexGlue = [];
  const standaloneFormulas = [];
  const fieldLeadArtifacts = [];   // 段首占位符被并入栏目名括号的情形（如素材把「【」做成了图片）
  const droppedConclusions = [];   // 剔除的「与答案重复」的选项结论句
  const answerSentenceCandidates = [];
  const restoredBlankCandidates = [];
  const candidateRecordKeysByUnit = new Map();
  const mergedStructures = [];     // 结构段（章节/小节/模块头）及其归属
  const stat = { withOptions: 0, withAnswer: 0, withAnalysis: 0, withFigures: 0, blanksRestored: 0, blanksNormalized: 0 };

  for (const h0 of hits) {
    if (h0.repeat) continue;
    const g = h0.group;
    const recordKey = `${datasetId}#${g.num}`;
    for (const seg of g.segs) {
      for (let i = seg[0]; i < seg[1]; i += 1) {
        const unit = units[i];
        if (structureUnitIndices.has(i)) continue;
        const list = candidateRecordKeysByUnit.get(i) || [];
        if (!list.includes(recordKey)) list.push(recordKey);
        candidateRecordKeysByUnit.set(i, list);
      }
    }

    // 本题全部段落索引（含答案段），用于挂图
    const paraSet = new Set();
    for (const seg of g.segs) {
      for (let i = seg[0]; i < seg[1]; i += 1) {
        const unit = units[i];
        if (unit.kind === "p") paraSet.add(unit.paraIndex);
        else for (const row of unit.rows || []) for (const cell of row || []) {
          for (const para of cell || []) if (Number.isFinite(para.paraIndex)) paraSet.add(para.paraIndex);
        }
      }
    }

    const subquestionOptionPlan = planSubquestionOptions(g, units, labelVocab);

    const stemParts = [];        // 主题干段（第一遍）；表格暂用独立标记，避免题干填空规则进入单元格
    const stemTableSegments = [];
    let stemTableMarkerPrefix = "\uE000mofang-table-";
    const serializedUnits = JSON.stringify(units);
    while (serializedUnits.includes(stemTableMarkerPrefix)) stemTableMarkerPrefix += "_";
    const addStemTable = (markdown) => {
      const marker = `${stemTableMarkerPrefix}${stemTableSegments.length}）\uE001`;
      stemTableSegments.push({ marker, markdown });
      stemParts.push(marker);
    };
    const fields = [];           // [{name, paras:[…]}] 按原文顺序
    const paraOptions = [];      // 段内选项
    const tableOptions = [];     // 选项表
    const tableFindings = [];
    let cur = null;
    let expectOpt = "A";
    let pendingOpt = null;

    const startField = (name, firstPara) => {
      const entry = { name, paras: [] };
      if (firstPara !== undefined && String(firstPara).trim()) entry.paras.push(String(firstPara).trim());
      fields.push(entry);
      cur = entry;
    };

    const paragraphForTable = (para) => {
      let text = String(para.text ?? "");
      const missing = [];
      for (const id of para.images || []) {
        const marker = `{{${id}}}`;
        if (text.includes(marker)) continue;
        const media = mediaById.get(id);
        const figure = media ? (!media.role || media.role === "figure") : /^FIG/i.test(id);
        if (figure && text.length === 0) { missing.push(marker); continue; }
        return { text, reason: `媒体 ${id} 没有可确定的单元格内位置` };
      }
      if (missing.length) text = missing.join(" ");
      return { text, reason: null };
    };
    const escapeTablePipes = (text) => {
      let out = "";
      let mathMode = null;
      let splitterInMath = false;
      const escapedAt = (index) => {
        let backslashes = 0;
        for (let j = index - 1; j >= 0 && text[j] === "\\"; j -= 1) backslashes += 1;
        return backslashes % 2 === 1;
      };
      for (let i = 0; i < text.length; i += 1) {
        const ch = text[i];
        if (ch === "$" && !escapedAt(i)) {
          if (text[i + 1] === "$" && !escapedAt(i + 1)) {
            if (mathMode === "inline") return { text: null, reason: "行内公式与 $$ 公式块定界混用，无法按当前表格协议保真" };
            mathMode = mathMode === "display" ? null : "display";
            // 正式 splitCells 对每个美元符号各翻转一次，保持同口径以识别当前 parser 能否安全切格。
            splitterInMath = !splitterInMath;
            splitterInMath = !splitterInMath;
            out += "$$";
            i += 1;
            continue;
          }
          if (mathMode !== "display") mathMode = mathMode === "inline" ? null : "inline";
          splitterInMath = !splitterInMath;
        }
        if (ch === "|" && !escapedAt(i)) {
          const formulaPipe = mathMode !== null;
          if (formulaPipe !== splitterInMath) {
            return { text: null, reason: "公式内竖线与现有表格切格器的数学定界判断不一致，无法保真" };
          }
          if (!formulaPipe) out += "\\";
        }
        out += ch;
      }
      return { text: out, reason: null };
    };
    const sourceTableMarkdown = (u) => {
      const rows = u.rows || [];
      if (!rows.length) return { markdown: null, reason: "表格没有行" };
      const widths = rows.map((row) => Array.isArray(row) ? row.length : 0);
      const width = widths[0];
      if (!width || widths.some((n) => n !== width)) {
        return { markdown: null, reason: `行列数不一致或列数无效（${widths.join("/ ")}）` };
      }
      const escapedRows = [];
      for (let ri = 0; ri < rows.length; ri += 1) {
        const cells = [];
        for (let ci = 0; ci < width; ci += 1) {
          const paras = rows[ri][ci];
          if (!Array.isArray(paras) || paras.length > 1) {
            return { markdown: null, reason: `第 ${ri + 1} 行第 ${ci + 1} 格含多个段落，Markdown 表格无法保真` };
          }
          let text = "";
          if (paras.length) {
            const rendered = paragraphForTable(paras[0]);
            if (rendered.reason) return { markdown: null, reason: `第 ${ri + 1} 行第 ${ci + 1} 格${rendered.reason}` };
            text = rendered.text;
          }
          if (/[\r\n]/.test(text)) {
            return { markdown: null, reason: `第 ${ri + 1} 行第 ${ci + 1} 格含换行，Markdown 表格无法保真` };
          }
          const escaped = escapeTablePipes(text);
          if (escaped.reason) return { markdown: null, reason: `第 ${ri + 1} 行第 ${ci + 1} 格${escaped.reason}` };
          cells.push(escaped.text);
        }
        escapedRows.push(cells);
      }
      const lines = [
        `| ${escapedRows[0].join(" | ")} |`,
        `| ${escapedRows[0].map(() => "---").join(" | ")} |`,
        ...escapedRows.slice(1).map((row) => `| ${row.join(" | ")} |`),
      ];
      return { markdown: lines.join("\n"), reason: null };
    };

    const addTableFinding = (u, field, reason) => {
      const blockNo = Number.isInteger(u.sourceIndex) ? u.sourceIndex + 1 : "未知";
      const tableNo = u.tableId == null ? "未知" : u.tableId;
      tableFindings.push({
        code: "Q_TABLE_UNSUPPORTED", level: "blocking", field,
        message: `表格 #${tableNo}（blocks 第 ${blockNo} 块）未能安全归入正文：${reason}。原始单元格保留在 blocks-audit，请对照原件处理。`,
      });
    };

    g.segs.forEach((seg, si) => {
      const isRepeatSeg = si > 0 || (secondPassAt >= 0 && seg[0] >= secondPassAt);
      cur = null;
      for (let i = seg[0]; i < seg[1]; i += 1) {
        const u = units[i];

        if (u.kind === "tbl") {
          if (u.role === "other") {
            const field = cur ? (cur.name === ANSWER_FIELD_NAME ? "content.answer" : "content.analysis") : "content.stem";
            const rendered = sourceTableMarkdown(u);
            if (!rendered.markdown) {
              addTableFinding(u, field, rendered.reason);
              continue;
            }
            if (isRepeatSeg && !cur) {
              addTableFinding(u, "content.analysis", "位于重复题号段但前面没有明确栏目名，无法确认应归入解析还是其他字段");
              continue;
            }
            if (cur && cur.name !== ANSWER_FIELD_NAME && (cur.name === "考点" || META_FIELD_NAMES.has(cur.name))) {
              addTableFinding(u, "content.analysis", `当前栏目「${cur.name}」属于元数据，不能安全承载表格正文`);
            } else if (cur) cur.paras.push(rendered.markdown);
            else if (pendingOpt) {
              pendingOpt.text = rendered.markdown;
              addTableFinding(u, "content.options", "普通表格位于选项文本中；当前导入器按行内选项解析，表格仅保留为候选且阻塞确认");
              pendingOpt = null;
            } else if (paraOptions.length || tableOptions.length) {
              addTableFinding(u, "content.options", "表格紧随选项区域，但没有空选项标签可确定归属");
            } else addStemTable(rendered.markdown);
            continue;
          }
          if (u.role === "options") {
            // 从左到右扫：遇到纯标签单元格就开一个新选项，其后的单元格累加为该选项正文。
            // 兼容「一行一个选项」「一行两个选项」「标签与正文分列」等版式；
            // v1.2 只取每行第一个标签并 break，会把 B、D 连同其正文一起吞掉。
            let open = null;
            let unassignedText = false;
            const beforeCount = tableOptions.length;
            for (const row of u.rows) {
              const cells = row.map((c) => c.map((x) => {
                const rendered = paragraphForTable(x);
                if (rendered.reason) addTableFinding(u, "content.options", rendered.reason);
                return rendered.text.trim();
              }));
              for (const cell of cells) {
                const flat = cell.filter(Boolean);
                if (flat.length === 1 && OPT_LABEL_CELL.test(flat[0])) {
                  open = { label: flat[0].replace(/[．.、)）]/g, "").toUpperCase(), text: "" };
                  tableOptions.push(open);
                  continue;
                }
                if (!open) { if (flat.length) unassignedText = true; continue; }
                const t = flat.join("\n");
                if (t) open.text = open.text ? `${open.text}\n${t}` : t;
              }
            }
            if (tableOptions.length === beforeCount || unassignedText) {
              addTableFinding(u, "content.options", tableOptions.length === beforeCount
                ? "选项表中没有识别到选项标签与正文"
                : "存在未能归入任何选项的非空单元格");
            }
          } else if (u.role === "analysis") {
            let unparsedRow = false;
            for (const row of u.rows) {
              const cells = row.map((c) => c.map((x) => {
                const rendered = paragraphForTable(x);
                if (rendered.reason) addTableFinding(u, "content.analysis", rendered.reason);
                return rendered.text.trim();
              }));
              if (cells.every((cell) => cell.every((text) => !text))) continue;
              if (cells.length < 2) { unparsedRow = true; continue; }
              const label = normFieldName((cells[0][0] || "").replace(/[：:]\s*$/, ""));
              const paras = cells.slice(1).flat().filter(Boolean); // 单元格内每段独立成条，否则答案句剔不出来
              if (!label || !paras.length) { unparsedRow = true; continue; }
              const entry = { name: label, paras };
              fields.push(entry);
              cur = entry;
            }
            if (unparsedRow) addTableFinding(u, "content.analysis", "至少一行非空内容无法识别栏目名或正文");
          } else {
            addTableFinding(u, cur ? "content.analysis" : "content.stem", `未知表格角色 ${String(u.role)}`);
          }
          continue;
        }

        const t = (u.text || "").trim();
        if (!t) continue;

        // 结构段（章节/小节/模块头）与文档标题一律不进正文；必须在栏目名之前判，
        // 否则「【选修3-3】（12分）」这种会被当成栏目名吃掉（v1.2.2 的实测缺口）。
        if (t === docTitle || structureUnitIndices.has(i)) continue;

        if (subquestionOptionPlan.inlineIndices.has(i)) {
          stemParts.push(t);
          continue;
        }

        // 栏目名：强形式（成对括号）无条件认；弱形式（丢了开括号只剩「X】」或「X：」）
        // 要求命中词表——这样「由题意可知：…」这类正文不会被误判。
        const fl = matchFieldLabel(t, labelVocab);
        if (fl) {
          startField(fl.label, fl.rest);
          if (fl.droppedLead) fieldLeadArtifacts.push({ recordKey: `${datasetId}#${g.num}`, label: fl.label, token: fl.droppedLead });
          continue;
        }
        if (isRepeatSeg && !cur) continue;                    // 第二遍重复的题干段：不进 stem
        if (!cur) {
          const pieces = parseOptionParagraph(t, expectOpt);
          if (pieces) {
            for (const pc of pieces) {
              const item = { label: pc.label, text: pc.text };
              paraOptions.push(item);
              pendingOpt = pc.text ? null : item;
            }
            const lastLabel = paraOptions[paraOptions.length - 1].label;
            expectOpt = String.fromCharCode(lastLabel.charCodeAt(0) + 1);
            continue;
          }
          if (pendingOpt) { pendingOpt.text = pendingOpt.text ? `${pendingOpt.text}\n${t}` : t; continue; }
          stemParts.push(t);
          continue;
        }
        cur.paras.push(t);                                     // 栏目正文续段
      }
    });

    const options = tableOptions.length ? tableOptions : paraOptions;

    // 图位：media.paragraphs 与本题段落集合有交集
    const figs = [];
    for (const [id, m] of mediaById) {
      if (m.role && m.role !== "figure") continue;
      if (!(m.paragraphs || []).some((p) => paraSet.has(p))) continue;
      figs.push({ ref: figs.length + 1, assetId: id, role: "figure" });
      if (!assetsById.has(id)) {
        // 协议里资产固定在包根 assets/ 下；manifest 给的是预处理目录 media/，必须改名，
        // 否则 --root 校验与打包都找不到文件（v1.2 沿用了 media/… 路径，属缺陷）。
        assetsById.set(id, { id, path: `assets/${path.basename(m.path)}`, mime: mimeOf(m.path) });
      }
    }
    const refOf = new Map(figs.map((f) => [f.assetId, f.ref]));
    const toMd = (s) =>
      String(s).replace(/\{\{FIG(\d+)\}\}/g, (mm, nn) => (refOf.has(`FIG${nn}`) ? `[图${refOf.get(`FIG${nn}`)}]` : mm));

    // 题干：去题号区（分值/出处入 metadata/source）→ 填空归一化 → 落图位
    const sourceStemBody = stemParts.join("\n");
    let stemBody = sourceStemBody;
    let fenZhi = null;
    const hm = stemBody.match(RE_QHEAD);
    if (hm) {
      if (hm[2]) fenZhi = `${hm[2]}分`;
      stemBody = stemBody.slice(hm[0].length);
    }
    const om = stemBody.match(RE_ORIGIN);
    const originId = om ? om[0].replace(/[（）]/g, "") : null;
    if (om) stemBody = stemBody.replace(RE_ORIGIN, "");

    const restoreStemBlanksOutsideTables = (src) => {
      let text = "";
      let values = [];
      let normalized = 0;
      let cursor = 0;
      for (const segment of stemTableSegments) {
        const at = src.indexOf(segment.marker, cursor);
        if (at < 0) continue;
        const blanks = restoreStemBlanks(src.slice(cursor, at));
        text += `${blanks.text}${segment.marker}`;
        values = values.concat(blanks.values);
        normalized += blanks.normalized;
        cursor = at + segment.marker.length;
      }
      const tail = restoreStemBlanks(src.slice(cursor));
      text += tail.text;
      values = values.concat(tail.values);
      normalized += tail.normalized;
      const restoreTables = (value) => stemTableSegments.reduce(
        (current, segment) => current.split(segment.marker).join(segment.markdown), value,
      );
      return { text: restoreTables(text), before: restoreTables(src), values, normalized };
    };
    const blanks = restoreStemBlanksOutsideTables(stemBody);
    stemBody = blanks.text;
    const blankValues = blanks.values;
    if (blanks.text !== blanks.before || blanks.values.length || blanks.normalized) {
      restoredBlankCandidates.push({
        recordKey, before: blanks.before, candidateAfter: blanks.text,
        extractedValues: blanks.values, normalizedCount: blanks.normalized,
        status: "needs-review",
        reason: "全角空格夹内容可能是预填答案，也可能是原文有效文字；需对照原件确认后再采用候选还原。",
      });
    }

    let stem = toMd(stemBody).trim();
    const issues = [];
    issues.push(...tableFindings);
    for (const review of subquestionOptionPlan.reviews) {
      issues.push({
        code: "Q_SUBQUESTION_OPTIONS_REVIEW",
        level: "review",
        field: "content.stem",
        message: `原blocks第 ${Number.isInteger(review.headingSourceIndex) ? review.headingSourceIndex + 1 : "未知"} 块（段落 ${review.headingParaIndex}）的小问可能包含独立选项；选项从原blocks第 ${Number.isInteger(review.optionsSourceIndex) ? review.optionsSourceIndex + 1 : "未知"} 块（段落 ${review.optionsParaIndex}）起。答案或边界证据不足，请对照原文复核。${review.reason}`,
      });
    }

    // 栏目归位
    const answerFieldText = [];
    const pickedAnswers = [];
    const analysis = [];
    const knowledgePoints = [];
    const extraFromFields = {};
    const labelSeen = new Set();
    for (const f of fields) {
      const name = f.name;
      const text = f.paras.join("\n").trim();
      if (name === ANSWER_FIELD_NAME) { if (text) answerFieldText.push(text); continue; }
      if (name === "考点") {
        for (const k of text.split(/[；;]/).map((s) => s.replace(/[．.]?\s*菁优网版权所有\s*$/, "").trim()).filter(Boolean)) knowledgePoints.push(k);
        continue;
      }
      if (META_FIELD_NAMES.has(name)) { if (text) extraFromFields[name] = text; continue; }
      if (ANALYSIS_FIELD_NAMES.has(name)) {
        const stripped = stripAnswerSentences(f.paras);
        if (stripped.picked.length) answerSentenceCandidates.push({
          recordKey, field: `content.analysis(${name})`, originalParas: f.paras,
          candidateKept: stripped.kept, candidateAnswer: stripped.picked,
          status: "needs-review",
          reason: "答案句从解析拆出是候选归类；需确认句界及题目归属，原始段落保留在 blocks-audit。",
        });
        const body = stripped.kept.join("\n").trim();
        for (const p of stripped.picked) pickedAnswers.push(p);
        if (body) analysis.push({ label: name, text: body });
        continue;
      }
      // 未登记的栏目名：原样保留进 analysis，避免静默丢内容
      if (text) { analysis.push({ label: name, text }); labelSeen.add(name); }
    }
    if (labelSeen.size) {
      issues.push({
        code: "Q_UNKNOWN_FIELD", level: "review", field: "content.analysis",
        message: `素材里出现未登记的栏目名：${[...labelSeen].join("、")}。已按原栏目名放进 analysis，请确认归属。`,
      });
    }

    // 答案：以材料【答案】为准；否则用从解析里剔出的答案句；再否则用填空抽出的值
    let answer = null;
    if (answerFieldText.length) answer = answerFieldText.join("\n").trim() || null;
    else if (pickedAnswers.length) answer = pickedAnswers.join("\n").trim() || null;
    else if (blankValues.length) answer = blankValues.join("；");

    if (blankValues.length) {
      stat.blanksRestored += 1;
      issues.push({
        code: "Q_STEM_BLANK_RESTORED", level: "info", field: "content.stem",
        message: `题干填空已还原为 ____，抽出的值：${blankValues.join("；")}。`,
      });
    } else if (blanks.normalized) {
      stat.blanksNormalized += 1;
      issues.push({
        code: "Q_STEM_BLANK_NORMALIZED", level: "info", field: "content.stem",
        message: "题干填空处由「全角空格成对夹住空白」归一化为 ____（原文该处未预填内容，无还原值）。",
      });
    }

    /* ---- v1.2.3：末尾「与答案重复」的选项结论句 ---- */
    if (answer) {
      for (const a of analysis) {
        const r = stripDuplicateChoiceConclusions(a.text.split("\n"), answer);
        if (r.dropped.length) {
          droppedConclusions.push({
            recordKey, label: a.label, originalText: a.text,
            candidateText: r.kept.join("\n").trim(), candidateDropped: r.dropped,
            status: "needs-review",
            reason: "与答案重复的结论句只作去重候选；需核对原文与答案，不自动从解析删除。",
          });
        }
      }
    }

    /* ---- v1.2.3：内容层**所有**文本字段走同一条规范化管线 ----
     * v1.2.2 只对 stem/options 做图位替换，解析与答案里的 {{FIGnn}} 会原样残留，
     * 还会连累报出「图位未被正文引用」的假告警（河北卷实测）。这里改为统一遍历：
     * 以后新增字段只要登记在 fields 列表里，就自动被覆盖。
     */
    const contentFields = [
      { get: () => stem, set: (v) => { stem = v; } },
      ...options.map((x) => ({ get: () => x.text, set: (v) => { x.text = v; } })),
      ...analysis.map((x) => ({ get: () => x.text, set: (v) => { x.text = v; } })),
      { get: () => answer, set: (v) => { answer = v; } },
    ];
    for (const cf of contentFields) {
      const raw = cf.get();
      if (raw == null) continue;
      cf.set(toMd(String(raw)).trim());
    }

    // 未替换占位符（答案也纳入扫描：占位符落在答案里同样是阻塞项）
    const texts = [
      ["stem", stem],
      ...options.map((x, i) => [`options[${i}]`, x.text]),
      ...analysis.map((x, i) => [`analysis[${i}].${x.label}`, x.text]),
      ...(answer ? [["answer", answer]] : []),
    ];

    /* ---- v1.2.3：把「素材层发现的问题」自动披露到相关题目 ----
     * 预处理已经知道哪些公式图疑似字形异常、哪个段首占位符被并进了栏目名括号；
     * 这里把证据**挂到具体题目**上，免得依赖模型记得手写 issues。
     * 时机正好：此时正文还是 {{Fnnn}} 占位符，能精确对上题目。
     */
    const suspectGlyphs = new Set([
      ...((manifest && manifest.suspectedMissingGlyph) || []),
      ...((manifest && manifest.suspectedMangledGlyph) || []),
    ]);
    if (suspectGlyphs.size) {
      const hit = new Set();
      for (const [, txt] of texts) {
        for (const mm of String(txt || "").matchAll(/\{\{(F\d{3,})\}\}/g)) if (suspectGlyphs.has(mm[1])) hit.add(mm[1]);
      }
      if (hit.size) {
        issues.push({
          code: "Q_GLYPH_SUSPECT", level: "info", field: "content",
          message: `素材预处理报告下列公式疑似字形异常（本机渲染字体回退）：${[...hit].sort().join("、")}。` +
            "请结合上下文与配图判读后按原文转写；换一台机器（字体不同）结论可能不同，别沿用上次判断。",
        });
      }
    }
    const leadHits = fieldLeadArtifacts.filter((x) => x.recordKey === `${datasetId}#${g.num}`);
    if (leadHits.length) {
      issues.push({
        code: "Q_FIELD_LEAD_ARTIFACT", level: "info", field: "content.analysis",
        // 注意：这里**不要**裸写 {{Fnnn}} 字面量。披露文字里出现占位符，会让
        // 「扫一遍 JSON 看还有没有残留占位符」的朴素检查误判（模型/脚本都会中招）。
        message: `栏目名前的内联占位符（${leadHits.map((x) => String(x.token).replace(/[{}]/g, "")).join("、")}）已并入栏目名「${leadHits[0].label}」的括号——` +
          "素材把开括号本身做成了图片，该占位符不再进正文。",
      });
    }
    const tokenList = [];
    for (const [field, text] of texts) {
      const found = String(text || "").match(RE_PLACEHOLDER);
      if (found) tokenList.push({ field, tokens: [...new Set(found)] });
    }
    if (tokenList.length) {
      const all = [...new Set(tokenList.flatMap((x) => x.tokens))];
      const figsTodo = all.filter((x) => x.startsWith("{{FIG"));
      issues.push({
        code: figsTodo.length === all.length ? "Q_TODO_FIGURE" : "Q_TODO_FORMULA",
        level: "review", field: "content",
        message: all.some((x) => x.startsWith("{{F"))
          ? `仍有未替换占位符：${all.join(", ")}。{{Fnnn}} 需对照 formula-sheet-*.png 转写成 LaTeX；{{FIGnn}} 需落到 figures（未挂上说明该图不在本题段落映射里，请人工核对）。`
          : `仍有未替换的图位占位符：${all.join(", ")}。请核对 manifest.media 的 paragraphs 映射后手工落到 figures。`,
      });
      pending.push({ recordKey: `${datasetId}#${g.num}`, tokens: tokenList });
    }

    // v1.2.2：正文里既有公式的「命令粘连」预检（scaffold 阶段就报，不必等 validate）
    const glueTargets = [...texts.map(([f, t]) => [`content.${f}`, t]), ["content.answer", answer || ""]];
    for (const [field, text] of glueTargets) {
      const glue = detectCommandGlue(text);
      if (glue.length) latexGlue.push({ recordKey: `${datasetId}#${g.num}`, field, tokens: glue });
    }
    // v1.2.2：孤立成段的公式占位符单独列出——有时它只是原文档的装饰符（如 ●）
    for (const t of [stem, ...analysis.map((a) => a.text)]) {
      const mm = String(t || "").match(/^\{\{(F\d{3,})\}\}$/m);
      if (mm) standaloneFormulas.push({ recordKey: `${datasetId}#${g.num}`, id: mm[1] });
    }

    /* ---- v1.2.2 每题完整性自检 ---- */
    const isChoiceBlank = RE_CHOICE_BLANK.test(stem);
    const missingAnswerOptions = missingChoiceAnswerOptions(answer, options);
    if ((isChoiceBlank || hasExplicitChoiceAnswer(answer)) && options.length === 0) {
      if (missingAnswerOptions.length) {
        issues.push({
          code: "Q_OPTIONS_MISSING", level: "blocking", field: "content.options",
          message: `答案包含选项标签 ${missingAnswerOptions.join("")}，但没切出任何选项${isChoiceBlank ? "且题干含选择题括号" : ""}：请对照 blocks.json 补回。`,
        });
      } else {
        issues.push({
          code: "Q_OPTIONS_MAYBE_MISSING", level: "review", field: "content.options",
          message: "题干含括号但没有选项：若这是选择题说明选项丢了；若括号只是填空占位可忽略。",
        });
      }
    }
    if (options.length > 0) {
      const labels = options.map((x) => x.label);
      const expected = labels.map((_, i) => String.fromCharCode(65 + i));
      if (labels.some((l, i) => l !== expected[i])) {
        issues.push({
          code: "Q_OPTIONS_LABELS_GAPPED", level: "review", field: "content.options",
          message: `选项标签不是从 A 起连续（实际 ${labels.join("")}）：可能中间丢了选项，或把题干里的 A、B 枚举误判成了选项。`,
        });
      }
      if (missingAnswerOptions.length) {
        issues.push({
          code: "Q_ANSWER_OPTION_MISMATCH", level: "blocking", field: "content.answer",
          message: `纯选项答案引用了实际选项中不存在的标签 ${missingAnswerOptions.join("")}（实际标签 ${labels.join("")}）。请对照原文核对答案与选项。`,
        });
      }
    }

    if (!stem) {
      stem = "（题干未识别）";
      issues.push({
        code: "Q_STEM_EMPTY", level: "blocking", field: "content.stem",
        message: "未能从素材切出题干，请对照 _work/blocks.json 手工补写后再交付。",
      });
    }
    for (let i = 0; i < options.length; i += 1) {
      if (!options[i].text) {
        options[i].text = "__TODO_OPTION__";
        issues.push({
          code: "Q_OPTION_EMPTY", level: "blocking", field: `content.options[${i}].text`,
          message: `选项 ${options[i].label} 只有标号没有内容（可能是独立标签行 + 图片/公式未挂上），请补写。`,
        });
      }
    }

    const extra = { 题号: String(g.num) };
    if (fenZhi) extra.分值 = fenZhi;
    // 结构段（章节/小节/模块头）：v1.2.3 起按「结构栈」有序记录，不再只记最近的一个。
    // 板块 = 一级；结构 = 完整层级（含一级），仅当有二级时才写，避免与板块重复。
    const structs = structuresOf(g.segs[0][0]);
    if (structs.length) {
      extra.板块 = boardAt.get(g.segs[0][0]) || structs[0];
      if (structs.length > 1) extra.结构 = structs;
    }
    for (const [k, v] of Object.entries(extraFromFields)) extra[k] = v;

    const source = { sourceId: "src-001" };
    if (originId) source.sourceRecordId = originId;

    const metadata = { extra };
    if (knowledgePoints.length) metadata.knowledgePoints = knowledgePoints;

    if (options.length) stat.withOptions += 1;
    if (answer !== null) stat.withAnswer += 1;
    if (analysis.length) stat.withAnalysis += 1;
    if (figs.length) stat.withFigures += 1;

    const question = {
      recordKey,
      source,
      metadata,
      content: {
        format: "mofang-md-v1",
        stem,
        options,
        answer,
        analysis: analysis.length ? analysis : null,
        figures: figs,
      },
      issues,
    };
    questions.push(question);
    for (const issue of question.issues.filter((item) => GENERATED_TODO_CODES.has(item.code))) {
      const targets = contentStrings(question).map(([field, text]) => ({
        field,
        tokens: [...new Set(String(text).match(/\{\{(?:F\d{3,}|FIG\d{2,}|rId\d+)\}\}/g) || [])],
      })).filter((target) => target.tokens.length > 0);
      if (targets.length) generatedTodoEntries.push({
        recordKey,
        issue: { code: issue.code, level: issue.level, field: issue.field, message: issue.message },
        targets,
      });
    }
  }

  const doc = {
    format: "mofang-question-pack",
    schemaVersion: 1,
    packageId: `${datasetId}-scaffold`,
    datasetId,
    title,
    sources: [{
      id: "src-001",
      name: srcName,
      kind: kind === "image" ? "image" : kind === "text" ? "text" : "document",
      // 协议：**纯文字**交付时 sources 不带 path（单个 JSON，不附原件）。
      // 带上 path 而 root 里又没有那个文件，pack/validate 必然报一条「源附件缺失」的假 review。
      ...(kind !== "text" && manifest && manifest.source && manifest.source.path ? { path: manifest.source.path } : {}),
    }],
    assets: [...assetsById.values()],
    questions,
  };
  fs.mkdirSync(path.dirname(path.resolve(o.out)), { recursive: true });
  fs.writeFileSync(o.out, JSON.stringify(doc, null, 2), "utf8");

  // 候选映射旁车保留每个原始块的完整内容。所有自动归类、排除、合并和删并
  // 都保持待核状态；questions.json 本身不增加协议字段，也不宣称覆盖完整。
  const rawBlocks = Array.isArray(blocksDoc.blocks) ? blocksDoc.blocks : [];
  const firstHitIndex = hits.reduce((min, hit) => Math.min(min, hit.idx), units.length);
  const preambleIndices = new Set();
  if (preamble) for (let i = preamble.start; i < preamble.end; i += 1) preambleIndices.add(i);
  const auditBlocks = rawBlocks.map((raw, sourceIndex) => {
    const candidateRecordKeys = candidateRecordKeysByUnit.get(sourceIndex) || [];
    const structureCandidate = structuralBySourceIndex.get(sourceIndex);
    let reason;
    if (preambleIndices.has(sourceIndex)) {
      reason = preamble.bounded
        ? "位于卷首候选说明区；题号识别暂时排除，需核对边界与原文。"
        : "只有卷首标题本身被隔离；后续段落继续参与切题，需核对该标题与相邻内容。";
    } else if (structureCandidate) {
      reason = `识别为第 ${structureCandidate.level} 级结构段，并将完整原文挂到后续题 ${structureCandidate.appliesToRecordKey || "（无后续题）"}；请结合段号核对。`;
    } else if (candidateRecordKeys.length) {
      reason = "按题号与栏目规则候选归属；请对照原始块核对是否有误归、删并或未覆盖内容。";
    } else if (sourceIndex < firstHitIndex) {
      reason = "首个候选题之前的未归属材料，可能是共享材料、标题或说明，需人工确认归属。";
    } else {
      reason = "未映射到候选题；需检查是否为共享材料、表格、结构标题或漏切内容。";
    }
    return {
      sourceIndex,
      paraIndex: raw && raw.paraIndex,
      type: raw && raw.type || "paragraph",
      candidateRecordKeys,
      status: "needs-review",
      reason,
      raw: JSON.parse(JSON.stringify(raw)),
    };
  });
  const sharedCandidates = auditBlocks.filter((block) =>
    block.sourceIndex < firstHitIndex && !preambleIndices.has(block.sourceIndex) &&
    !structuralBySourceIndex.has(block.sourceIndex) && block.candidateRecordKeys.length === 0,
  ).map((block) => ({
    sourceIndex: block.sourceIndex, paraIndex: block.paraIndex,
    text: block.raw && typeof block.raw.text === "string" ? block.raw.text : null,
    raw: block.raw, status: "needs-review", reason: block.reason,
  }));
  const candidateRoutes = new Map();
  for (const block of auditBlocks) for (const recordKey of block.candidateRecordKeys) {
    const indexes = candidateRoutes.get(recordKey) || [];
    indexes.push(block.sourceIndex);
    candidateRoutes.set(recordKey, indexes);
  }
  const transformations = [
    ...answerSentenceCandidates.map((item) => ({ type: "answer-sentence-extraction", ...item })),
    ...restoredBlankCandidates.map((item) => ({ type: "prefilled-blank-restoration", ...item })),
    ...droppedConclusions.map((item) => ({ type: "duplicate-answer-conclusion", ...item })),
    ...structuralCandidates.map((item) => ({ type: "structure-section-routing", ...item })),
  ];
  if (preamble) transformations.push({
    type: "preamble-exclusion-candidate", status: "needs-review",
    sourceIndexes: [...preambleIndices], bounded: preamble.bounded,
    originalBlocks: [...preambleIndices].map((i) => auditBlocks[i] && auditBlocks[i].raw).filter(Boolean),
    reason: preamble.bounded
      ? "卷首范围由结构标题界定，仍需对照原件确认范围内均非题目内容。"
      : "无可靠结束边界，仅隔离卷首标题本身；后续段落没有按固定段数跳过。",
  });
  if (docTitle && units[0]) transformations.push({
    type: "document-title-exclusion-candidate", status: "needs-review",
    sourceIndex: units[0].sourceIndex, originalBlock: units[0].raw,
    reason: "首段被作为候选标题排除出题目正文，需核对它是否含有共享材料或题干。",
  });
  if (mergedNums.length) transformations.push({
    type: "repeated-question-number-merge", status: "needs-review",
    recordKeys: mergedNums.map((num) => `${datasetId}#${num}`),
    sourceBlocks: hits.filter((hit) => hit.repeat).map((hit) => ({
      sourceIndex: units[hit.idx] && units[hit.idx].sourceIndex,
      paraIndex: units[hit.idx] && units[hit.idx].paraIndex,
      recordKey: `${datasetId}#${hit.num}`,
      raw: units[hit.idx] && units[hit.idx].raw,
    })),
    reason: "重复题号可能是答案解析区，也可能是独立题目；合并关系只是候选，需看原文确认。",
  });
  transformations.push(...[...candidateRoutes.entries()].map(([recordKey, sourceIndexes]) => ({
    type: "candidate-question-routing", recordKey, sourceIndexes, status: "needs-review",
    reason: "题目边界与栏目归属为规则候选；完整原始 blocks 保留在旁车中供逐块核对。",
  })));
  const blockAuditFile = path.resolve(o.blockAudit || `${o.out}.blocks-audit.json`);
  const generatedTodoProvenanceFile = path.resolve(`${o.out}.todo-provenance.json`);
  const blockAudit = {
    format: "mofang-question-block-audit-v1",
    input: o.input,
    datasetId,
    sourceName: srcName,
    status: "candidate-only-needs-review",
    blockCoverage: {
      complete: false,
      total: auditBlocks.length,
      pending: auditBlocks.length,
      assignedCandidates: auditBlocks.filter((block) => block.candidateRecordKeys.length).length,
      unassigned: auditBlocks.filter((block) => !block.candidateRecordKeys.length).length,
    },
    blocks: auditBlocks,
    structuralCandidates,
    sharedCandidates,
    transformations,
    generatedTodoProvenanceFile,
  };
  fs.mkdirSync(path.dirname(blockAuditFile), { recursive: true });
  fs.writeFileSync(blockAuditFile, JSON.stringify(blockAudit, null, 2), "utf8");
  fs.writeFileSync(generatedTodoProvenanceFile, JSON.stringify({
    format: "mofang-question-generated-todo-provenance-v1",
    scaffoldVersion: VERSION,
    datasetId,
    sourceBlocks: { path: path.resolve(o.input), sha256: sha256File(o.input) },
    scaffoldOutputSha256: sha256File(o.out),
    entries: generatedTodoEntries,
  }, null, 2), "utf8");

  // 逐题一览（核对用；重点看 options 计数，切题切错时它会明显不对）
  const records = questions.map((q) => ({
    recordKey: q.recordKey,
    options: q.content.options.length,
    figures: q.content.figures.length,
    answer: q.content.answer === null ? null : (q.content.answer.length > 24 ? `${q.content.answer.slice(0, 24)}…` : q.content.answer),
    analysis: (q.content.analysis || []).map((a) => a.label),
    issues: q.issues.map((i) => i.code),
    stemHead: q.content.stem.replace(/\s+/g, " ").slice(0, 40),
  }));
  const suspicious = records.filter((r) => r.issues.some((c) => c === "Q_OPTIONS_MISSING" || c === "Q_OPTIONS_MAYBE_MISSING" || c === "Q_OPTIONS_LABELS_GAPPED" || c === "Q_STEM_EMPTY" || c === "Q_TABLE_UNSUPPORTED"));

  emit({
    tool: TOOL, mode: "scaffold", input: o.input, out: o.out, exitCode: 0,
    questionCount: questions.length,
    prefill: { ...stat },
    records,
    suspiciousRecords: suspicious.map((r) => r.recordKey),
    layoutWarnings,
    latexGlue: latexGlue.length ? latexGlue : undefined,
    standaloneFormulas: standaloneFormulas.length ? standaloneFormulas : undefined,
    droppedChoiceSentenceCandidates: droppedConclusions.length ? droppedConclusions : undefined,
    fieldLeadArtifacts: fieldLeadArtifacts.length ? fieldLeadArtifacts : undefined,
    structures: [...new Set([...structAt.values()].flat())],
    pendingFormulaTokens: pending,
    blockAuditFile,
    generatedTodoProvenanceFile,
    blockCoverage: blockAudit.blockCoverage,
    figuresFromBlocks: figuresFromBlocks || undefined,
    notes: {
      sourceName: srcName,
      datasetId,
      datasetIdSource: o.datasetId ? "显式 --dataset-id" : "manifest.datasetId / manifest.input.datasetId",
      preambleSkipped: preamble ? { fromParaIndex: (units[preamble.start] || {}).paraIndex, bounded: preamble.bounded } : null,
      answerSectionAtUnit: secondPassAt,
      mergedRepeatedNumbers: mergedNums,
      skippedRepeatedNumbers: [...new Set(skippedRepeats)],
      hasManifest: !!manifest,
      figuresFromBlocks: figuresFromBlocks
        ? `${figuresFromBlocks} 张插图来自 blocks 段落自带的 images[]（该素材未提供 manifest，或 manifest 未登记它们）`
        : null,
    },
    note: "这是候选 questions.json，不代表材料覆盖完整或题目归属已确认。逐块核对 blockAuditFile；共享材料、卷首范围、重复题号、答案抽取、预填答案还原与去重均需对照原件确认。",
  }, o);
  return 0;
}

/* ------------------------------------------------------------------ */
/* report：对 questions.json 出逐题核对表                               */
/* ------------------------------------------------------------------ */

function loadQuestions(file) {
  const doc = readJson(file);
  if (!doc || !Array.isArray(doc.questions)) throw new Error(`${file} 不是 questions.json（缺少 questions 数组）`);
  return doc;
}

function cmdReport(o) {
  const doc = loadQuestions(o.input);
  const maxStem = Number.isFinite(o.maxStem) ? o.maxStem : 60;
  const assetsById = new Map((doc.assets || []).filter((asset) => asset && asset.id).map((asset) => [asset.id, asset]));
  const rows = doc.questions.map((q, i) => {
    const c = q.content || {};
    const extra = (q.metadata && q.metadata.extra) || {};
    return {
      idx: i + 1,
      题号: extra.题号 != null ? String(extra.题号) : "",
      recordKey: q.recordKey,
      options: (c.options || []).map((x) => x.label).join(""),
      选项数: (c.options || []).length,
      figures: (c.figures || []).length,
      answer: c.answer == null ? null : String(c.answer).replace(/\s+/g, " ").slice(0, 40),
      analysis: (c.analysis || []).map((a) => a.label).join("+") || null,
      issues: (q.issues || []).map((x) => `${x.code}/${x.level}`),
      stem: String(c.stem || "").replace(/\s+/g, " ").slice(0, maxStem),
    };
  });
  const fullRows = o.full ? doc.questions.map((q, i) => {
    const c = q.content || {};
    const extra = (q.metadata && q.metadata.extra) || {};
    const figures = (c.figures || []).map((figure) => {
      const asset = assetsById.get(figure.assetId);
      return {
        ref: figure.ref,
        assetId: figure.assetId,
        role: figure.role,
        path: asset && asset.path ? asset.path : null,
      };
    });
    return {
      idx: i + 1,
      题号: extra.题号 != null ? String(extra.题号) : "",
      recordKey: q.recordKey,
      source: q.source || null,
      metadata: q.metadata || null,
      stem: String(c.stem || ""),
      options: (c.options || []).map((option) => ({ label: option.label, text: String(option.text || "") })),
      answer: c.answer == null ? null : String(c.answer),
      analysis: c.analysis == null ? null : c.analysis.map((analysis) => ({ label: analysis.label, text: String(analysis.text || "") })),
      figures,
      issues: q.issues || [],
    };
  }) : null;
  const optDist = {};
  for (const r of rows) optDist[r.选项数] = (optDist[r.选项数] || 0) + 1;
  const issueCount = {};
  for (const q of doc.questions) for (const it of q.issues || []) issueCount[it.code] = (issueCount[it.code] || 0) + 1;
  const stats = {
    选项数分布: optDist,
    有答案: rows.filter((r) => r.answer !== null).length,
    有解析: rows.filter((r) => r.analysis).length,
    有配图: rows.filter((r) => r.figures > 0).length,
    自报问题: issueCount,
  };

  if (o.md && o.full) {
    const lines = [`# ${doc.title || doc.datasetId || o.input} —— 逐题全文核对报告`, ""];
    for (const row of fullRows) {
      lines.push(`## ${row.idx}. 题号 ${row.题号 || "未标注"}`, "", `recordKey：${row.recordKey || "未标注"}`, "");
      if (row.source) lines.push(`来源：${JSON.stringify(row.source)}`, "");
      lines.push("### 题干", "", row.stem || "（空）", "", "### 选项", "");
      if (row.options.length) {
        for (const option of row.options) lines.push(`#### ${option.label}`, "", option.text || "（空）", "");
      } else lines.push("无选项。", "");
      lines.push("### 答案", "", row.answer == null ? "未提供。" : row.answer, "", "### 解析", "");
      if (row.analysis && row.analysis.length) {
        for (const analysis of row.analysis) lines.push(`#### ${analysis.label}`, "", analysis.text, "");
      } else lines.push("未提供。", "");
      lines.push("### 图位与资产", "");
      if (row.figures.length) {
        for (const figure of row.figures) {
          lines.push(`- 图位 ${figure.ref}：${figure.assetId}（${figure.role}），路径：${figure.path || "未列入 assets"}`);
        }
      } else lines.push("无图位。", "");
      lines.push("", "### Issues", "");
      if (row.issues.length) {
        for (const issue of row.issues) lines.push(`- ${JSON.stringify(issue)}`);
      } else lines.push("无。", "");
      lines.push("");
    }
    process.stdout.write(lines.join("\n"));
    return 0;
  }
  if (o.md) {
    const lines = [
      `## ${doc.title || doc.datasetId || o.input} —— 逐题核对表`,
      "",
      `- 题数 **${rows.length}**；选项数分布 ${JSON.stringify(optDist)}；有答案 ${stats.有答案}；有解析 ${stats.有解析}；有配图 ${stats.有配图}`,
      "",
      "| # | 题号 | 选项 | 图 | 答案 | 解析栏目 | 自报问题 | 题干（截断） |",
      "|---|---|---|---|---|---|---|---|",
      ...rows.map((r) => `| ${r.idx} | ${r.题号} | ${r.options || "—"} | ${r.figures} | ${r.answer == null ? "—" : r.answer.replace(/\|/g, "\\|")} | ${r.analysis || "—"} | ${r.issues.join(" ") || "—"} | ${r.stem.replace(/\|/g, "\\|")} |`),
    ];
    process.stdout.write(lines.join("\n") + "\n");
    return 0;
  }
  emit({
    tool: TOOL, mode: "report", input: o.input,
    datasetId: doc.datasetId, packageId: doc.packageId, schemaVersion: doc.schemaVersion,
    detail: o.full ? "full" : "summary",
    questionCount: rows.length, stats, records: o.full ? fullRows : rows,
  }, o);
  return 0;
}

/* ------------------------------------------------------------------ */
/* inspect：一条命令代替「读 manifest + 读 blocks」                     */
/* ------------------------------------------------------------------ */

function renderBlocksTxt(blocksDoc) {
  const lines = [];
  const blocks = (blocksDoc && blocksDoc.blocks) || [];
  lines.push("# blocks.txt — 行式视图（每行一段；制表符分隔：段落号 / 图片 / 原文）");
  lines.push(`# 源：blocks.json（blockCount=${blocksDoc.blockCount != null ? blocksDoc.blockCount : blocks.length}）`);
  lines.push("");
  for (const b of blocks) {
    if (b.type === "tbl") {
      lines.push(`-- 表格 #${b.tableId} role=${b.role || "other"} rows=${(b.rows || []).length} --`);
      let n = 0;
      for (const row of b.rows || []) {
        for (const cell of row) {
          for (const p of cell) {
            n += 1;
            lines.push(`${String(p.paraIndex).padStart(5, "0")}\t(表${n})\t${String(p.text || "").replace(/\t/g, " ")}`);
          }
        }
      }
      lines.push(`-- 表格 #${b.tableId} 结束 --`);
      continue;
    }
    lines.push(`${String(b.paraIndex).padStart(5, "0")}\t${(b.images || []).join(",")}\t${String(b.text || "").replace(/\t/g, " ")}`);
  }
  return lines.join("\n") + "\n";
}

function cmdInspect(o) {
  const work = o.work || "_work";
  const mFile = path.join(work, "manifest.json");
  const bFile = path.join(work, "blocks.json");
  const out = { tool: TOOL, mode: "inspect", work };
  if (!fs.existsSync(bFile)) throw new Error(`找不到 ${bFile}（先用 scripts/extract-material.cjs 生成 _work）`);
  const blocksDoc = readJson(bFile);
  if (fs.existsSync(mFile)) {
    const m = readJson(mFile);
    out.input = m.input && m.input.name;
    out.stats = m.stats;
    out.capabilities = m.capabilities;
    out.warnings = m.warnings || [];
    out.suspectedMissingGlyph = m.suspectedMissingGlyph || [];
    out.suspectedMangledGlyph = m.suspectedMangledGlyph || [];
    out.artifacts = m.artifacts;
    out.formulaSheets = (m.formulaSheets || []).map((s) => ({
      path: s.path, width: s.width, height: s.height,
      items: (s.items || []).length,
      paragraphRange: s.paragraphRange,
      paragraphs: (s.paragraphs || []).slice(0, 40),
    }));
    if (o.formula) {
      const requested = String(o.formula).toUpperCase();
      const formulaId = /^F?\d{3,}$/.test(requested) ? (requested.startsWith("F") ? requested : `F${requested}`) : null;
      if (!formulaId) throw new Error(`公式编号无效：${o.formula}（示例：F112）`);
      const media = (m.media || []).find((item) => item && item.id === formulaId && item.role === "formula");
      if (!media) throw new Error(`manifest.media 中找不到公式 ${formulaId}`);
      const paragraphSet = new Set((media.paragraphs || []).filter(Number.isFinite));
      const lines = renderBlocksTxt(blocksDoc).split("\n");
      const matchingLines = [];
      for (let index = 0; index < lines.length; index += 1) {
        const match = /^(\d{5})\t/.exec(lines[index]);
        if (match && paragraphSet.has(Number(match[1]))) matchingLines.push(index);
      }
      const contextLines = [];
      const seenContextLines = new Set();
      for (const index of matchingLines) {
        for (let neighbor = Math.max(0, index - 2); neighbor <= Math.min(lines.length - 1, index + 2); neighbor += 1) {
          if (seenContextLines.has(neighbor)) continue;
          seenContextLines.add(neighbor);
          contextLines.push({ line: neighbor + 1, text: lines[neighbor] });
        }
      }
      out.formulaLookup = {
        id: formulaId,
        imagePath: media.path ? path.resolve(work, media.path) : null,
        imageExists: !!media.path && fs.existsSync(path.resolve(work, media.path)),
        role: media.role,
        source: media.from || null,
        paragraphs: [...paragraphSet],
        contextLines,
        sheets: (m.formulaSheets || []).filter((sheet) => (sheet.items || []).includes(formulaId)).map((sheet) => ({
          path: path.resolve(work, sheet.path),
          width: sheet.width,
          height: sheet.height,
        })),
      };
    }
    out.next = m.next || [];
  } else {
    out.warnings = [`找不到 ${mFile}（只读了 blocks.json）`];
    if (o.formula) throw new Error(`找不到 ${mFile}，无法定位公式 ${o.formula}`);
  }
  const txt = renderBlocksTxt(blocksDoc);
  const txtFile = path.join(work, "blocks.txt");
  if (o.write) { fs.writeFileSync(txtFile, txt, "utf8"); out.blocksTxt = { path: txtFile, lines: txt.split("\n").length - 1 }; }
  const all = txt.split("\n");
  out.blocks = { paragraphs: all.filter((l) => /^\d{5}\t/.test(l)).length, totalLines: all.length };
  const preview = Number.isFinite(o.lines) ? o.lines : 0;
  if (preview > 0) out.blocksPreview = all.slice(0, preview);
  emit(out, o);
  return 0;
}

/* ------------------------------------------------------------------ */
/* doctor：环境自检（跨机器排障）                                      */
/* ------------------------------------------------------------------ */

function cmdDoctor(o) {
  const major = Number(process.versions.node.split(".")[0]);
  let raster;
  try { raster = require("./lib/raster.cjs").probe(); } catch (e) { raster = { backend: null, detail: `探测失败：${e.message}` }; }
  const out = {
    tool: TOOL, mode: "doctor", version: VERSION,
    node: { version: process.versions.node, ok: major >= 20, note: major >= 20 ? "满足 Node 20+" : "需要 Node 20 或更高版本" },
    platform: process.platform,
    stdout: process.stdout.isTTY ? "tty（Windows 控制台若为 GBK，中文可能显示为乱码；重定向到文件则是 UTF-8）" : "非 tty（重定向，UTF-8）",
    bundle: { path: BUNDLE, exists: fs.existsSync(BUNDLE) },
    rasterBackend: raster,
    notes: [
      "矢量公式图（WMF/EMF）必须真正栅格化；渲染出来的字形是否正常取决于**本机字体**，与后端选型无关。",
      "非 Windows 且无 ImageMagick 时无法栅格化，会如实降级并写进 warnings。",
      "打包用 mofang.cjs pack，不依赖系统 zip/unzip。",
      "重跑请换 --out 目录，不要删 _work。",
    ],
  };
  emit(out, o);
  return 0;
}

/* ------------------------------------------------------------------ */

function main(argv) {
  // 允许 `mofang.cjs --help` / `-h` / `--version` 直接生效（否则会被当成未知子命令）
  if (argv.length && /^(--help|-h)$/.test(argv[0])) { process.stdout.write(HELP); return 0; }
  if (argv.length && /^(--version|-V)$/.test(argv[0])) { process.stdout.write(`${VERSION}\n`); return 0; }
  let o;
  try {
    o = parseArgs(argv);
  } catch (e) {
    process.stderr.write(`参数错误：${e.message}\n\n${HELP}`);
    return 2;
  }
  const major = Number(process.versions.node.split(".")[0]);
  if (major < 20 && !o.help) {
    process.stderr.write(`需要 Node 20 或更高版本（当前 ${process.versions.node}）。\n`);
    return 2;
  }
  if (o.help || !o.sub) {
    process.stdout.write(HELP);
    return o.help ? 0 : 2;
  }
  try {
    if (o.sub === "validate") return cmdValidate(o);
    if (o.sub === "pack") return cmdPack(o);
    if (o.sub === "fix") return cmdFix(o);
    if (o.sub === "scaffold") return scaffold(o);
    if (o.sub === "report") return cmdReport(o);
    if (o.sub === "inspect") return cmdInspect(o);
    if (o.sub === "doctor") return cmdDoctor(o);
    process.stderr.write(`未知子命令：${o.sub}\n\n${HELP}`);
    return 2;
  } catch (e) {
    process.stderr.write(`错误：${e.message}\n`);
    return 2;
  }
}

if (require.main === module) {
  process.exit(main(process.argv.slice(2)));
}

module.exports = { fixText, delimitersOutsideMath, buildSummary, detectCommandGlue, parseOptionParagraph, findPreambleRange };
