---
name: mofang-question-transcribe
description: 忠实转写并整理用户提供的题目材料，生成魔方助教可导入的 JSON 或含图 ZIP；按当前宿主实际能力读取素材，不直接操作题库。
version: 1.2.9
---

# 魔方题目转写

把原材料整理成可导入题目包。保留原文事实、题目关系和来源；不自行解题、补答案、猜测模糊字符或生成替代配图。材料没给答案或解析时分别写 `null`。拿不准的内容保留原串，标出字段和待核原因。

## 选择合适的路径

先看材料和当前宿主实际可用的读取能力。格式支持取决于环境：本 skill 不宣称内建读取 PDF、PPTX、XLSX 或扫描件。宿主能可靠读取时可直接整理；需要导出或抽取时使用可用工具。需要本地预处理时，按 [references/extract-material.md](references/extract-material.md) 查看 `extract-material.cjs` 的真实支持范围。

- 一道简单题、单张截图或短 Markdown：直接写正式 pack JSON 并运行 `validate`。不要求先造 `blocks.json`，也不要求使用 `scaffold`。
- 多题混排、复杂表格或已有素材抽取结果：若能帮助保留段落与图片位置，可整理为 blocks，再用 `scaffold` 生成候选 JSON。`scaffold` 是辅助切分，不是必经步骤或完整性证明。
- 图片和公式：尽量保留原图或忠实裁剪，并按协议建立 assets 与图位引用。不要用生成图替代材料。

选择题按原文完整保留标签 A–H、顺序和全文。复合题中明确要求选项作答的小问，其 A/B/C 应留在该小问原位；不能因为整题不是选择题就清空 options。边界不明时保留原文并定位 review。工具会把纯选项答案引用了未提取的标签报告为 blocking；这不能发现未出现在答案中的漏项，也不能证明无答案题的选项齐全，仍需对照 blocks 和原件逐项核对。

## 忠实性与来源身份

逐题保留题干、选项、已有答案、解析、图片、分类原文和题间关系。共享材料必须保留；作答需要的共同条件要落实到每道受影响题的正式题干，或按 v1 协议把完整题组作为一条记录。不能只留在 `sources/` 或审计旁车里，也不要自造引用字段或机械复制到无关题目。题组范围或归属未确认时保留原文并标为待处理，不宣称完整。题界、重复题号、卷首说明、答案句拆分、预填空还原及去重都只是候选处理，必须对照原件确认。

数学表达若有多种解释，原串保持不变并定位到字段待核，例如 `$x^{2}^{3}$`、相邻公式 `$1$$2$`、未知命令粘连 `\sinn`。不要自动合并、拆开或改写来猜其含义。复杂公式图、切片、题组和复核流程见 [references/content-and-review.md](references/content-and-review.md)。

每个来源使用稳定的 `datasetId`；同名但不同来源要区分。优先复用已有来源 ID；首次遇到新来源时，可按原件的稳定指纹确定一次并保存在正式 JSON。纯文本首次收录后也保存该 ID。后续重试、移动工作目录或修改题目文字与图片时，复用原 `datasetId` 与由源题号/稳定源 ID 建立的 `recordKey`，不要对每次修订的内容重算身份。若来源身份或题目对应关系不明确，先请求足以区分来源的信息。运行 `scaffold` 时须显式提供 `--dataset-id`，或在 manifest 中提供稳定 `datasetId`；由 agent 根据已确定的原件身份生成并复用，无需普通用户设计 ID。

## 候选切分与核对

`scaffold` 输出正式 JSON 候选，并另写 `.blocks-audit.json`：其中逐块保留原始内容，展示候选题号、未归属共享材料及被排除、拆分或合并的理由。旁车中的状态始终表示“待核”，不需要为了改成 `complete` 而重写它。核对未归属块与特殊变换，再把确认后的内容落实到正式 JSON；旁车作为原文定位依据保留。

图片、表格、特殊栏目或复杂答案版式的细节按需读相应参考文档，不必把所有参考资料一次读完：

- 交付结构、字段、路径和稳定 ID： [references/protocol.md](references/protocol.md)
- 共享题组、数学保真、分类与复核： [references/content-and-review.md](references/content-and-review.md)
- 抽取产物和预处理命令： [references/extract-material.md](references/extract-material.md)

## 校验与打包

对正式 JSON 运行随包工具的 `validate`。纯文字可直接交付 JSON；含资产时用 `pack --verify` 生成 ZIP：

```bash
node scripts/mofang.cjs validate --input questions.json
node scripts/mofang.cjs pack --input questions.json --root <素材根目录> --output questions.zip --verify --media-dir <图片目录> [--source-dir <原件目录>]
```

`fix` 仅处理题目内容字段的明确格式归一；默认保留所有既有 `issues`。调用者对照原件确认对应字段已完成后，可用 `--confirm-generated-todos` 定向确认 scaffold 生成的 TODO；若输入另存为 `questions.filled.json`，用 `--todo-provenance questions.json.todo-provenance.json` 指回原 scaffold 旁车。来源或精确匹配无效时整批失败且不写输出；仍有占位符的条目保留 issue 并在审计中标为未完成。来源旁车会保留，不能用输出或审计覆盖。

`pack` 是正式薄壳入口：对新素材根先做隔离预检，随后仍检查真实目标根；对已有根直接检查结构和路径。检查通过后才暂存素材、生成临时 ZIP 并复验，成功后才替换输出。`--force` 不会提前删除旧 ZIP，失败时保留旧文件。`--allow-partial` 仅适用于明确需要部分包的场景。v1.2.8 的临时绕行方法只作历史记录，不能代替当前薄壳校验。

首次 pack 时可直接给一个尚不存在的素材根目录；通过输入和路径预检后，工具会创建 root、`assets/` 与 `sources/`。已有 root 的目录链接或普通文件会被拒绝。若 output 已存在且未传 `--force`，命令在创建目标 root 前拒绝；无需手工 `mkdir`。

候选或定稿后可用 `node scripts/mofang.cjs report --input questions.json --full --md` 输出逐题全文核对稿，含完整题干、选项、答案、解析、图位资产路径和 issues；省略 `--md` 时 `--full` 输出完整 JSON。默认 `report` 与摘要 Markdown 表仍保留旧的题干截断和答案短摘要行为。

若当前环境无法运行 Node 20+，仍交付正式 JSON 与所需资产，并明确说明未运行本地校验；不要自动安装运行时，也不要声称校验通过。

把中间稿命名为 `<卷名>.working.json`，选定唯一正式 `.json` 或 `.zip` 交付路径；后续重试复用来源身份，不覆盖旧的冻结包。在回复中给出正式文件绝对路径、实际校验结果及仍待处理的题目。候选旁车、抽取文件和审计日志用于复核，不可替代正式 JSON 中的题目内容。
